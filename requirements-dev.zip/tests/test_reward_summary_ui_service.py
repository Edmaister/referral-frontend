from app.services.reward_summary_ui_service import normalize_reward_summary_payload


def test_normalize_reward_summary_matches_api_shape():
    raw = {
        "referralTrackId": "56a8c78e-0203-4c27-befe-fed4ee445bb5",
        "currency": "ZAR",
        "generatedAt": "2026-04-10T12:45:44.225763Z",
        "referrer": {
            "earned": 100,
            "pending": 50,
            "nextEligibleReward": 25,
            "totalPotential": 150,
        },
        "referee": {
            "earned": 0,
            "pending": 0,
            "nextEligibleReward": 0,
            "totalPotential": 0,
        },
        "count": 1,
        "items": [
            {
                "beneficiaryType": "REFERRER",
                "rewardType": "BASE",
                "rewardSource": "BASE",
                "status": "APPLIED",
                "amount": 100,
                "description": "Base referral reward",
                "missionCode": None,
            }
        ],
        "disclosures": ["Line one.", "Line two."],
        "compliance": {
            "isAdvice": False,
            "requiresDisclaimer": True,
            "disclaimerCodes": ["GENERAL_INFO_ONLY", "REWARD_CONDITIONAL"],
            "regulatoryTags": ["TCF", "FAIS"],
        },
    }
    out = normalize_reward_summary_payload(raw)
    assert out is not None
    assert out["referral_track_id"] == "56a8c78e-0203-4c27-befe-fed4ee445bb5"
    assert out["referrer"]["earned"] == 100
    assert out["referrer"]["next_eligible"] == 25
    assert out["referee"]["total_potential"] == 0
    assert len(out["disclosures"]) == 2
    assert out["compliance"]["regulatory_tags"] == ["TCF", "FAIS"]
    assert out["items"][0]["beneficiary_label"] == "Your rewards (referrer)"
    assert "2026" in out["generated_at_label"]
