from fastapi.testclient import TestClient

from app.main import app


def test_healthz_ok():
    client = TestClient(app)
    resp = client.get("/healthz")
    assert resp.status_code == 200
    assert resp.json().get("status") == "ok"


def test_home_route_available():
    client = TestClient(app)
    resp = client.get("/")
    assert resp.status_code in (200, 302)


def test_friend_route_available():
    client = TestClient(app)
    resp = client.get("/friend")
    assert resp.status_code == 200


def test_me_requires_context_redirects_home():
    client = TestClient(app)
    resp = client.get("/me", follow_redirects=False)
    assert resp.status_code == 302
    assert resp.headers.get("location", "").startswith("/?no_ocep=1")


def test_refer_and_earn_requires_context_redirects_home():
    client = TestClient(app)
    resp = client.get("/refer-and-earn", follow_redirects=False)
    assert resp.status_code == 302
    assert resp.headers.get("location", "").startswith("/?no_ocep=1")


def test_admin_route_available_or_gated():
    client = TestClient(app)
    resp = client.get("/admin")
    assert resp.status_code in (200, 401, 404)


def test_correlation_id_header_echoed():
    client = TestClient(app)
    resp = client.get("/healthz", headers={"X-Correlation-ID": "test-corr-id"})
    assert resp.status_code == 200
    assert resp.headers.get("X-Correlation-ID") == "test-corr-id"


def test_me_referral_detail_requires_context():
    client = TestClient(app)
    resp = client.get(
        "/me/referral/831bd2e8-15e6-4f19-8fd5-14d89a75e8ee",
        follow_redirects=False,
    )
    assert resp.status_code == 302
    assert resp.headers.get("location", "").startswith("/?no_ocep=1")


def test_me_subpages_require_context():
    client = TestClient(app)
    for path in ("/me/rewards", "/me/missions", "/me/leaderboard", "/me/share"):
        resp = client.get(path, follow_redirects=False)
        assert resp.status_code == 302
        assert "no_ocep=1" in resp.headers.get("location", "") or resp.headers.get(
            "location", ""
        ).startswith("/?no_ocep=1")


def test_friend_journey_and_rewards_available():
    client = TestClient(app)
    assert client.get("/friend/journey").status_code == 200
    assert client.get("/friend/rewards").status_code == 200
