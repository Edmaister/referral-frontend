import re

import pytest
from fastapi.testclient import TestClient

from app.config import PROGRESS_EVENT_TYPES
from app.main import app
from app.routers import admin as admin_router


def _csrf(html: str) -> str:
    m = re.search(r'name="csrf_token"\s+value="([^"]+)"', html)
    assert m, "CSRF token not found"
    return m.group(1)


def _seed_admin_context(client: TestClient) -> str:
    page = client.get("/admin")
    token = _csrf(page.text)
    set_resp = client.post(
        "/admin",
        data={
            "csrf_token": token,
            "ocep_ucn": "U_TEST",
            "ocep_tenant": "FNB",
            "ocep_sticker": "EASY",
            "ocep_segment": "EASY",
        },
        follow_redirects=False,
    )
    assert set_resp.status_code in (302, 303)
    page2 = client.get("/admin")
    return _csrf(page2.text)


@pytest.mark.parametrize(
    "event_type",
    [ev for ev in PROGRESS_EVENT_TYPES if ev != "ACCOUNT_OPENED"],
)
def test_admin_progress_other_event_types_forward_fields(monkeypatch, event_type: str):
    captured = {}

    def _fake_record(_client, **kwargs):
        captured.update(kwargs)
        return {"status": "ok"}

    monkeypatch.setattr(
        admin_router.workflows,
        "record_referral_progress_event",
        _fake_record,
    )

    client = TestClient(app)
    token = _seed_admin_context(client)
    resp = client.post(
        "/admin/progress",
        data={
            "csrf_token": token,
            "referral_track_id": "62fe7073-8846-424d-859e-63ea4d77231b",
            "event_type": event_type,
            "product": "Transactional",
            "sub_product": "DDA13",
            "include_referee_ucn": "1",
            "referee_ucn": "202604101032",
            "account_number": "11223301",
        },
        follow_redirects=False,
    )
    assert resp.status_code in (302, 303)
    assert "progress_ok=1" in resp.headers.get("location", "")
    assert captured["event_type"] == event_type
    assert captured["referee_ucn"] == "202604101032"
    assert captured["account_number"] == "11223301"
    assert captured["product"] == "Transactional"
    assert captured["sub_product"] == "DDA13"


def test_admin_progress_account_opened_requires_referee_ucn_and_account():
    client = TestClient(app)
    token = _seed_admin_context(client)
    resp = client.post(
        "/admin/progress",
        data={
            "csrf_token": token,
            "referral_track_id": "62fe7073-8846-424d-859e-63ea4d77231b",
            "event_type": "ACCOUNT_OPENED",
            "include_referee_ucn": "1",
            "referee_ucn": "202604101032",
            "account_number": "",
        },
        follow_redirects=False,
    )
    assert resp.status_code in (302, 303)
    assert "error=progress_payload_missing" in resp.headers.get("location", "")


def test_admin_progress_account_activated_requires_referee_ucn():
    client = TestClient(app)
    token = _seed_admin_context(client)
    resp = client.post(
        "/admin/progress",
        data={
            "csrf_token": token,
            "referral_track_id": "62fe7073-8846-424d-859e-63ea4d77231b",
            "event_type": "ACCOUNT_ACTIVATED",
            "include_referee_ucn": "1",
            "referee_ucn": "",
            "account_number": "11223301",
        },
        follow_redirects=False,
    )
    assert resp.status_code in (302, 303)
    assert "error=progress_payload_missing" in resp.headers.get("location", "")


def test_admin_progress_uses_typed_referee_ucn_even_if_checkbox_off(monkeypatch):
    captured = {}

    def _fake_record(_client, **kwargs):
        captured.update(kwargs)
        return {"status": "ok"}

    monkeypatch.setattr(
        admin_router.workflows,
        "record_referral_progress_event",
        _fake_record,
    )
    client = TestClient(app)
    token = _seed_admin_context(client)
    resp = client.post(
        "/admin/progress",
        data={
            "csrf_token": token,
            "referral_track_id": "62fe7073-8846-424d-859e-63ea4d77231b",
            "event_type": "ACCOUNT_ACTIVATED",
            # Checkbox intentionally omitted
            "referee_ucn": "202604101032",
            "account_number": "11223301",
        },
        follow_redirects=False,
    )
    assert resp.status_code in (302, 303)
    assert "progress_ok=1" in resp.headers.get("location", "")
    assert captured["referee_ucn"] == "202604101032"


def test_admin_progress_other_events_require_account_number():
    client = TestClient(app)
    token = _seed_admin_context(client)
    resp = client.post(
        "/admin/progress",
        data={
            "csrf_token": token,
            "referral_track_id": "62fe7073-8846-424d-859e-63ea4d77231b",
            "event_type": "SALARY_SWITCHED",
            "include_referee_ucn": "1",
            "referee_ucn": "202604101032",
            "account_number": "",
        },
        follow_redirects=False,
    )
    assert resp.status_code in (302, 303)
    assert "error=progress_payload_missing" in resp.headers.get("location", "")

