from app.services.referrer_missions_service import _normalize_mission_row


def test_normalize_mission_strips_optional_prefix_title():
    row = {
        "title": "Optional mission: first salary switch",
        "progress": 1,
        "goal": 1,
        "isComplete": True,
        "bonusRewardAmount": 50,
        "maxBonusRewardAmount": 50,
    }
    m = _normalize_mission_row(row, category_default="BOOST")
    assert m["title"] == "First salary switch"


def test_normalize_mission_reward_fallback_when_canonical_zero():
    row = {
        "title": "Salary bonus",
        "progress": 1,
        "goal": 1,
        "isComplete": True,
        "bonusRewardAmount": 0,
        "maxBonusRewardAmount": 0,
        "payoutAmount": 75,
    }
    m = _normalize_mission_row(row, category_default="BOOST")
    assert m["reward_potential_max"] == 75
    assert m["reward_earned_amount"] == 75
    assert m["bonus_reward_amount"] == 75
