from app.services.referrer_reward_overview_service import (
    normalize_referrer_reward_overview_payload,
)


def test_normalize_referrer_reward_overview_matches_api_shape():
    raw = {
        "referrerUcn": "202604101416",
        "currency": "ZAR",
        "generatedAt": "2026-04-11T12:55:14.850227Z",
        "totals": {
            "earned": 200,
            "pending": 200,
            "nextEligibleReward": 200,
            "totalPotential": 400,
        },
        "referralsCount": 1,
        "completedReferralsCount": 1,
        "pendingBonusesCount": 1,
        "count": 2,
        "disclosures": [
            "This is general information and not personal financial advice.",
            "Rewards are conditional.",
        ],
        "compliance": {
            "isAdvice": False,
            "requiresDisclaimer": True,
            "disclaimerCodes": ["GENERAL_INFO_ONLY"],
            "regulatoryTags": ["TCF", "FAIS"],
        },
    }
    out = normalize_referrer_reward_overview_payload(raw)
    assert out["referrer_ucn"] == "202604101416"
    assert out["currency_symbol"] == "R"
    assert out["earned"] == 200.0
    assert out["pending"] == 200.0
    assert out["next_eligible"] == 200.0
    assert out["total_potential"] == 400.0
    assert out["referrals_count"] == 1
    assert out["completed_referrals_count"] == 1
    assert out["pending_bonuses_count"] == 1
    assert out["line_item_count"] == 2
    assert "2026" in out["generated_label"]
    assert len(out["disclosures"]) == 2
    assert out["compliance"]["requires_disclaimer"] is True
    assert out["compliance"]["regulatory_tags"] == ["TCF", "FAIS"]


def test_normalize_referrer_overview_root_level_totals_fallback():
    """Some proxies omit the nested ``totals`` object; read amounts from the root."""
    raw = {
        "referrerUcn": "202604101416",
        "currency": "ZAR",
        "generatedAt": "2026-04-11T12:55:14.850227Z",
        "earned": 200,
        "pending": 200,
        "nextEligibleReward": 200,
        "totalPotential": 400,
        "referralsCount": 1,
        "completedReferralsCount": 1,
        "pendingBonusesCount": 1,
        "count": 2,
        "disclosures": [],
        "compliance": {
            "isAdvice": False,
            "requiresDisclaimer": False,
            "disclaimerCodes": [],
            "regulatoryTags": [],
        },
    }
    out = normalize_referrer_reward_overview_payload(raw)
    assert out["earned"] == 200.0
    assert out["pending"] == 200.0
    assert out["next_eligible"] == 200.0
    assert out["total_potential"] == 400.0
