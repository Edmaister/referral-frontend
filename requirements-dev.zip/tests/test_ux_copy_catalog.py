from app.copy.ux_copy_catalog import (
    REFERRER_PHASE_FINAL_STEPS,
    REFERRER_STATUS_COMPLETED,
    REFERRER_STATUS_IN_PROGRESS,
    filter_referrer_missions,
    format_referrer_milestone_for_display,
    sanitize_mission_title_for_display,
    sanitize_referrer_display_status,
    sanitize_referrer_state_label,
    should_exclude_referrer_mission,
)


def test_sanitize_referrer_state_label_sensitive_next():
    assert sanitize_referrer_state_label("Next: Salary switched") == REFERRER_PHASE_FINAL_STEPS
    assert sanitize_referrer_state_label("Awaiting debit order setup") == REFERRER_PHASE_FINAL_STEPS


def test_sanitize_referrer_display_status_completed():
    assert (
        sanitize_referrer_display_status("anything", is_complete=True, progress_percent=50)
        == REFERRER_STATUS_COMPLETED
    )


def test_sanitize_referrer_display_status_masks_sensitive():
    assert (
        sanitize_referrer_display_status(
            "Pending debit order", is_complete=False, progress_percent=50
        )
        == REFERRER_STATUS_IN_PROGRESS
    )
    assert (
        sanitize_referrer_display_status(
            "Pending debit order", is_complete=False, progress_percent=80
        )
        == REFERRER_PHASE_FINAL_STEPS
    )


def test_should_exclude_referrer_mission():
    assert should_exclude_referrer_mission("Invite 3 friends", "INVITE_V1") is False
    assert should_exclude_referrer_mission("Help salary switch", "CAMP_SALARY") is True
    assert should_exclude_referrer_mission("Debit order bonus", "DEBIT_ORDER_X") is True


def test_format_referrer_milestone_for_display():
    assert format_referrer_milestone_for_display("Customer linked") == "Customer linked"
    assert format_referrer_milestone_for_display("ACCOUNT_OPENED") == "Account Opened"
    assert format_referrer_milestone_for_display("FUNDED") == "Funded"
    assert format_referrer_milestone_for_display("") == ""


def test_sanitize_mission_title_for_display():
    assert (
        sanitize_mission_title_for_display("Optional mission: first salary switch")
        == "First salary switch"
    )
    assert sanitize_mission_title_for_display("Optional mission — Foo bar") == "Foo bar"
    assert sanitize_mission_title_for_display("Already clean title") == "Already clean title"


def test_filter_referrer_missions():
    missions = [
        {"title": "Invite friends", "mission_code": "INV"},
        {"title": "Salary switch sprint", "mission_code": "S1"},
    ]
    out = filter_referrer_missions(missions)
    assert len(out) == 1
    assert out[0]["mission_code"] == "INV"
