from app.recommendation_renderer import render_recommendations


def test_render_recommendations_empty():
    out = render_recommendations({})
    assert out["primary"] is None
    assert out["secondary"] == []
    assert out["all"] == []


def test_render_recommendations_items_structure():
    raw = {
        "items": [
            {"action": "SEND_INVITE", "priorityScore": 0.9},
            {"actionCode": "CHECK_PROGRESS", "priority_score": 0.5},
        ]
    }
    out = render_recommendations(raw)
    assert out["primary"] is not None
    assert out["primary"]["action_code"] == "SEND_INVITE"
    assert len(out["secondary"]) == 1
    assert out["secondary"][0]["action_code"] == "CHECK_PROGRESS"
    assert len(out["all"]) == 2


def test_render_recommendations_primary_secondary_structure():
    raw = {
        "primaryAction": {"type": "SEND_INVITE"},
        "secondaryActions": [{"action": "CHECK_PROGRESS"}],
    }
    out = render_recommendations(raw)
    assert out["primary"]["action_code"] == "SEND_INVITE"
    assert len(out["secondary"]) == 1
    assert out["secondary"][0]["action_code"] == "CHECK_PROGRESS"


def test_render_recommendations_unknown_action_uses_default():
    raw = {"items": [{"action": "TOTALLY_UNKNOWN_CODE_XYZ"}]}
    out = render_recommendations(raw)
    assert out["primary"] is not None
    assert out["primary"]["title"]  # default catalogue entry has a title
    assert out["primary"]["action_code"] == "TOTALLY_UNKNOWN_CODE_XYZ"
