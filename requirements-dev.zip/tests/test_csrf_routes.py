import re

from fastapi.testclient import TestClient

from app.main import app


def _extract_csrf_token(html: str) -> str:
    m = re.search(r'name="csrf_token"\s+value="([^"]+)"', html)
    assert m, "CSRF token input not found in HTML"
    return m.group(1)


def test_admin_set_context_rejects_missing_csrf():
    client = TestClient(app)
    resp = client.post(
        "/admin",
        data={
            "ocep_ucn": "U1",
            "ocep_tenant": "FNB",
            "ocep_sticker": "EASY",
            "ocep_segment": "EASY",
        },
    )
    assert resp.status_code == 403


def test_admin_set_context_accepts_valid_csrf():
    client = TestClient(app)
    page = client.get("/admin")
    assert page.status_code == 200
    token = _extract_csrf_token(page.text)
    resp = client.post(
        "/admin",
        data={
            "csrf_token": token,
            "ocep_ucn": "U1",
            "ocep_tenant": "FNB",
            "ocep_sticker": "EASY",
            "ocep_segment": "EASY",
        },
        follow_redirects=False,
    )
    assert resp.status_code in (302, 303)


def test_refer_accept_rejects_missing_csrf():
    client = TestClient(app)
    # Seed OCEP context in session via admin flow first.
    admin = client.get("/admin")
    token = _extract_csrf_token(admin.text)
    client.post(
        "/admin",
        data={
            "csrf_token": token,
            "ocep_ucn": "U2",
            "ocep_tenant": "FNB",
            "ocep_sticker": "EASY",
            "ocep_segment": "EASY",
        },
        follow_redirects=False,
    )
    resp = client.post("/refer-and-earn/accept", data={"accept_terms": "on"}, follow_redirects=False)
    assert resp.status_code == 403
