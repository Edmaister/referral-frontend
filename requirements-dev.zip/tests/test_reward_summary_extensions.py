from app.services.referrer_rewards_service import fetch_referrer_rewards
from app.services.reward_explanation_service import fetch_reward_explanation
from app.services.reward_summary_extensions import normalize_reward_summary_extensions


def test_normalize_reward_summary_extensions_reads_potential_fields():
    ext = normalize_reward_summary_extensions(
        {
            "earnedAmount": 10,
            "potentialMaxAmount": 250,
            "potentialNarrative": " Max applies if all milestones complete.",
            "amountSemanticsVersion": "2026-04-01",
            "potentialBreakdown": [
                {"code": "BASE", "label": "Welcome", "amount": 100, "status": "EARNED"},
                {"code": "BONUS", "label": "Campaign", "amount": 150, "status": "POSSIBLE"},
            ],
        }
    )
    assert ext["potential_max_amount"] == 250.0
    assert "Max applies" in ext["potential_narrative"]
    assert ext["amount_semantics_version"] == "2026-04-01"
    assert len(ext["potential_breakdown"]) == 2
    assert ext["potential_breakdown"][1]["status"] == "POSSIBLE"


def test_fetch_referrer_rewards_merges_extensions():
    class _C:
        def get_referrer_reward_summary(self, ucn: str):
            return {
                "totals": {"earned": 1, "pending": 2, "totalPotential": 99},
                "potentialNarrative": "Narrative",
                "items": [],
            }

    import logging

    out = fetch_referrer_rewards(_C(), "U1", logging.getLogger("t"))
    assert out is not None
    assert out["potential_max_amount"] == 99.0
    assert out["potential_narrative"] == "Narrative"


def test_fetch_reward_explanation_extended_fields():
    class _C:
        def get_reward_explanation(self, rid: str):
            return {
                "reason": "Because",
                "amountStatus": "PENDING",
                "potentialCeiling": 500,
                "whatUnlocksMore": ["Finish step A"],
                "eligibilityNarrative": "You may qualify when rules are met.",
            }

    import logging

    out = fetch_reward_explanation(_C(), "r1", logging.getLogger("t"))
    assert out is not None
    assert out["amount_status"] == "PENDING"
    assert out["potential_ceiling"] == 500.0
    assert out["what_unlocks_more"] == ["Finish step A"]
    assert "qualify" in out["eligibility_narrative"]
