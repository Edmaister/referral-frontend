from app.services.referee_referral_view_service import normalize_referee_referral_view_payload
from app.services.referrer_referral_view_service import normalize_referrer_referral_view_payload


def test_normalize_referrer_referral_view_snake_case():
    raw = {
        "referral_track_id": "t-1",
        "progress": {
            "percent": "42",
            "display_status": "Active",
            "is_complete": "true",
            "completed_milestones": ["A", None, "B"],
            "remaining_state_label": "Next up",
        },
        "rewards": {"earned_amount": "10.5", "pending_amount": "2"},
    }
    out = normalize_referrer_referral_view_payload(raw, fallback_track_id="fallback")
    assert out is not None
    assert out["referral_track_id"] == "t-1"
    assert out["progress_percent"] == 42
    assert out["display_status"] == "Completed"
    assert out["referrer_status_headline"] == "Completed"
    assert out["referrer_status_detail"] == "Completed"
    assert out["is_complete"] is True
    assert out["completed_milestones"] == ["A", "B"]
    assert out["remaining_state_label"] == "Next up"
    assert out["rewards_earned"] == 10.5
    assert out["rewards_pending"] == 2.0


def test_normalize_referrer_referral_view_fallback_track_id():
    raw = {
        "progress": {},
        "rewards": {},
    }
    out = normalize_referrer_referral_view_payload(raw, fallback_track_id="tid-99")
    assert out is not None
    assert out["referral_track_id"] == "tid-99"
    assert out["display_status"] == "In progress"
    assert out["referrer_status_headline"] == "In progress"


def test_normalize_referrer_non_dict_returns_none():
    assert normalize_referrer_referral_view_payload(None) is None
    assert normalize_referrer_referral_view_payload([]) is None


def test_normalize_referee_referral_view_camel_case():
    raw = {
        "referralTrackId": "trk",
        "progress": {
            "percent": 55,
            "displayStatus": "On track",
            "isComplete": False,
            "completedMilestones": ["m1"],
            "pendingMilestones": ["m2"],
            "remainingStateLabel": "Finish",
        },
        "journey": {
            "currentMilestone": "m1",
            "nextMilestone": "m2",
            "conditions": ["c1"],
        },
        "rewards": {
            "earnedAmount": 1,
            "pendingAmount": 2,
            "potentialAmount": 3,
        },
    }
    out = normalize_referee_referral_view_payload(raw)
    assert out is not None
    assert out["referral_track_id"] == "trk"
    assert out["progress_percent"] == 55
    assert out["completed_milestones"] == ["m1"]
    assert out["pending_milestones"] == ["m2"]
    assert out["current_milestone"] == "m1"
    assert out["next_milestone"] == "m2"
    assert out["conditions"] == ["c1"]
    assert out["rewards_earned"] == 1.0
    assert out["rewards_pending"] == 2.0
    assert out["rewards_potential"] == 3.0


def test_normalize_referee_non_dict_returns_none():
    assert normalize_referee_referral_view_payload("x") is None
