from app.services.referrer_home_hero_service import (
    almost_there_body,
    almost_there_body_short,
    build_me_hero_context,
    portfolio_hero_momentum_line,
    rewards_still_available_amount,
    summarize_referral_portfolio,
)


def test_rewards_still_available_uses_ceiling_minus_earned():
    ov = {"earned": 120.0, "total_potential": 200.0, "pending": 10.0}
    assert rewards_still_available_amount(ov) == 80.0


def test_summarize_portfolio_counts_active_and_close():
    rows = [
        {"is_complete": False, "progressPercent": 75, "rewardsPendingAmount": 0},
        {"is_complete": False, "progressPercent": 30, "rewardsPendingAmount": 0},
        {"is_complete": True, "progressPercent": 100},
    ]
    s = summarize_referral_portfolio(rows)
    assert s["active_in_progress"] == 2
    assert s["close_to_reward"] == 1


def test_summarize_close_from_pending_not_percent():
    rows = [{"is_complete": False, "progressPercent": 20, "rewardsPendingAmount": 50.0}]
    s = summarize_referral_portfolio(rows)
    assert s["close_to_reward"] == 1


def test_portfolio_hero_line_close_one():
    line = portfolio_hero_momentum_line(
        1,
        2,
        next_eligible=0,
        still=0,
        fallback="x",
    )
    assert "1 referral" in line.lower()


def test_build_me_hero_has_no_stepper():
    ctx = build_me_hero_context(
        rewards_overview=None,
        tier_progress_percent=0,
        referrals_in_progress_count=0,
    )
    assert "stepper" not in ctx


def test_almost_there_body_plural():
    body = almost_there_body(2).lower()
    assert "2" in body
    assert "progressing" in body


def test_almost_there_body_short_plural():
    body = almost_there_body_short(2).lower()
    assert "2" in body
    assert "progressing" in body
