from app.services.error_service import api_error_message
from app.services.leaderboard_mapping_service import (
    leaderboard_generated_label,
    normalize_leaderboard_rows,
    normalize_my_leaderboard,
)
from app.services.referrer_code_service import (
    bootstrap_is_favorable,
    issue_shape_from_bootstrap,
)
from app.services.progress_ui_service import (
    finalize_progress_rows_for_ui,
    normalize_referrer_progress,
)


class _FakeResponse:
    def __init__(self, status_code=400, text="bad", payload=None):
        self.status_code = status_code
        self.text = text
        self._payload = payload or {}

    def json(self):
        return self._payload


class _FakeExc(Exception):
    def __init__(self, response):
        self.response = response


def test_api_error_message_uses_detail_message():
    exc = _FakeExc(_FakeResponse(payload={"detail": "boom"}))
    assert api_error_message(exc) == "boom"


def test_bootstrap_mapping_and_favorable():
    raw = {"referralCode": "ABC123", "acceptedTerms": True, "requiresTermsAcceptance": True}
    assert bootstrap_is_favorable(raw) is True
    shaped = issue_shape_from_bootstrap(raw)
    assert shaped["short_code"] == "ABC123"


def test_leaderboard_normalizers():
    raw = {
        "generatedAt": "2026-04-07T23:08:43.667536+00:00",
        "items": [{"displayName": "SwiftDragon74", "totalScore": 20, "rankPosition": 1}],
    }
    rows = normalize_leaderboard_rows(raw)
    assert rows and rows[0]["display_name"] == "SwiftDragon74"
    assert leaderboard_generated_label(raw) == "2026-04-07"
    my = normalize_my_leaderboard({"displayName": "Me", "rankPosition": 2, "totalScore": 10})
    assert my and my["rank"] == 2


def test_progress_normalizer_reads_nested_progress_object():
    raw = {
        "items": [
            {
                "referralTrackId": "nested-1",
                "alias": "Nested friend",
                "progress": {
                    "percent": 33,
                    "currentMilestone": "Halfway there",
                    "nextMilestone": "DONE_EVENT",
                },
            }
        ]
    }
    rows = normalize_referrer_progress(raw)
    assert len(rows) == 1
    assert rows[0]["progressPercent"] == 33
    assert rows[0]["currentMilestoneDisplay"] == "Halfway there"
    assert rows[0]["nextMilestoneDisplay"] == "Done Event"


def test_progress_normalizer_aligns_v1_referrers_milestone_fields():
    """Matches GET /v1/referrers item shape: progressPercent, currentMilestone, nextMilestone."""
    raw = {
        "items": [
            {
                "referralTrackId": "t-1",
                "refereeAlias": "BoldWolf67",
                "progressPercent": 20,
                "currentMilestone": "Customer linked",
                "nextMilestone": "ACCOUNT_OPENED",
                "lastUpdatedAt": "2026-04-10T00:00:00Z",
            }
        ]
    }
    rows = normalize_referrer_progress(raw)
    assert len(rows) == 1
    assert rows[0]["progressPercent"] == 20
    assert rows[0]["currentMilestoneDisplay"] == "Customer linked"
    assert rows[0]["nextMilestoneDisplay"] == "Account Opened"


def test_finalize_progress_rows_sets_snake_case_mirrors():
    rows = normalize_referrer_progress(
        {
            "items": [
                {
                    "referralTrackId": "t1",
                    "progressPercent": 20,
                    "currentMilestone": "Customer linked",
                    "nextMilestone": "ACCOUNT_OPENED",
                    "status": "UCN_CAPTURED",
                }
            ]
        }
    )
    finalize_progress_rows_for_ui(rows)
    r = rows[0]
    assert r["next_milestone"] == "ACCOUNT_OPENED"
    assert r["next_milestone_display"] == "Account Opened"


def test_progress_normalizer_maps_core_fields():
    raw = {
        "items": [
            {
                "referralCode": "ABC123",
                "referralTrackId": "track-1",
                "status": "accepted",
                "refereeAlias": "R",
                "progressPercent": 80,
                "currentMilestone": "ACCOUNT_OPENED",
                "nextMilestone": "FUNDED",
                "lastUpdatedAt": "2026-04-08T10:00:00Z",
            }
        ]
    }
    rows = normalize_referrer_progress(raw)
    assert len(rows) == 1
    assert rows[0]["referral_code"] == "ABC123"
    assert rows[0]["referral_track_id"] == "track-1"
    assert rows[0]["alias"] == "R"
    assert rows[0]["progressPercent"] == 80
    assert rows[0]["nextMilestone"] == "FUNDED"
    assert rows[0]["currentMilestoneDisplay"] == "Account Opened"
    assert rows[0]["nextMilestoneDisplay"] == "Funded"
    assert rows[0]["referrerStatusHeadline"] == "In progress"
    assert rows[0]["referrerStatusDetail"] == "Final steps in progress"
