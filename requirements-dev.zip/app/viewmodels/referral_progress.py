from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ReferralProgressViewModel:
    referral_track_id: str
    referral_code: str
    status: str
    progress_percent: int
    current_milestone: Optional[str]
    next_milestone: Optional[str]
    is_complete: bool
