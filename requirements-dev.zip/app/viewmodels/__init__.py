# ViewModel package for template-safe UI shapes.
