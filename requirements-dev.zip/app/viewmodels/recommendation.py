from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class RecommendationCardViewModel:
    code: str
    title: str
    body: str
    cta_label: Optional[str] = None
    cta_url: Optional[str] = None
