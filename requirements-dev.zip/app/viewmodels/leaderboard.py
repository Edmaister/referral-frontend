from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class LeaderboardRowViewModel:
    rank: int
    display_name: str
    value: float
    is_me: bool = False


@dataclass(frozen=True)
class LeaderboardViewModel:
    leaderboard_code: str
    generated_label: Optional[str]
