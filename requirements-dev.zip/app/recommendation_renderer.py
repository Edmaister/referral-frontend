"""
Recommendation Renderer

Transforms raw recommendation engine output into user-friendly UX components.
Keeps decisioning separate from experience design.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class CtaButton:
    label: str
    target: str
    type: str = "DEEPLINK"


@dataclass
class RenderedRecommendation:
    """The final UX-ready recommendation to display."""
    action_code: str
    placement: str
    component: str
    visual_style: str
    title: str
    body: str
    cta: CtaButton
    secondary_cta: Optional[CtaButton] = None
    icon: str = "star"
    emoji: str = "✨"
    dismissible: bool = True
    priority: float = 0.0
    confidence: float = 0.0
    family: str = "GENERAL"
    audience: str = "BOTH"
    reason_codes: List[str] = field(default_factory=list)
    recommendation_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_code": self.action_code,
            "placement": self.placement,
            "component": self.component,
            "visual_style": self.visual_style,
            "title": self.title,
            "body": self.body,
            "cta": {"label": self.cta.label, "target": self.cta.target, "type": self.cta.type},
            "secondary_cta": {"label": self.secondary_cta.label, "target": self.secondary_cta.target} if self.secondary_cta else None,
            "icon": self.icon,
            "emoji": self.emoji,
            "dismissible": self.dismissible,
            "priority": self.priority,
            "confidence": self.confidence,
            "family": self.family,
            "audience": self.audience,
            "reason_codes": self.reason_codes,
            "recommendation_id": self.recommendation_id,
        }


# =============================================================================
# ACTION CATALOGUE
# =============================================================================
# Maps action codes to UX treatments. This is the central source of truth
# for how each recommendation type should be displayed.

ACTION_CATALOGUE: Dict[str, Dict[str, Any]] = {
    # =========================================================================
    # A. REFERRER GROWTH ACTIONS
    # =========================================================================
    "SEND_INVITE": {
        "family": "REFERRER_GROWTH",
        "audience": "REFERRER",
        "component": "primary_nudge_card",
        "placement": "top_of_home",
        "icon": "share",
        "emoji": "🔥",
        "tone": "motivational",
        "title": "You're on a roll!",
        "body": "Keep your referral momentum going and invite another friend.",
        "cta_label": "Invite now",
        "deeplink": "/referrals/invite",
        "secondary_cta_label": "View rewards",
        "secondary_deeplink": "/rewards",
    },
    "SHARE_REFERRAL_LINK": {
        "family": "REFERRER_GROWTH",
        "audience": "REFERRER",
        "component": "inline_share_card",
        "placement": "mid_home",
        "icon": "link",
        "emoji": "🔗",
        "tone": "helpful",
        "title": "Share your referral link",
        "body": "Send your referral link to friends and start earning rewards.",
        "cta_label": "Share link",
        "deeplink": "/referrals/share",
    },
    "RESHARE_TO_PENDING_CONTACT": {
        "family": "REFERRER_GROWTH",
        "audience": "REFERRER",
        "component": "follow_up_card",
        "placement": "top_of_home",
        "icon": "refresh",
        "emoji": "📬",
        "tone": "encouraging",
        "title": "A few friends haven't completed yet",
        "body": "Follow up with people you already referred and help them finish.",
        "cta_label": "Send reminder",
        "deeplink": "/referrals/pending",
    },
    "REFER_ANOTHER_FRIEND": {
        "family": "REFERRER_GROWTH",
        "audience": "REFERRER",
        "component": "celebration_action_card",
        "placement": "top_of_home",
        "icon": "users",
        "emoji": "🎉",
        "tone": "celebratory",
        "title": "Nice one — ready for the next?",
        "body": "Your last referral is progressing. Invite another friend to keep earning.",
        "cta_label": "Refer another",
        "deeplink": "/referrals/invite",
    },
    "COMPLETE_REFERRER_PROFILE": {
        "family": "REFERRER_GROWTH",
        "audience": "REFERRER",
        "component": "setup_card",
        "placement": "settings",
        "icon": "user-check",
        "emoji": "📋",
        "tone": "administrative",
        "title": "Complete your referral setup",
        "body": "Add the missing details needed to track and pay your rewards.",
        "cta_label": "Complete setup",
        "deeplink": "/profile/referral-setup",
    },
    "SELECT_REFERRAL_CHANNEL": {
        "family": "REFERRER_GROWTH",
        "audience": "REFERRER",
        "component": "action_sheet",
        "placement": "modal",
        "icon": "share-2",
        "emoji": "📤",
        "tone": "helpful",
        "title": "Choose how to share",
        "body": "Share your referral in the way you prefer.",
        "cta_label": "WhatsApp",
        "deeplink": "/referrals/share/whatsapp",
        "secondary_cta_label": "Copy link",
        "secondary_deeplink": "/referrals/share/copy",
    },
    "JOIN_REFERRAL_CHALLENGE": {
        "family": "REFERRER_GROWTH",
        "audience": "REFERRER",
        "component": "campaign_card",
        "placement": "top_of_home",
        "icon": "trophy",
        "emoji": "🏆",
        "tone": "exciting",
        "title": "Join this week's referral challenge",
        "body": "Refer friends this week and unlock bonus rewards.",
        "cta_label": "Join challenge",
        "deeplink": "/challenges/current",
    },

    # =========================================================================
    # B. REFEREE CONVERSION ACTIONS
    # =========================================================================
    "START_APPLICATION": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "primary_conversion_card",
        "placement": "top_of_landing",
        "icon": "play",
        "emoji": "🚀",
        "tone": "action",
        "title": "Your offer is ready",
        "body": "Start your application to open your account and unlock your referral benefits.",
        "cta_label": "Start application",
        "deeplink": "/onboarding/start",
    },
    "RESUME_APPLICATION": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "sticky_resume_card",
        "placement": "top_of_home",
        "icon": "play-circle",
        "emoji": "▶️",
        "tone": "action",
        "title": "Pick up where you left off",
        "body": "Your application is waiting. Finish it in a few steps.",
        "cta_label": "Resume application",
        "deeplink": "/onboarding/resume",
    },
    "COMPLETE_KYC": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "blocking_task_card",
        "placement": "top_of_home",
        "icon": "shield-check",
        "emoji": "🔐",
        "tone": "task",
        "title": "Verify your details",
        "body": "Complete your verification to continue opening your account.",
        "cta_label": "Verify now",
        "deeplink": "/kyc/verify",
    },
    "OPEN_ACCOUNT": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "product_offer_card",
        "placement": "top_of_home",
        "icon": "credit-card",
        "emoji": "💳",
        "tone": "action",
        "title": "Open your account",
        "body": "Continue to open your account and start banking.",
        "cta_label": "Open account",
        "deeplink": "/accounts/open",
    },
    "ACTIVATE_ACCOUNT": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "next_step_card",
        "placement": "top_of_home",
        "icon": "zap",
        "emoji": "⚡",
        "tone": "action",
        "title": "Activate your account",
        "body": "One more step to unlock your account and rewards.",
        "cta_label": "Activate now",
        "deeplink": "/accounts/activate",
    },
    "FUND_ACCOUNT": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "progression_card",
        "placement": "mid_home",
        "icon": "dollar-sign",
        "emoji": "💰",
        "tone": "encouraging",
        "title": "Add money to get started",
        "body": "Fund your account to complete the next step in your journey.",
        "cta_label": "Fund account",
        "deeplink": "/accounts/fund",
    },
    "LINK_CARD": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "setup_card",
        "placement": "mid_home",
        "icon": "credit-card",
        "emoji": "💳",
        "tone": "task",
        "title": "Link your card",
        "body": "Add your card to complete setup and start using your account.",
        "cta_label": "Link card",
        "deeplink": "/cards/link",
    },
    "SET_PIN": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "task_completion_card",
        "placement": "mid_home",
        "icon": "lock",
        "emoji": "🔑",
        "tone": "task",
        "title": "Set your PIN",
        "body": "Set your card PIN so your account is ready to use.",
        "cta_label": "Set PIN",
        "deeplink": "/cards/set-pin",
    },
    "USE_CARD": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "activation_nudge_card",
        "placement": "top_of_home",
        "icon": "shopping-bag",
        "emoji": "🛍️",
        "tone": "informational",
        "title": "Card activation",
        "body": "If your product includes a card, you may complete activation when you are ready.",
        "cta_label": "Learn more",
        "deeplink": "/cards/first-use",
    },
    "SWITCH_DEBIT_ORDER": {
        "family": "REFEREE_CONVERSION",
        "audience": "REFEREE",
        "component": "benefit_card",
        "placement": "mid_home",
        "icon": "repeat",
        "emoji": "🔄",
        "tone": "informational",
        "title": "Day-to-day banking setup",
        "body": "If it suits your situation, you may move debit orders as part of onboarding. Conditions apply—this is not advice.",
        "cta_label": "View details",
        "deeplink": "/debit-orders/switch",
    },

    # =========================================================================
    # C. REWARD AND ENGAGEMENT ACTIONS
    # =========================================================================
    "VIEW_REWARD_STATUS": {
        "family": "REWARD",
        "audience": "BOTH",
        "component": "rewards_wallet_card",
        "placement": "rewards_area",
        "icon": "gift",
        "emoji": "🎁",
        "tone": "informational",
        "title": "Track your rewards",
        "body": "See what you've earned and what's still in progress.",
        "cta_label": "View rewards",
        "deeplink": "/rewards",
    },
    "CLAIM_REWARD": {
        "family": "REWARD",
        "audience": "BOTH",
        "component": "celebration_card",
        "placement": "top_of_home",
        "icon": "gift",
        "emoji": "🎊",
        "tone": "celebratory",
        "title": "Your reward is ready!",
        "body": "You've unlocked a reward — claim it now.",
        "cta_label": "Claim reward",
        "deeplink": "/rewards/claim",
    },
    "VIEW_PROGRESS": {
        "family": "REWARD",
        "audience": "BOTH",
        "component": "progress_tracker_card",
        "placement": "mid_home",
        "icon": "bar-chart",
        "emoji": "📊",
        "tone": "informational",
        "title": "See your progress",
        "body": "Track where you are and what's left to complete.",
        "cta_label": "View progress",
        "deeplink": "/progress",
    },
    "UNLOCK_BONUS": {
        "family": "REWARD",
        "audience": "BOTH",
        "component": "milestone_card",
        "placement": "top_of_home",
        "icon": "star",
        "emoji": "⭐",
        "tone": "motivational",
        "title": "One more step to unlock a bonus",
        "body": "Complete the next action to unlock an extra reward.",
        "cta_label": "Unlock bonus",
        "deeplink": "/rewards/bonus",
    },
    "REDEEM_EWALLET": {
        "family": "REWARD",
        "audience": "BOTH",
        "component": "wallet_payout_card",
        "placement": "top_of_home",
        "icon": "wallet",
        "emoji": "💵",
        "tone": "celebratory",
        "title": "Your eWallet reward is available",
        "body": "Redeem your reward and use it right away.",
        "cta_label": "Redeem now",
        "deeplink": "/rewards/redeem",
    },
    "VIEW_STREAK": {
        "family": "REWARD",
        "audience": "REFERRER",
        "component": "gamified_widget",
        "placement": "mid_home",
        "icon": "flame",
        "emoji": "🔥",
        "tone": "gamified",
        "title": "Your referral streak is live",
        "body": "Keep going to grow your streak and unlock more value.",
        "cta_label": "View streak",
        "deeplink": "/streaks",
    },
    "VIEW_LEADERBOARD": {
        "family": "REWARD",
        "audience": "REFERRER",
        "component": "leaderboard_card",
        "placement": "mid_home",
        "icon": "award",
        "emoji": "🏅",
        "tone": "competitive",
        "title": "See how you rank",
        "body": "Check your position and keep climbing the leaderboard.",
        "cta_label": "View leaderboard",
        "deeplink": "/me#leaderboard",
    },

    # =========================================================================
    # D. RETENTION AND RECOVERY ACTIONS
    # =========================================================================
    "REMIND_PENDING_REFEREE": {
        "family": "RETENTION",
        "audience": "REFERRER",
        "component": "follow_up_card",
        "placement": "top_of_home",
        "icon": "bell",
        "emoji": "🔔",
        "tone": "helpful",
        "title": "Someone you referred is still in progress",
        "body": "Send a reminder to help them finish their journey.",
        "cta_label": "Remind them",
        "deeplink": "/referrals/remind",
    },
    "NUDGE_INCOMPLETE_APPLICATION": {
        "family": "RETENTION",
        "audience": "REFEREE",
        "component": "resume_banner",
        "placement": "top_of_home",
        "icon": "alert-circle",
        "emoji": "📝",
        "tone": "helpful",
        "title": "Finish your application",
        "body": "You're partway there — complete the last few steps.",
        "cta_label": "Continue",
        "deeplink": "/onboarding/resume",
    },
    "RECOVER_DROPPED_FUNNEL": {
        "family": "RETENTION",
        "audience": "BOTH",
        "component": "reactivation_card",
        "placement": "top_of_home",
        "icon": "arrow-right",
        "emoji": "👋",
        "tone": "welcoming",
        "title": "Ready to continue?",
        "body": "Come back and finish your referral journey when it suits you.",
        "cta_label": "Continue now",
        "deeplink": "/resume",
    },
    "RETRY_FAILED_STEP": {
        "family": "RETENTION",
        "audience": "BOTH",
        "component": "error_recovery_card",
        "placement": "top_of_home",
        "icon": "refresh-cw",
        "emoji": "🔄",
        "tone": "reassuring",
        "title": "Something needs another try",
        "body": "One of your steps didn't go through. Retry to continue.",
        "cta_label": "Retry",
        "deeplink": "/retry",
    },
    "UPDATE_EXPIRED_DETAILS": {
        "family": "RETENTION",
        "audience": "BOTH",
        "component": "compliance_card",
        "placement": "top_of_home",
        "icon": "alert-triangle",
        "emoji": "⚠️",
        "tone": "urgent",
        "title": "Update your details",
        "body": "Some information needs to be refreshed before you can continue.",
        "cta_label": "Update now",
        "deeplink": "/profile/update",
    },
    "REENGAGE_DORMANT_REFERRER": {
        "family": "RETENTION",
        "audience": "REFERRER",
        "component": "comeback_card",
        "placement": "top_of_home",
        "icon": "heart",
        "emoji": "💚",
        "tone": "welcoming",
        "title": "Start earning from referrals again",
        "body": "It's been a while — invite friends again and get back into the rewards flow.",
        "cta_label": "Start again",
        "deeplink": "/referrals/invite",
    },

    # =========================================================================
    # E. OPERATIONAL / SUPPORT ACTIONS
    # =========================================================================
    "CONTACT_SUPPORT": {
        "family": "SUPPORT",
        "audience": "BOTH",
        "component": "support_card",
        "placement": "footer",
        "icon": "message-circle",
        "emoji": "💬",
        "tone": "reassuring",
        "title": "Need help?",
        "body": "We can help you finish your referral or account journey.",
        "cta_label": "Contact support",
        "deeplink": "/support",
    },
    "VERIFY_DETAILS": {
        "family": "SUPPORT",
        "audience": "BOTH",
        "component": "verification_card",
        "placement": "top_of_home",
        "icon": "user-check",
        "emoji": "✅",
        "tone": "task",
        "title": "We need to verify something",
        "body": "Check your details so we can continue processing your journey.",
        "cta_label": "Verify details",
        "deeplink": "/verify",
    },
    "RESOLVE_DUPLICATE_REFERRAL": {
        "family": "SUPPORT",
        "audience": "BOTH",
        "component": "exception_card",
        "placement": "top_of_home",
        "icon": "copy",
        "emoji": "📋",
        "tone": "informational",
        "title": "We found an existing referral",
        "body": "Review the referral details to continue correctly.",
        "cta_label": "Review referral",
        "deeplink": "/referrals/review",
    },
    "CHECK_ELIGIBILITY": {
        "family": "SUPPORT",
        "audience": "BOTH",
        "component": "eligibility_card",
        "placement": "mid_home",
        "icon": "check-circle",
        "emoji": "🔍",
        "tone": "informational",
        "title": "Check if you qualify",
        "body": "Review the requirements before continuing.",
        "cta_label": "Check eligibility",
        "deeplink": "/eligibility",
    },
    "VIEW_TERMS": {
        "family": "SUPPORT",
        "audience": "BOTH",
        "component": "secondary_link",
        "placement": "footer",
        "icon": "file-text",
        "emoji": "📄",
        "tone": "neutral",
        "title": "Campaign rules and terms",
        "body": "Review the important details about eligibility and rewards.",
        "cta_label": "View terms",
        "deeplink": "/terms",
    },
    "ESCALATE_CASE": {
        "family": "SUPPORT",
        "audience": "BOTH",
        "component": "status_card",
        "placement": "top_of_home",
        "icon": "clock",
        "emoji": "⏳",
        "tone": "reassuring",
        "title": "We're reviewing this for you",
        "body": "Your case needs a manual review before we can continue.",
        "cta_label": "View status",
        "deeplink": "/cases/status",
    },
    "MANUAL_REVIEW_REQUIRED": {
        "family": "SUPPORT",
        "audience": "BOTH",
        "component": "status_card",
        "placement": "top_of_home",
        "icon": "eye",
        "emoji": "👁️",
        "tone": "reassuring",
        "title": "Your referral is being reviewed",
        "body": "We're checking a few details. We'll update you once it's complete.",
        "cta_label": "View progress",
        "deeplink": "/review/status",
    },
}

# Default fallback for unknown actions
DEFAULT_ACTION = {
    "family": "GENERAL",
    "audience": "BOTH",
    "component": "info_card",
    "placement": "mid_home",
    "icon": "info",
    "emoji": "ℹ️",
    "tone": "informational",
    "title": "Recommendation",
    "body": "Here's something that might help you.",
    "cta_label": "Learn more",
    "deeplink": "/",
}


# =============================================================================
# RENDERER FUNCTIONS
# =============================================================================

def get_confidence_placement(confidence: float) -> str:
    """Map confidence score to placement priority."""
    if confidence >= 0.80:
        return "hero"
    elif confidence >= 0.60:
        return "top_of_home"
    elif confidence >= 0.40:
        return "mid_home"
    else:
        return "suggestions"


def render_single_action(
    action_code: str,
    confidence: float = 0.5,
    priority_score: float = 0.5,
    reason: Optional[str] = None,
    reason_codes: Optional[List[str]] = None,
    audience: Optional[str] = None,
    recommendation_id: Optional[str] = None,
    meta: Optional[Dict[str, Any]] = None,
) -> RenderedRecommendation:
    """
    Transform a single recommendation action into a UX-ready object.
    """
    catalogue_entry = ACTION_CATALOGUE.get(action_code, DEFAULT_ACTION)
    
    # Override placement based on confidence
    placement = catalogue_entry.get("placement", "mid_home")
    if confidence >= 0.80:
        placement = "top_of_home"
    
    # Build CTA
    cta = CtaButton(
        label=catalogue_entry.get("cta_label", "Continue"),
        target=catalogue_entry.get("deeplink", "/"),
        type="DEEPLINK",
    )
    
    # Build secondary CTA if available
    secondary_cta = None
    if catalogue_entry.get("secondary_cta_label"):
        secondary_cta = CtaButton(
            label=catalogue_entry["secondary_cta_label"],
            target=catalogue_entry.get("secondary_deeplink", "/"),
            type="DEEPLINK",
        )
    
    # Determine visual style from tone
    tone_to_style = {
        "motivational": "motivational",
        "celebratory": "celebratory",
        "action": "action-oriented",
        "task": "task-oriented",
        "helpful": "helpful",
        "encouraging": "encouraging",
        "informational": "informational",
        "reassuring": "reassuring",
        "urgent": "urgent",
        "welcoming": "welcoming",
        "gamified": "gamified",
        "competitive": "competitive",
        "value": "value-led",
        "neutral": "neutral",
        "administrative": "administrative",
        "exciting": "exciting",
    }
    visual_style = tone_to_style.get(catalogue_entry.get("tone", "neutral"), "neutral")
    
    # Build body - use reason if provided and meaningful
    body = catalogue_entry.get("body", "")
    if reason and len(reason) > 10:
        body = reason
    
    return RenderedRecommendation(
        action_code=action_code,
        placement=placement,
        component=catalogue_entry.get("component", "info_card"),
        visual_style=visual_style,
        title=catalogue_entry.get("title", "Recommendation"),
        body=body,
        cta=cta,
        secondary_cta=secondary_cta,
        icon=catalogue_entry.get("icon", "star"),
        emoji=catalogue_entry.get("emoji", "✨"),
        dismissible=True,
        priority=priority_score,
        confidence=confidence,
        family=catalogue_entry.get("family", "GENERAL"),
        audience=audience or catalogue_entry.get("audience", "BOTH"),
        reason_codes=reason_codes or [],
        recommendation_id=recommendation_id,
    )


def render_recommendations(raw_response: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transform the raw recommendations API response into UX-ready format.
    
    Handles various response structures:
    - { "items": [...] }
    - { "primaryAction": {...}, "secondaryActions": [...] }
    - { "recommendations": [...] }
    - Direct list of actions
    """
    rendered = {
        "primary": None,
        "secondary": [],
        "all": [],
        "raw": raw_response,
    }
    
    if not raw_response:
        return rendered
    
    actions_to_render = []
    
    # Handle different response structures
    if "primaryAction" in raw_response:
        # Structure: { primaryAction: {...}, secondaryActions: [...] }
        primary = raw_response["primaryAction"]
        actions_to_render.append(("primary", primary))
        for sec in raw_response.get("secondaryActions", []):
            actions_to_render.append(("secondary", sec))
    
    elif "items" in raw_response and isinstance(raw_response["items"], list):
        # Structure: { items: [...] }
        for i, item in enumerate(raw_response["items"]):
            role = "primary" if i == 0 else "secondary"
            actions_to_render.append((role, item))
    
    elif "recommendations" in raw_response and isinstance(raw_response["recommendations"], list):
        # Structure: { recommendations: [...] }
        for i, item in enumerate(raw_response["recommendations"]):
            role = "primary" if i == 0 else "secondary"
            actions_to_render.append((role, item))
    
    elif isinstance(raw_response, list):
        # Direct list
        for i, item in enumerate(raw_response):
            role = "primary" if i == 0 else "secondary"
            actions_to_render.append((role, item))
    
    else:
        # Try to extract any action-like fields
        for key in ["action", "actionCode", "action_code", "type"]:
            if key in raw_response:
                actions_to_render.append(("primary", raw_response))
                break
    
    # Render each action
    for role, action_data in actions_to_render:
        if not isinstance(action_data, dict):
            continue
        
        # Extract action code from various field names
        action_code = (
            action_data.get("action")
            or action_data.get("actionCode")
            or action_data.get("action_code")
            or action_data.get("type")
            or action_data.get("recommendationType")
            or "UNKNOWN"
        )
        
        rendered_action = render_single_action(
            action_code=action_code,
            confidence=action_data.get("confidence", 0.5),
            priority_score=action_data.get("priorityScore", action_data.get("priority_score", 0.5)),
            reason=action_data.get("reason", action_data.get("message")),
            reason_codes=action_data.get("reasonCodes", action_data.get("reason_codes", [])),
            audience=action_data.get("audience"),
            recommendation_id=action_data.get("id", action_data.get("recommendation_id")),
            meta=action_data.get("meta"),
        )
        
        rendered["all"].append(rendered_action.to_dict())
        
        if role == "primary" and rendered["primary"] is None:
            rendered["primary"] = rendered_action.to_dict()
        else:
            rendered["secondary"].append(rendered_action.to_dict())
    
    # Sort secondary by priority
    rendered["secondary"].sort(key=lambda x: x.get("priority", 0), reverse=True)
    
    return rendered


def get_action_info(action_code: str) -> Dict[str, Any]:
    """Get the catalogue entry for a specific action code."""
    return ACTION_CATALOGUE.get(action_code, DEFAULT_ACTION).copy()


def list_actions_by_family(family: str) -> List[str]:
    """List all action codes in a given family."""
    return [
        code for code, entry in ACTION_CATALOGUE.items()
        if entry.get("family") == family
    ]


def list_actions_by_audience(audience: str) -> List[str]:
    """List all action codes for a given audience (REFERRER, REFEREE, BOTH)."""
    return [
        code for code, entry in ACTION_CATALOGUE.items()
        if entry.get("audience") == audience or entry.get("audience") == "BOTH"
    ]
