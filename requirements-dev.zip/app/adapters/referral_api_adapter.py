from __future__ import annotations

from typing import Any, Dict, Optional

from referral_client import ReferralApiClient


class ReferralApiAdapter:
    """
    App-level HTTP boundary to the referral backend.

    ``ReferralApiClient`` is constructed in ``app.bootstrap`` with
    ``timeout_seconds`` from ``REFERRAL_API_TIMEOUT_SECONDS`` (environment
    variable ``REFERRAL_API_TIMEOUT_SECONDS``, default 10 seconds, clamped 1–120).
    This wrapper keeps routers/services on a stable adapter surface.
    """

    def __init__(self, client: ReferralApiClient):
        self._client = client

    def __getattr__(self, name: str):
        return getattr(self._client, name)

    def get_referrer_progress(self, referrer_ucn: str) -> Dict[str, Any]:
        return self._client.get_referrer_progress(referrer_ucn)

    def get_referrer_summary(self, referrer_ucn: str) -> Dict[str, Any]:
        """GET /v1/referrers/{referrer_ucn} summary + item list."""
        return self._client._get(f"/v1/referrers/{referrer_ucn}").json()

    def get_my_leaderboard_position(self, leaderboard_code: str, referrer_ucn: str) -> Dict[str, Any]:
        return self._client.get_my_leaderboard_position(leaderboard_code, referrer_ucn)

    def get_leaderboard(
        self,
        leaderboard_code: str,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        return self._client.get_leaderboard(leaderboard_code, limit=limit, offset=offset)

    def my_recommendations(
        self,
        *,
        referrer_hash: str,
        sticker: str,
        tenant: Optional[str] = None,
        top_k: int = 3,
        subject_role: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self._client.my_recommendations(
            referrer_hash=referrer_hash,
            sticker=sticker,
            tenant=tenant,
            top_k=top_k,
            subject_role=subject_role,
        )

    # Phase 2 persona-safe UX views -----------------------------------

    def get_referrer_dashboard(self, referrer_ucn: str) -> Dict[str, Any]:
        return self._client._get(f"/v1/referrers/{referrer_ucn}/dashboard").json()

    def get_referrer_referral_view(self, referral_track_id: str) -> Dict[str, Any]:
        path = f"/v1/referrals/{referral_track_id}/referrer-view"
        return self._client._get(path).json()

    def get_referrer_missions(self, referrer_ucn: str) -> Dict[str, Any]:
        return self._client._get(f"/v1/missions/referrer/{referrer_ucn}").json()

    def get_referee_dashboard(self, referral_track_id: str) -> Dict[str, Any]:
        return self._client._get(f"/v1/dashboard/referee/{referral_track_id}").json()

    def get_referee_referral_view(self, referral_track_id: str) -> Dict[str, Any]:
        path = f"/v1/referrals/{referral_track_id}/referee-view"
        return self._client._get(path).json()

    def get_referee_rewards(self, referral_track_id: str) -> Dict[str, Any]:
        """
        GET ``/v1/rewards/referee/{referralTrackId}``.

        Same **recommended** ``summary`` fields as referrer persona reward summaries so referee
        “you may qualify for up to …” strings can be backed by ``potentialMaxAmount``
        and ``potentialNarrative`` instead of UI guesswork.
        """
        return self._client._get(f"/v1/rewards/referee/{referral_track_id}").json()

    def get_reward_explanation(self, reward_id: str) -> Dict[str, Any]:
        """
        GET ``/v1/rewards/{rewardId}/explanation``.

        **Recommended** extras for explainability:

        - ``amountStatus`` — ``EARNED`` | ``PENDING`` | ``FORFEITED`` | ``NOT_ELIGIBLE`` | …
        - ``potentialCeiling`` *(optional)* — max this reward line could reach if conditions met.
        - ``whatUnlocksMore`` / ``pathToMax`` *(optional)* — string list of remaining drivers.
        - ``eligibilityNarrative`` *(optional)* — ties conditions to amounts in plain language.
        """
        return self._client._get(f"/v1/rewards/{reward_id}/explanation").json()
