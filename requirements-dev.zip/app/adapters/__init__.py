# Adapter package for backend integrations.
