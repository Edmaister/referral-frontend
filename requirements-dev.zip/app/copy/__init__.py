"""Approved UX copy and helpers — use to avoid risky language in persona-safe surfaces."""
