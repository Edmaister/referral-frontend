"""
Formal copy standard for referral UX (persona-safe surfaces).

Keep user-facing strings here so product/legal can review one place.
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

# --- Referrer home / rewards (persona-safe, high-clarity) ---
PROGRESS_HERO_TITLE = "Your referral progress"
REFERRALS_OVERVIEW_TITLE = "Your rewards"
ENGINE_HERO_EYEBROW = "Your reward engine"
REWARDS_CTA_VIEW_BREAKDOWN = "See reward breakdown"
CTA_TRACK_PROGRESS = "Track progress"
CTA_SEE_TIER_BENEFITS = "View tier benefits"
FOOTER_REFER_AND_EARN = "Refer a friend"
FOOTER_MY_REFERRALS = "View my referrals"
PORTFOLIO_CLOSE_ONE = (
    "1 referral is progressing toward the next reward milestone."
)
PORTFOLIO_CLOSE_MANY = (
    "{n} referrals are progressing toward the next reward milestone."
)
PORTFOLIO_ACTIVE_PROGRESS_ONE = (
    "1 referral is in progress toward your next reward milestone."
)
PORTFOLIO_ACTIVE_PROGRESS_MANY = (
    "{n} referrals are in progress toward your next reward milestone."
)
MOMENTUM_ALMOST_BODY_ONE = (
    "1 referral is progressing toward the next reward milestone."
)
MOMENTUM_ALMOST_BODY_MANY = (
    "{n} referrals are progressing toward the next reward milestone."
)
TIER_TOP_UNLOCKED = "Top tier unlocked — every tier benefit is available."
REWARDS_MICRO_COMPLIANCE_PROGRESS = (
    "Rewards are applied once qualifying actions are completed."
)
GLOBAL_REWARDS_DISCLAIMER = (
    "Rewards are applied based on qualifying actions. "
    "This information is provided for general guidance and does not constitute financial advice."
)
REWARDS_EARNED_SUBTEXT = "From completed referral milestones"
REWARDS_STILL_AVAILABLE_LABEL = "Still available"
REWARDS_STILL_AVAILABLE_SUBTEXT = "Based on qualifying actions"
REWARDS_COMPLIANCE_NO_ACTION_REQUIRED = (
    "Rewards are applied based on qualifying actions. No action is required from you."
)
REWARDS_SECTION_HOW_BUILT = "How your rewards are built"
MOMENTUM_CARD_TITLE = "In progress"
MOMENTUM_CARD_SUB = "Reward applies when qualifying actions are completed."
MOMENTUM_CARD_PROGRESS_SUB = (
    "Progress updates when qualifying requirements are met."
)
OVERVIEW_LABEL_EARNED = "Earned"
OVERVIEW_HERO_EYEBROW = "Your rewards"
OVERVIEW_HERO_LINE_PENDING = "{amt} available now"
OVERVIEW_HERO_LINE_UP_TO = "Up to {amt} may be earned next"
OVERVIEW_HERO_EXPANSION_LINE_ONE = "Your first referral is complete."
OVERVIEW_HERO_EXPANSION_LINE_TWO = "Refer more to unlock additional rewards."
OVERVIEW_FOOTER_MY_REFERRALS_SHORT = "My referrals"
CTA_VIEW_TIER_BENEFITS_SHORT = "View benefits"
OVERVIEW_STAT_REFERRALS = "Referrals"
OVERVIEW_STAT_COMPLETE = "Completed"
OVERVIEW_STAT_BONUSES = "Oppertunities"
OVERVIEW_STAT_TIER = "Tier"
OVERVIEW_GROWTH_HINT = "Each new referral unlocks new reward opportunities."
OVERVIEW_SECONDARY_TRACK = "Track progress"
OVERVIEW_TIER_ENCOURAGEMENT_START = "Every completed referral moves you forward."
OVERVIEW_TIER_METER_EMPTY = "Progress appears here as referrals complete."
MOMENTUM_CARD_HEADLINE_DISPLAY = "In progress"
MOMENTUM_CARD_HEADLINE_NO_ACTIVE = "No active referrals"
MOMENTUM_CARD_BODY_SHORT_ONE = "1 referral is progressing toward the next milestone."
MOMENTUM_CARD_BODY_SHORT_MANY = (
    "{n} referrals are progressing toward the next milestone."
)
MOMENTUM_CARD_BODY_NO_ACTIVE = (
    "You currently have no referrals in progress. New referrals will appear here as they progress."
)
OVERVIEW_AVAILABLE_NOW_LABEL = "available now"
OVERVIEW_UP_TO_NEXT_MAY_BE_EARNED = "Up to {sym}{amt} may be earned next"
OVERVIEW_STRIP_REFERRALS_ONE = "1 referral"
OVERVIEW_STRIP_REFERRALS_MANY = "{n} referrals"
OVERVIEW_STRIP_COMPLETE = "{n} complete"
OVERVIEW_STRIP_OPPORTUNITIES_ONE = "1 opportunity"
OVERVIEW_STRIP_OPPORTUNITIES_MANY = "{n} opportunities"
OVERVIEW_STRIP_TIER_FMT = "{tier}"
OVERVIEW_TIER_NEXT_HEADING = "Next tier: {name}"
OVERVIEW_TIER_CURRENT_HEADING = "Your tier: {name}"
OVERVIEW_TIER_PROGRESS_LINE = (
    "Programme progress is about {n}% toward the next tier."
)
MISSIONS_LANDING_SECTION_TITLE = "Bonus opportunities"
MISSION_LANDING_EARN_UPTO = "Earn up to {sym}{amt}"
MISSION_LANDING_STATUS_NOT_YET = "Not yet completed"
MISSION_LANDING_STATUS_COMPLETED = "Completed"
MISSION_LANDING_VIEW_DETAILS = "View details"
OVERVIEW_MOMENTUM_NEXT_POSSIBLE = (
    "Further amounts may become available when qualifying actions are completed."
)
OVERVIEW_MOMENTUM_STILL_BUILDING = (
    "Additional rewards may apply when programme conditions are met."
)
OVERVIEW_HERO_FALLBACK_SHARE = (
    "Share your referral code so friends can join the programme on their own terms."
)
OVERVIEW_HERO_FALLBACK_HIGH_TIER = (
    "Further rewards may apply when qualifying actions are completed."
)
OVERVIEW_HERO_FALLBACK_IN_FLIGHT = (
    "Referrals are in progress; rewards apply when qualifying steps are completed."
)
MISSIONS_PAGE_TITLE = "Boost your rewards"
MISSIONS_SECTION_HEADING = "Boost your rewards (optional)"
MISSIONS_NAV_TAB = "Boost rewards"
MISSIONS_NAV_TAB_ARIA = "Boost your rewards (optional)"
MISSIONS_BONUS_SECTION_DISCLAIMER = (
    "Bonus rewards are applied once qualifying actions are completed."
)
MISSION_CARD_BODY_DEFAULT = (
    "You may qualify for a bonus if this action is completed successfully."
)
CREDIT_RELATED_DISCLAIMER = "Subject to approval and qualifying criteria."
ACHIEVEMENTS_SECTION_TITLE = "Achievements"
STEPPER_ARIA_LABEL = "Your programme momentum (four stages)"
REWARDS_LEARN_HOW_TOGGLE = "Learn how rewards work"
REWARDS_YOUR_REWARDS_TITLE = "Your rewards"
REWARDS_YOUR_ACTIVITY_TITLE = "Your activity"
REWARDS_LABEL_YOUVE_EARNED = "You've earned"
REWARDS_LABEL_IN_PROGRESS = "In progress"
REWARDS_LABEL_NEXT_REWARD = "Next reward"
REWARDS_LABEL_TOTAL_POSSIBLE = "Total possible"
REWARDS_MOMENTUM_PROGRESSING_ONE = (
    "1 referral is progressing toward your next reward."
)
REWARDS_MOMENTUM_PROGRESSING_MANY = (
    "{n} referrals are progressing toward your next reward."
)
CTA_TRACK_REFERRALS = "Track referrals"
REWARDS_ACTIVITY_STARTED_ONE = "{n} referral started"
REWARDS_ACTIVITY_STARTED_MANY = "{n} referrals started"
REWARDS_ACTIVITY_COMPLETED_ONE = "{n} referral completed"
REWARDS_ACTIVITY_COMPLETED_MANY = "{n} referrals completed"
REWARDS_TOTAL_POSSIBLE_HINT = (
    "Total possible is the programme ceiling if all conditions are met — not a promise of payment until requirements are satisfied."
)
REWARDS_SUMMARY_UNAVAILABLE = (
    "We couldn’t load your reward summary right now. Please try again in a moment."
)

_CREDIT_MISSION_FRAGMENTS: Tuple[str, ...] = (
    "credit",
    "loan",
    "overdraft",
    "facility",
    "lending",
    "borrow",
    "mortgage",
    "homeloan",
    "home loan",
)


def mission_is_credit_related(m: Any) -> bool:
    """True when API flags credit or title/code clearly indicates credit/lending."""
    if not isinstance(m, dict):
        return False
    if bool(m.get("is_credit_related") or m.get("isCreditRelated")):
        return True
    blob = _norm_blob(
        str(m.get("title") or ""),
        str(m.get("mission_code") or ""),
    )
    return any(s in blob for s in _CREDIT_MISSION_FRAGMENTS)


# --- Progress / status (referrer-facing) ---
REFERRER_STATUS_COMPLETED = "Completed"
REFERRER_STATUS_IN_PROGRESS = "In progress"
REFERRER_PHASE_FINAL_STEPS = "Final steps in progress"

# Threshold: at or above this %, show "final steps" instead of generic in-progress copy.
REFERRER_FINAL_STEPS_PERCENT = 72

# --- Rewards wording ---
REWARDS_NEUTRAL_INTRO = "Rewards are described using neutral programme language."
REWARD_WHY_RECEIVED_PROMPT = "Why did I get this reward?"
REWARD_WHY_PENDING_PROMPT = "Why is this reward pending?"
REWARD_EXPLAIN_BUTTON = "Explain reward"
CONDITIONS_APPLY_SHORT = "Conditions apply."
NOT_FINANCIAL_ADVICE_SHORT = "This is not financial advice."

# --- Privacy / consent ---
CONSENT_CONFIRMATION_NOTE = (
    "Your consent confirms you have read the referral terms. We use your details only "
    "to validate this referral, award eligible benefits, and meet regulatory requirements. "
    "We do not share your personal information with the referrer."
)
PRIVACY_PURPOSE_SHORT = (
    "We process referral data fairly and only for this programme: validation, rewards, "
    "and required compliance."
)
LEADERBOARD_ANONYMISED_NOTE = (
    "Display names on this leaderboard are anonymised. Rankings reflect programme activity, "
    "not personal financial information."
)

# --- Referee journey ---
REFEREE_MAY_EARN_PREFIX = "You may earn"
REFEREE_QUALIFY_HINT = "You may qualify when programme conditions are met."
REFEREE_NEXT_STEP_LABEL = "Your next step"
REFEREE_CURRENT_STEP_LABEL = "Where you are now"

# --- Mission labels (referrer-safe scope) ---
MISSIONS_REFERRER_SCOPE_NOTE = (
    "Missions here focus on inviting friends, completed referrals, and programme campaigns. "
    "Friend activities like salary or debit order steps are not shown."
)

# Content hints that another person’s banking steps are pending — replace for referrers.
_REFERRER_STATE_RISK_FRAGMENTS: Tuple[str, ...] = (
    "salary",
    "debit order",
    "debit-order",
    "debit orders",
    "mandate",
    "payroll",
    "debitorderswitch",
)

# mission_code / title filters
_REFERRER_MISSION_EXCLUDE_FRAGMENTS: Tuple[str, ...] = (
    "salary",
    "debit order",
    "debit-order",
    "debit orders",
    "mandate",
    "payroll",
)

_REFERRER_MISSION_CODE_MARKERS: Tuple[str, ...] = (
    "SALARY",
    "DEBIT_ORDER",
    "DEBITORD",
    "MANDATE",
    "PAYROLL",
)


def _norm_blob(*parts: str) -> str:
    return " ".join(str(p or "") for p in parts).lower()


def contains_referee_sensitive_action_hint(text: str) -> bool:
    """True if copy looks like another person’s salary / debit / mandate step."""
    t = (text or "").lower()
    return any(s in t for s in _REFERRER_STATE_RISK_FRAGMENTS)


def sanitize_referrer_state_label(text: str) -> str:
    """Replace risky 'next step' labels with approved referrer-safe phrasing."""
    raw = (text or "").strip()
    if not raw:
        return ""
    if contains_referee_sensitive_action_hint(raw):
        return REFERRER_PHASE_FINAL_STEPS
    lower = raw.lower()
    if lower.startswith("next:") or lower.startswith("next step"):
        inner = raw.split(":", 1)[-1].strip()
        if contains_referee_sensitive_action_hint(inner):
            return REFERRER_PHASE_FINAL_STEPS
        return REFERRER_PHASE_FINAL_STEPS if inner else REFERRER_STATUS_IN_PROGRESS
    return raw


def sanitize_referrer_completed_milestone(text: str) -> str:
    """Soften milestone lines that expose another person’s sensitive banking steps."""
    raw = (text or "").strip()
    if not raw:
        return raw
    if contains_referee_sensitive_action_hint(raw):
        return "Referral milestone completed"
    return raw


_OPTIONAL_MISSION_TITLE_PREFIXES: Tuple[str, ...] = (
    "optional mission:",
    "optional mission -",
    "optional mission —",
    "optional:",
)


def sanitize_mission_title_for_display(title: str) -> str:
    """
    Strip redundant programme framing the API may prepend to mission titles.

    Boost missions already sit under an optional / bonus section; repeating
    'Optional mission:' on every card reads as noisy product copy.
    """
    raw = (title or "").strip()
    if not raw:
        return raw
    lower = raw.lower()
    for prefix in _OPTIONAL_MISSION_TITLE_PREFIXES:
        if lower.startswith(prefix):
            rest = raw[len(prefix) :].strip().lstrip(":-— \t")
            if not rest:
                return raw
            if rest[0].isalpha():
                return rest[0].upper() + rest[1:]
            return rest
    return raw


def sanitize_referrer_display_status(
    display_status: str,
    *,
    is_complete: bool,
    progress_percent: int,
) -> str:
    """Safe high-level status line for referrers."""
    if is_complete:
        return REFERRER_STATUS_COMPLETED
    d = (display_status or "").strip()
    if contains_referee_sensitive_action_hint(d):
        return (
            REFERRER_PHASE_FINAL_STEPS
            if progress_percent >= REFERRER_FINAL_STEPS_PERCENT
            else REFERRER_STATUS_IN_PROGRESS
        )
    if not d:
        return (
            REFERRER_PHASE_FINAL_STEPS
            if progress_percent >= REFERRER_FINAL_STEPS_PERCENT
            else REFERRER_STATUS_IN_PROGRESS
        )
    return d


def referrer_card_status_detail(*, is_complete: bool, progress_percent: int) -> str:
    if is_complete:
        return REFERRER_STATUS_COMPLETED
    if progress_percent >= REFERRER_FINAL_STEPS_PERCENT:
        return REFERRER_PHASE_FINAL_STEPS
    return REFERRER_STATUS_IN_PROGRESS


def format_referrer_milestone_for_display(text: str) -> str:
    """
    Turn API milestone tokens into readable referrer-facing labels.

    Keeps human phrases (e.g. \"Customer linked\") as-is; turns SCREAMING_SNAKE
    like ACCOUNT_OPENED into \"Account Opened\". Sensitive referee-step hints
    are replaced separately via contains_referee_sensitive_action_hint.
    """
    raw = (text or "").strip()
    if not raw:
        return ""
    if contains_referee_sensitive_action_hint(raw):
        return REFERRER_PHASE_FINAL_STEPS
    # Sentence-style copy from the API
    if " " in raw and "_" not in raw:
        return raw
    normalized = raw.replace("-", "_")
    if "_" in normalized:
        parts = [p for p in normalized.split("_") if p]
        if parts:
            return " ".join(p.capitalize() for p in parts)
    if raw.isupper() and len(raw) > 1:
        return raw.capitalize()
    return raw


def referrer_card_status_headline(*, is_complete: bool) -> str:
    return REFERRER_STATUS_COMPLETED if is_complete else REFERRER_STATUS_IN_PROGRESS


def should_exclude_referrer_mission(title: str, mission_code: str) -> bool:
    blob = _norm_blob(title, mission_code)
    if any(s in blob for s in _REFERRER_MISSION_EXCLUDE_FRAGMENTS):
        return True
    code = (mission_code or "").upper().replace("-", "_")
    return any(marker in code for marker in _REFERRER_MISSION_CODE_MARKERS)


def filter_referrer_missions(missions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        m
        for m in missions
        if not should_exclude_referrer_mission(
            str(m.get("title") or ""),
            str(m.get("mission_code") or ""),
        )
    ]


def enrich_referrer_progress_row(row: Dict[str, Any]) -> None:
    """
    Add persona-safe display fields aligned with GET /v1/referrers/* item shape.

    Exposes currentMilestoneDisplay / nextMilestoneDisplay for list cards while
    scrubbing salary/debit-order style hints from the referrer surface.
    """
    pct = int(row.get("progressPercent") or 0)
    is_complete = bool(row.get("is_complete"))
    row["referrerStatusHeadline"] = referrer_card_status_headline(is_complete=is_complete)
    row["referrerStatusDetail"] = referrer_card_status_detail(
        is_complete=is_complete, progress_percent=pct
    )

    cur = str(row.get("currentMilestone") or "").strip()
    next_val = str(row.get("nextMilestone") or "").strip()

    if contains_referee_sensitive_action_hint(cur):
        row["currentMilestone"] = row["referrerStatusDetail"]
        cur = row["referrerStatusDetail"]

    if is_complete:
        row["currentMilestoneDisplay"] = (
            format_referrer_milestone_for_display(cur) or REFERRER_STATUS_COMPLETED
        )
        row["nextMilestoneDisplay"] = ""
        return

    cur_disp = format_referrer_milestone_for_display(cur)
    if not cur_disp:
        cur_disp = row["referrerStatusDetail"]

    if contains_referee_sensitive_action_hint(next_val):
        next_disp = REFERRER_PHASE_FINAL_STEPS
    else:
        next_disp = format_referrer_milestone_for_display(next_val)

    row["currentMilestoneDisplay"] = cur_disp
    row["nextMilestoneDisplay"] = next_disp


def apply_referrer_referral_detail_copy(d: Dict[str, Any]) -> None:
    """Normalize API fields for referrer-only detail template."""
    pct = int(d.get("progress_percent") or 0)
    is_complete = bool(d.get("is_complete"))
    d["display_status"] = sanitize_referrer_display_status(
        str(d.get("display_status") or ""),
        is_complete=is_complete,
        progress_percent=pct,
    )
    d["remaining_state_label"] = sanitize_referrer_state_label(str(d.get("remaining_state_label") or ""))
    d["referrer_status_headline"] = referrer_card_status_headline(is_complete=is_complete)
    d["referrer_status_detail"] = referrer_card_status_detail(
        is_complete=is_complete, progress_percent=pct
    )
    milestones = d.get("completed_milestones") or []
    if isinstance(milestones, list):
        d["completed_milestones"] = [
            sanitize_referrer_completed_milestone(str(m)) for m in milestones if m is not None
        ]
