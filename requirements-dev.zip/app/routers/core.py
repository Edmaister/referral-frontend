from __future__ import annotations

import io
import logging
from typing import Any, Callable, Dict

from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse, Response, StreamingResponse

from app.services.context_service import get_ocep_context

logger = logging.getLogger(__name__)


def build_core_router(
    *,
    render: Callable[[Request, str, Dict[str, Any]], Any],
    admin_console_enabled: bool,
) -> APIRouter:
    router = APIRouter()

    @router.get("/")
    def home(request: Request):
        ocep = get_ocep_context(request)
        if ocep:
            return RedirectResponse(url="/me", status_code=302)
        no_ocep = request.query_params.get("no_ocep") == "1"
        return render(
            request,
            "home.html",
            {"no_ocep": no_ocep, "admin_console_enabled": admin_console_enabled},
        )

    @router.get("/qr")
    def qr_image(url: str = ""):
        if not (url or "").strip():
            return Response(status_code=400, content=b"Missing url")
        try:
            import qrcode

            buf = io.BytesIO()
            qrcode.make(url.strip(), box_size=4, border=2).save(buf, format="PNG")
            buf.seek(0)
            return StreamingResponse(buf, media_type="image/png")
        except ImportError:
            logger.warning("QR generation skipped: install qrcode[pil] for server-side QR")
            return Response(
                status_code=503,
                content=b"QR not available; use client-generated QR on My Referral page",
            )
        except Exception as exc:
            logger.warning("QR generation failed: %s", exc)
            return Response(status_code=500, content=b"QR generation failed")

    return router
