from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional
from urllib.parse import quote, urlencode

import requests
from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse

from referral_client import workflows
from app.services.security_service import require_admin_console, verify_csrf

logger = logging.getLogger(__name__)


def build_admin_router(
    *,
    render: Callable[[Request, str, Dict[str, Any]], Any],
    api_client: Any,
    progress_event_types: tuple[str, ...],
    session_ocep_keys: tuple[str, ...],
    lookup_referee_ucn_for_track: Callable[[str], str],
    record_ucn_captured: Callable[[str, str], None],
    record_progress: Callable[[str, str], None],
    record_accepted: Callable[[str, Optional[str]], None],
    api_error_message: Callable[[requests.RequestException], str],
    render_recommendations: Callable[[Any], Optional[Dict[str, Any]]],
) -> APIRouter:
    router = APIRouter()

    @router.get("/admin")
    def admin_console(request: Request):
        require_admin_console(request)
        try:
            session = getattr(request, "session", None) or {}
        except Exception:
            session = {}
        q = request.query_params
        error = q.get("error")
        message = q.get("message", "")
        capture_ok = q.get("capture_ok") == "1"
        progress_ok = q.get("progress_ok") == "1"
        referee_track_id = session.get("referee_referral_track_id", "")
        referee_ucn_for_track: str = lookup_referee_ucn_for_track(referee_track_id) if referee_track_id else ""
        return render(
            request,
            "admin.html",
            {
                "ocep_ucn": session.get("ocep_ucn", ""),
                "ocep_tenant": session.get("ocep_tenant", "FNB"),
                "ocep_sticker": session.get("ocep_sticker", "EASY"),
                "ocep_segment": session.get("ocep_segment", "EASY"),
                "admin_error": error,
                "admin_message": message,
                "capture_ok": capture_ok,
                "progress_ok": progress_ok,
                "progress_event_types": progress_event_types,
                "referee_referral_track_id": referee_track_id,
                "referee_ucn_for_track": referee_ucn_for_track,
            },
        )

    @router.post("/admin")
    async def admin_set_context(request: Request):
        require_admin_console(request)
        form = await request.form()
        verify_csrf(request, form)
        ucn = (form.get("ocep_ucn") or "").strip()
        tenant = (form.get("ocep_tenant") or "FNB").strip()
        sticker = (form.get("ocep_sticker") or "EASY").strip()
        segment = (form.get("ocep_segment") or "EASY").strip()
        if not ucn or not tenant:
            return RedirectResponse(url="/admin?error=missing", status_code=303)
        try:
            request.session["ocep_ucn"] = ucn
            request.session["ocep_tenant"] = tenant
            request.session["ocep_sticker"] = sticker
            request.session["ocep_segment"] = segment
            return RedirectResponse(url="/me", status_code=303)
        except Exception as e:
            logger.warning("Session write failed, redirecting with query params: %s", e)
            qs = urlencode(
                {
                    "ocep_ucn": ucn,
                    "ocep_tenant": tenant,
                    "ocep_sticker": sticker,
                    "ocep_segment": segment,
                }
            )
            return RedirectResponse(url=f"/me?{qs}", status_code=303)

    @router.post("/admin/clear")
    async def admin_clear(request: Request):
        require_admin_console(request)
        form = await request.form()
        verify_csrf(request, form)
        for key in session_ocep_keys:
            request.session.pop(key, None)
        return RedirectResponse(url="/admin", status_code=303)

    @router.post("/admin/capture-ucn")
    async def admin_capture_ucn(request: Request):
        require_admin_console(request)
        form = await request.form()
        verify_csrf(request, form)
        referral_track_id = (form.get("referral_track_id") or "").strip()
        referee_ucn = (form.get("referee_ucn") or "").strip()
        logger.info(
            "Admin capture UCN called: referral_track_id=%s referee_ucn=%s",
            referral_track_id,
            referee_ucn,
        )
        if not referral_track_id or not referee_ucn:
            return RedirectResponse(url="/admin?error=capture_missing", status_code=303)
        try:
            api_client.capture_referee_ucn(
                {
                    "referral_track_id": referral_track_id,
                    "referee_ucn": referee_ucn,
                }
            )
            record_ucn_captured(referral_track_id, referee_ucn)
        except requests.RequestException as e:
            logger.warning("Capture UCN API failed: %s", e)
            return RedirectResponse(
                url=f"/admin?error=capture_api&message={quote(api_error_message(e))}",
                status_code=303,
            )
        return RedirectResponse(url="/admin?capture_ok=1", status_code=303)

    @router.post("/admin/progress")
    async def admin_progress(request: Request):
        require_admin_console(request)
        form = await request.form()
        verify_csrf(request, form)
        referral_track_id = (form.get("referral_track_id") or "").strip()
        product_raw = (form.get("product") or "").strip()
        product: Optional[str] = product_raw if product_raw else None
        sub_product = (form.get("sub_product") or "").strip()
        event_type = (form.get("event_type") or "").strip().upper()
        referee_ucn = (form.get("referee_ucn") or "").strip()
        account_number = (form.get("account_number") or "").strip()
        if not referral_track_id or not event_type or event_type not in progress_event_types:
            return RedirectResponse(url="/admin?error=progress_missing", status_code=303)
        if not referee_ucn:
            referee_ucn = lookup_referee_ucn_for_track(referral_track_id)

        # Admin test harness requirement: all events must carry both UCN + account number.
        if not referee_ucn or not account_number:
            return RedirectResponse(url="/admin?error=progress_payload_missing", status_code=303)

        if event_type == "DEBIT_ORDER_SWITCHED" and product and product.upper() == "ACCOUNT":
            product = "DEBIT_ORDER"
        try:
            workflows.record_referral_progress_event(
                api_client,
                referral_track_id=referral_track_id,
                event_type=event_type,
                product=product,
                sub_product=sub_product if sub_product else None,
                referee_ucn=(referee_ucn if referee_ucn else None),
                account_number=account_number if account_number else None,
            )
            record_progress(referral_track_id, event_type)
            if event_type == "ACCOUNT_OPENED":
                record_accepted(referral_track_id, None)
        except requests.RequestException as e:
            logger.warning("Progress API failed: %s", e)
            debug = (
                f" (submitted eventType={event_type}, "
                f"refereeUCN={'set' if bool(referee_ucn) else 'empty'}, "
                f"accountNumber={'set' if bool(account_number) else 'empty'})"
            )
            return RedirectResponse(
                url=f"/admin?error=progress_api&message={quote(api_error_message(e) + debug)}",
                status_code=303,
            )
        return RedirectResponse(url="/admin?progress_ok=1", status_code=303)

    @router.get("/admin/test-recommendations")
    def admin_test_recommendations(
        request: Request,
        identifier: str = "",
        audience: str = "referrer",
        tenant: str = "FNB",
    ):
        require_admin_console(request)
        recommendations = None
        error = None

        if identifier.strip():
            try:
                raw_recommendations = api_client.my_recommendations(
                    referrer_hash=identifier.strip(),
                    sticker="EASY",
                    tenant=tenant.strip() or "FNB",
                )
                recommendations = render_recommendations(raw_recommendations)
            except requests.RequestException as e:
                logger.warning("Test recommendations API failed: %s", e)
                error = api_error_message(e)

        return render(
            request,
            "test_recommendations.html",
            {
                "identifier": identifier,
                "audience": audience,
                "tenant": tenant,
                "recommendations": recommendations,
                "error": error,
            },
        )

    return router
