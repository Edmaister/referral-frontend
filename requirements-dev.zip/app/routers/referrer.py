from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import quote

import requests
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import RedirectResponse
from referral_client import workflows

from app.config import DEMO_MODE, DEMO_PROGRESS_PREVIEW
from app.copy import ux_copy_catalog as ux
from app.services.context_service import get_ocep_context
from app.services.referrer_dashboard_service import fetch_referrer_dashboard
from app.services.referrer_home_hero_service import (
    almost_there_body_short,
    build_me_hero_context,
    portfolio_hero_momentum_line,
    summarize_referral_portfolio,
)
from app.services.referrer_missions_service import (
    fetch_referrer_missions,
    fetch_referrer_missions_snapshot,
)
from app.services.referrer_referral_view_service import fetch_referrer_referral_detail
from app.services.progress_ui_service import (
    fetch_referrer_progress_snapshot,
    finalize_progress_rows_for_ui,
    normalize_referrer_progress,
)
from app.services.referrer_reward_overview_service import fetch_referrer_reward_overview
from app.services.referrer_code_service import (
    bootstrap_is_favorable,
    bootstrap_merged,
    bootstrap_requires_api_terms,
    fetch_bootstrap_safe,
)
from app.services.security_service import verify_csrf

logger = logging.getLogger(__name__)


def _overview_money_compact(sym: str, amount: float) -> str:
    try:
        a = float(amount)
    except (TypeError, ValueError):
        return f"{sym}0"
    if abs(a - round(a)) < 0.005:
        return f"{sym}{int(round(a))}"
    return f"{sym}{a:.2f}"


def _tier_display_short(tier_name: str) -> str:
    t = (tier_name or "").strip()
    low = t.lower()
    if low.endswith(" tier"):
        return t[:-5].strip()
    return t


def build_referrer_router(
    *,
    render: Callable[[Request, str, Dict[str, Any]], Any],
    api_client: Any,
    leaderboard_code_setting: str,
    leaderboard_top_n: int,
    require_terms_for_me: Callable[[Request, Any], bool],
    resolve_referrer_code_for_ui: Callable[..., tuple[Dict[str, Any], Optional[str], str]],
    register_referral_code: Callable[[str, str], None],
    fetch_referrer_progress_from_api: Callable[[str], Optional[List[Dict[str, Any]]]],
    get_referrer_statuses: Callable[[str], List[Dict[str, Any]]],
    fetch_leaderboard_for_me: Callable[[Any, str, str, int], tuple[Optional[Dict[str, Any]], List[Dict[str, Any]], Optional[str]]],
    api_error_message: Callable[[requests.RequestException], str],
    render_recommendations: Callable[[Any], Optional[Dict[str, Any]]],
    fetch_reward_summary: Callable[[Any, str], Optional[Dict[str, Any]]],
) -> APIRouter:
    router = APIRouter()

    @router.get("/refer-and-earn")
    def refer_and_earn(request: Request):
        """
        First call POST /referrals/bootstrap (referrerUcn, tenantCode).
        If exists=true and API terms pending → terms-only UX + POST /referrals/accept-terms on submit.
        If bootstrap is favourable (code + terms OK) → redirect to codes (session synced).
        Else → new-referrer flow: terms + optional handle, then POST /referrals/codes on codes screen.
        """
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)

        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]
        bootstrap_raw = fetch_bootstrap_safe(api_client, referrer_ucn, tenant, logger)
        merged = bootstrap_merged(bootstrap_raw)

        if bootstrap_requires_api_terms(merged):
            profile_alias = str(merged.get("alias") or merged.get("gamingHandle") or "").strip()
            return render(
                request,
                "refer_and_earn.html",
                {
                    "ocep": ocep,
                    "api_terms_only": True,
                    "refer_flow": "api_terms",
                    "gaming_handle_prefill": "",
                    "profile_alias": profile_alias,
                    "bootstrap_message": merged.get("message"),
                    "accept_error": None,
                },
            )

        if bootstrap_is_favorable(bootstrap_raw):
            try:
                request.session["terms_accepted"] = True
            except Exception as ex:
                logger.warning("refer-and-earn: session update after favorable bootstrap: %s", ex)
            return RedirectResponse(url="/refer-and-earn/codes", status_code=302)

        if not require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn/codes", status_code=302)

        gaming_handle_prefill = ""
        try:
            ph = request.session.get("preferred_handle")
            if ph:
                gaming_handle_prefill = str(ph).strip()
        except Exception:
            pass
        return render(
            request,
            "refer_and_earn.html",
            {
                "ocep": ocep,
                "api_terms_only": False,
                "refer_flow": "issue",
                "gaming_handle_prefill": gaming_handle_prefill,
                "profile_alias": "",
                "bootstrap_message": None,
                "accept_error": None,
            },
        )

    @router.post("/refer-and-earn/accept")
    async def refer_and_earn_accept(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)
        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]

        try:
            form = await request.form()
            verify_csrf(request, form)
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("refer_and_earn_accept: form read failed: %s", e)
            raise HTTPException(
                status_code=400,
                detail="We could not read the form. Please try again.",
            ) from e

        flow = (form.get("refer_flow") or "issue").strip().lower()
        if flow not in ("issue", "api_terms"):
            flow = "issue"

        raw_accept = form.get("accept_terms")
        terms_checked = raw_accept in ("on", "true", "1", True, "yes", "Yes")
        if not terms_checked:
            gh = (form.get("gaming_handle") or "").strip()
            if flow == "api_terms":
                merged_e = bootstrap_merged(
                    fetch_bootstrap_safe(api_client, referrer_ucn, tenant, logger)
                )
                return render(
                    request,
                    "refer_and_earn.html",
                    {
                        "ocep": ocep,
                        "api_terms_only": True,
                        "refer_flow": "api_terms",
                        "gaming_handle_prefill": "",
                        "profile_alias": str(merged_e.get("alias") or merged_e.get("gamingHandle") or "").strip(),
                        "bootstrap_message": merged_e.get("message"),
                        "accept_error": "Please tick the box to accept the terms before continuing.",
                        "_http_status": 400,
                    },
                )
            return render(
                request,
                "refer_and_earn.html",
                {
                    "ocep": ocep,
                    "api_terms_only": False,
                    "refer_flow": "issue",
                    "gaming_handle_prefill": gh,
                    "profile_alias": "",
                    "bootstrap_message": None,
                    "accept_error": "Please tick the box to accept the terms before continuing.",
                    "_http_status": 400,
                },
            )

        if flow == "api_terms":
            try:
                workflows.accept_referrer_programme_terms(
                    api_client,
                    referrer_ucn=referrer_ucn,
                    tenant_code=tenant,
                )
            except requests.RequestException as e:
                logger.warning("accept-terms failed: %s", e)
                merged_e = bootstrap_merged(
                    fetch_bootstrap_safe(api_client, referrer_ucn, tenant, logger)
                )
                return render(
                    request,
                    "refer_and_earn.html",
                    {
                        "ocep": ocep,
                        "api_terms_only": True,
                        "refer_flow": "api_terms",
                        "gaming_handle_prefill": "",
                        "profile_alias": str(merged_e.get("alias") or merged_e.get("gamingHandle") or "").strip(),
                        "bootstrap_message": merged_e.get("message"),
                        "accept_error": api_error_message(e),
                        "_http_status": 502,
                    },
                )
            try:
                request.session["terms_accepted"] = True
            except Exception as e:
                logger.exception("refer_and_earn_accept: session failed after accept-terms: %s", e)
                merged_e = bootstrap_merged(
                    fetch_bootstrap_safe(api_client, referrer_ucn, tenant, logger)
                )
                return render(
                    request,
                    "refer_and_earn.html",
                    {
                        "ocep": ocep,
                        "api_terms_only": True,
                        "refer_flow": "api_terms",
                        "gaming_handle_prefill": "",
                        "profile_alias": str(merged_e.get("alias") or merged_e.get("gamingHandle") or "").strip(),
                        "bootstrap_message": merged_e.get("message"),
                        "accept_error": "We could not save your session. Check cookies and try again.",
                        "_http_status": 500,
                    },
                )
            return RedirectResponse(url="/refer-and-earn/codes", status_code=303)

        preferred_handle = (form.get("gaming_handle") or "").strip() or None
        try:
            request.session["terms_accepted"] = True
            if preferred_handle:
                request.session["preferred_handle"] = preferred_handle
            else:
                request.session.pop("preferred_handle", None)
        except Exception as e:
            logger.exception("refer_and_earn_accept failed: %s", e)
            raise HTTPException(
                status_code=400,
                detail="We could not save your acceptance. Please try again.",
            ) from e
        return RedirectResponse(url="/refer-and-earn/codes", status_code=303)

    @router.get("/refer-and-earn/codes")
    def refer_and_earn_codes(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)

        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]
        sticker = ocep["sticker"]
        segment = ocep["segment"]

        bootstrap_raw = fetch_bootstrap_safe(api_client, referrer_ucn, tenant, logger)
        merged = bootstrap_merged(bootstrap_raw)
        if bootstrap_requires_api_terms(merged):
            return RedirectResponse(url="/refer-and-earn", status_code=302)
        if not bootstrap_is_favorable(bootstrap_raw) and require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn", status_code=302)

        try:
            preferred_handle = request.session.get("preferred_handle")
        except Exception:
            preferred_handle = None

        issue_resp, error, code_source = resolve_referrer_code_for_ui(
            referrer_ucn=referrer_ucn,
            tenant=tenant,
            sticker=sticker,
            segment=segment,
            preferred_handle=preferred_handle,
            bootstrap_raw=bootstrap_raw,
        )

        short_code = (
            issue_resp.get("short_code")
            or issue_resp.get("referralShortCode")
            or issue_resp.get("referral_short_code")
            or issue_resp.get("referral_code")
        )
        gaming_handle = (issue_resp or {}).get("gaming_handle") or ""
        referral_context_message = (issue_resp or {}).get("message")

        if short_code:
            register_referral_code(referrer_ucn, str(short_code))

        base = str(request.base_url).rstrip("/")
        share_url = (
            f"{base}/friend?referral_code={quote(short_code or '')}&tenant_code={quote(tenant)}"
            if short_code
            else ""
        )
        qr_image_url = f"{base}/qr?url={quote(share_url)}" if share_url else ""

        return render(
            request,
            "refer_and_earn_codes.html",
            {
                "referrer_ucn": referrer_ucn,
                "tenant": tenant,
                "short_code": short_code or "",
                "gaming_handle": gaming_handle,
                "share_url": share_url,
                "qr_image_url": qr_image_url,
                "error": error,
                "code_source": code_source,
                "referral_context_message": referral_context_message,
                "qr_eligible": (issue_resp or {}).get("qr_eligible"),
            },
        )

    @router.get("/me")
    def my_referral(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)

        terms_pending = require_terms_for_me(request, ocep)
        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]

        error: Optional[str] = None
        dashboard = None
        rewards_earned_amount: float = 0.0
        rewards_pending_amount: float = 0.0
        rewards_total_potential: float = 0.0
        rewards_currency_symbol: str = "R"
        rewards_overview: Optional[Dict[str, Any]] = None
        active_missions_count: int = 0
        current_badges_count: int = 0
        missions_preview: List[Dict[str, Any]] = []

        progress_rows = fetch_referrer_progress_from_api(referrer_ucn)
        if progress_rows is None:
            raw_demo = get_referrer_statuses(referrer_ucn) if DEMO_MODE else []
            progress_rows = (
                normalize_referrer_progress({"items": raw_demo}) if raw_demo else []
            )
        else:
            progress_rows = list(progress_rows)
        my_statuses = progress_rows

        if not terms_pending:
            try:
                rewards_overview = fetch_referrer_reward_overview(
                    api_client, referrer_ucn, logger
                )
                if rewards_overview:
                    rewards_earned_amount = float(rewards_overview.get("earned") or 0.0)
                    rewards_pending_amount = float(rewards_overview.get("pending") or 0.0)
                    rewards_total_potential = float(
                        rewards_overview.get("total_potential") or 0.0
                    )
                    rewards_currency_symbol = str(
                        rewards_overview.get("currency_symbol") or "R"
                    )

                dashboard = fetch_referrer_dashboard(api_client, referrer_ucn, logger)
                if dashboard:
                    if rewards_overview is None:
                        rewards_earned_amount = float(
                            dashboard.get("rewards_earned_amount") or 0.0
                        )
                        rewards_pending_amount = float(
                            dashboard.get("rewards_pending_amount") or 0.0
                        )
                    active_missions_count = int(dashboard.get("active_missions_count") or 0)
                    current_badges_count = int(dashboard.get("current_badges_count") or 0)
                mp = fetch_referrer_missions(api_client, referrer_ucn, logger)
                if mp:
                    missions_preview = mp[:3]
            except requests.RequestException as e:
                logger.exception("Referral API error")
                error = api_error_message(e)

        accepted_count = sum(1 for s in my_statuses if s.get("status") == "accepted")
        if dashboard:
            accepted_count = int(dashboard.get("referrals_completed_count") or accepted_count)
        if accepted_count >= 5:
            tier_name = "Gold tier"
            tier_progress_percent = 100
            next_tier_name = None
            next_goal = None
        elif accepted_count >= 2:
            tier_name = "Silver tier"
            tier_min, tier_max = 2, 5
            tier_progress_percent = int(((accepted_count - tier_min) / (tier_max - tier_min)) * 100)
            next_tier_name = "Gold tier"
            next_goal = f"{5 - accepted_count} more accepted"
        else:
            tier_name = "Bronze tier"
            tier_min, tier_max = 0, 2
            tier_progress_percent = int(((accepted_count - tier_min) / (tier_max - tier_min)) * 100)
            next_tier_name = "Silver tier"
            next_goal = f"{2 - accepted_count} more accepted"

        dashboard_tier_name = ""
        dashboard_points_to_next = 0
        dashboard_next_rank_pos = None
        dashboard_pending_bonuses = 0
        dashboard_summary_referrals = 0
        dashboard_next_eligible = 0.0
        dashboard_milestone_progress = 0
        dashboard_milestone_goal = 0
        if dashboard:
            raw_tier = str(dashboard.get("leaderboard_tier") or "").strip()
            if raw_tier:
                dashboard_tier_name = (
                    raw_tier if raw_tier.lower().endswith("tier") else f"{raw_tier} tier"
                )
            dashboard_points_to_next = int(dashboard.get("points_to_next_rank") or 0)
            dashboard_next_rank_pos = dashboard.get("leaderboard_next_rank_position")
            dashboard_pending_bonuses = int(dashboard.get("pending_bonuses_count") or 0)
            dashboard_summary_referrals = int(dashboard.get("summary_referrals_count") or 0)
            dashboard_next_eligible = float(dashboard.get("next_eligible_reward") or 0.0)
            dashboard_milestone_progress = int(
                dashboard.get("milestone_next_progress_count") or 0
            )
            dashboard_milestone_goal = int(
                dashboard.get("milestone_next_goal_count") or 0
            )

        if dashboard_tier_name:
            tier_name = dashboard_tier_name
            if (
                accepted_count >= 1
                and dashboard_next_eligible <= 0
                and dashboard_milestone_goal > 0
            ):
                tier_progress_percent = int(
                    max(
                        0,
                        min(
                            100,
                            round((dashboard_milestone_progress / dashboard_milestone_goal) * 100),
                        ),
                    )
                )
                next_tier_name = None
                next_goal = None
            elif dashboard_points_to_next <= 0:
                tier_progress_percent = 100
                next_tier_name = None
                next_goal = None
            else:
                if dashboard_next_rank_pos is not None:
                    next_tier_name = f"Rank #{dashboard_next_rank_pos}"
                else:
                    next_tier_name = "Next tier"
                next_goal = f"{dashboard_points_to_next} points to next rank"

        latest_iso = None
        for s in my_statuses:
            candidate = s.get("accepted_at") or s.get("validated_at")
            if candidate and (latest_iso is None or candidate > latest_iso):
                latest_iso = candidate
        latest_update = latest_iso[:10] if latest_iso else None

        referrals_in_progress = 0
        badge_items: List[Dict[str, Any]] = []
        if dashboard:
            referrals_in_progress = int(dashboard.get("referrals_in_progress_count") or 0)
            raw_badges = dashboard.get("badge_items")
            if isinstance(raw_badges, list):
                badge_items = [b for b in raw_badges if isinstance(b, dict)]

        portfolio = summarize_referral_portfolio(progress_rows)
        active_portfolio = int(portfolio.get("active_in_progress") or 0)
        close_portfolio = int(portfolio.get("close_to_reward") or 0)
        if referrals_in_progress and active_portfolio == 0:
            active_portfolio = referrals_in_progress

        me_hero = build_me_hero_context(
            rewards_overview=rewards_overview,
            tier_progress_percent=tier_progress_percent,
            referrals_in_progress_count=active_portfolio,
        )
        still_amt = float(me_hero.get("rewards_still_available") or 0.0)
        next_eligible_amt = 0.0
        if rewards_overview:
            try:
                next_eligible_amt = float(rewards_overview.get("next_eligible") or 0.0)
            except (TypeError, ValueError):
                next_eligible_amt = 0.0
        if next_eligible_amt <= 0 and dashboard_next_eligible > 0:
            next_eligible_amt = dashboard_next_eligible

        portfolio_hero_momentum = portfolio_hero_momentum_line(
            close_portfolio,
            active_portfolio,
            next_eligible=next_eligible_amt,
            still=still_amt,
            fallback=str(me_hero.get("momentum_hero_line") or ""),
        )
        is_expansion_state = accepted_count >= 1 and next_eligible_amt <= 0

        if active_portfolio > 0:
            almost_there_display = almost_there_body_short(active_portfolio)
            progress_card_title = ux.MOMENTUM_CARD_HEADLINE_DISPLAY
            progress_card_cta_href = "/me/progress"
            progress_card_cta_label = ux.CTA_TRACK_PROGRESS
        else:
            almost_there_display = ux.MOMENTUM_CARD_BODY_NO_ACTIVE
            progress_card_title = ux.MOMENTUM_CARD_HEADLINE_NO_ACTIVE
            progress_card_cta_href = "/refer-and-earn/codes"
            progress_card_cta_label = ux.FOOTER_REFER_AND_EARN
        show_almost_there = True

        if dashboard_tier_name:
            if is_expansion_state and dashboard_milestone_goal > 0:
                next_tier_subcopy = (
                    f"{dashboard_milestone_progress} of {dashboard_milestone_goal} referrals completed"
                )
            elif dashboard_points_to_next <= 0:
                next_tier_subcopy = ux.TIER_TOP_UNLOCKED
            else:
                next_tier_subcopy = f"{dashboard_points_to_next} points to next rank"
        elif accepted_count >= 5:
            next_tier_subcopy = ux.TIER_TOP_UNLOCKED
        elif next_tier_name:
            if accepted_count >= 2:
                n_more = 5 - accepted_count
            else:
                n_more = 2 - accepted_count
            next_tier_subcopy = f"{n_more} more successful referrals"
        else:
            next_tier_subcopy = next_goal or ""

        strip_referrals_count = (
            dashboard_summary_referrals
            or (
                int(rewards_overview.get("referrals_count") or 0)
                if rewards_overview
                else len(my_statuses)
            )
        )
        strip_opportunities_count = (
            dashboard_pending_bonuses if dashboard is not None else active_missions_count
        )
        rewards_earned_display = _overview_money_compact(
            rewards_currency_symbol, rewards_earned_amount
        )
        pending_display = _overview_money_compact(
            rewards_currency_symbol, rewards_pending_amount
        )
        overview_hero_subline_pending = ux.OVERVIEW_HERO_LINE_PENDING.format(
            amt=pending_display
        )
        overview_hero_subline_next = ""
        if is_expansion_state:
            overview_hero_subline_pending = ux.OVERVIEW_HERO_EXPANSION_LINE_ONE
            overview_hero_subline_next = ux.OVERVIEW_HERO_EXPANSION_LINE_TWO
        else:
            next_for_copy = next_eligible_amt
            if next_for_copy <= 0 and still_amt > 0:
                # Fallback for gateways that omit nextEligible but do provide remaining potential.
                next_for_copy = still_amt
            if next_for_copy > 0:
                ne_display = _overview_money_compact(
                    rewards_currency_symbol, next_for_copy
                )
                overview_hero_subline_next = ux.OVERVIEW_HERO_LINE_UP_TO.format(amt=ne_display)
        tier_display_short = _tier_display_short(tier_name)
        if active_portfolio <= 0:
            overview_momentum_dots_filled = min(6, max(0, close_portfolio * 2))
        else:
            overview_momentum_dots_filled = min(6, max(1, active_portfolio * 3))
        overview_momentum_bar_pct = min(
            100, int(round(overview_momentum_dots_filled * 100 / 6))
        )
        show_tier_encouragement = (
            bool(next_tier_name) and int(tier_progress_percent) < 30
        ) or is_expansion_state

        return render(
            request,
            "my_referral.html",
            {
                "referrer_ucn": referrer_ucn,
                "tenant": tenant,
                "error": error,
                "tier_name": tier_name,
                "tier_display_short": tier_display_short,
                "tier_progress_percent": tier_progress_percent,
                "next_tier_name": next_tier_name,
                "next_goal": next_goal,
                "latest_update": latest_update,
                "rewards_earned_amount": rewards_earned_amount,
                "rewards_earned_display": rewards_earned_display,
                "overview_hero_subline_pending": overview_hero_subline_pending,
                "overview_hero_subline_next": overview_hero_subline_next,
                "overview_momentum_bar_pct": overview_momentum_bar_pct,
                "rewards_pending_amount": rewards_pending_amount,
                "rewards_total_potential": rewards_total_potential,
                "rewards_currency_symbol": rewards_currency_symbol,
                "active_missions_count": active_missions_count,
                "strip_opportunities_count": strip_opportunities_count,
                "current_badges_count": current_badges_count,
                "missions_preview": missions_preview,
                "strip_referrals_count": strip_referrals_count,
                "strip_complete_count": accepted_count,
                "me_hero": me_hero,
                "badge_items": badge_items,
                "next_tier_subcopy": next_tier_subcopy,
                "portfolio_hero_momentum": portfolio_hero_momentum,
                "show_almost_there": show_almost_there,
                "progress_card_title": progress_card_title,
                "progress_card_cta_href": progress_card_cta_href,
                "progress_card_cta_label": progress_card_cta_label,
                "almost_there_display": almost_there_display,
                "overview_momentum_dots_filled": overview_momentum_dots_filled,
                "show_tier_encouragement": show_tier_encouragement,
                "show_growth_hint": is_expansion_state,
            },
        )

    @router.get("/me/share")
    def my_referral_share(request: Request):
        """
        Backward-compatible entry: always delegate to the canonical Refer & Earn routes
        (/refer-and-earn for terms, /refer-and-earn/codes for code/QR).
        """
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)
        if require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn", status_code=302)
        return RedirectResponse(url="/refer-and-earn/codes", status_code=302)

    @router.get("/me/progress")
    def my_referral_progress(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)

        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]

        error: Optional[str] = None
        terms_pending = require_terms_for_me(request, ocep)
        rewards_earned_amount = 0.0
        rewards_pending_amount = 0.0
        rewards_total_potential = 0.0
        rewards_currency_symbol = "R"
        if not terms_pending:
            try:
                ro = fetch_referrer_reward_overview(api_client, referrer_ucn, logger)
                if ro:
                    rewards_earned_amount = float(ro.get("earned") or 0.0)
                    rewards_pending_amount = float(ro.get("pending") or 0.0)
                    rewards_total_potential = float(ro.get("total_potential") or 0.0)
                    rewards_currency_symbol = str(ro.get("currency_symbol") or "R")
            except requests.RequestException:
                pass

        progress_snapshot = fetch_referrer_progress_snapshot(
            api_client,
            referrer_ucn,
            logger,
            normalizer=normalize_referrer_progress,
        )
        if progress_snapshot is None:
            error = "We couldn’t load your referral progress right now. Please try again in a moment."
            raw_demo = get_referrer_statuses(referrer_ucn) if DEMO_MODE else []
            records = normalize_referrer_progress({"items": raw_demo}) if raw_demo else []
            total_count = len(records)
            completed_count = sum(1 for r in records if r.get("is_complete"))
            in_progress_count = max(0, total_count - completed_count)
            has_active_referrals = in_progress_count > 0
        elif DEMO_MODE and DEMO_PROGRESS_PREVIEW and len(progress_snapshot.get("records") or []) == 0:
            raw_demo = get_referrer_statuses(referrer_ucn)
            records = normalize_referrer_progress({"items": raw_demo}) if raw_demo else []
            total_count = len(records)
            completed_count = sum(1 for r in records if r.get("is_complete"))
            in_progress_count = max(0, total_count - completed_count)
            has_active_referrals = in_progress_count > 0
        else:
            records = list(progress_snapshot.get("records") or [])
            _total_from_api = progress_snapshot.get("total_referrals")
            _completed_from_api = progress_snapshot.get("completed_referrals_count")
            _in_progress_from_api = progress_snapshot.get("in_progress_referrals_count")
            _has_active_from_api = progress_snapshot.get("has_active_referrals")

            total_count = int(_total_from_api) if _total_from_api is not None else len(records)
            completed_count = (
                int(_completed_from_api)
                if _completed_from_api is not None
                else sum(1 for r in records if r.get("is_complete"))
            )
            in_progress_count = (
                int(_in_progress_from_api)
                if _in_progress_from_api is not None
                else max(0, total_count - completed_count)
            )
            has_active_referrals = (
                bool(_has_active_from_api)
                if _has_active_from_api is not None
                else in_progress_count > 0
            )

        def _format_date_label(iso: Any) -> Optional[str]:
            if not iso or not isinstance(iso, str):
                return None
            s = iso.strip()
            if not s:
                return None
            try:
                s = s.replace("Z", "+00:00")
                dt = datetime.fromisoformat(s)
                return dt.strftime("%d %b %Y")
            except Exception:
                return s[:10] if len(s) >= 10 else s

        for r in records:
            r["lastUpdatedLabel"] = _format_date_label(r.get("lastUpdatedAt"))

        finalize_progress_rows_for_ui(records)

        in_progress_records = [r for r in records if not r.get("is_complete")]
        completed_records = [r for r in records if r.get("is_complete")]

        def _last_updated_sort_key(r: Dict[str, Any]) -> str:
            return str(r.get("lastUpdatedAt") or "")

        in_progress_records.sort(
            key=lambda x: (int(x.get("progressPercent") or 0), _last_updated_sort_key(x)),
            reverse=True,
        )
        completed_records.sort(key=lambda x: (_last_updated_sort_key(x),), reverse=True)

        still_available = max(0.0, rewards_total_potential - rewards_earned_amount)
        if still_available <= 0.0 and rewards_pending_amount > 0.0:
            still_available = rewards_pending_amount

        return render(
            request,
            "my_referral_progress.html",
            {
                "referrer_ucn": referrer_ucn,
                "tenant": tenant,
                "total_count": total_count,
                "in_progress_count": in_progress_count,
                "completed_count": completed_count,
                "in_progress_records": in_progress_records,
                "completed_records": completed_records,
                "has_active_referrals": has_active_referrals,
                "error": error,
                "terms_pending": terms_pending,
                "rewards_earned_amount": rewards_earned_amount,
                "rewards_pending_amount": rewards_pending_amount,
                "rewards_total_potential": rewards_total_potential,
                "rewards_still_available": still_available,
                "rewards_currency_symbol": rewards_currency_symbol,
            },
        )

    @router.get("/me/referral/{referral_track_id}")
    def referrer_referral_detail(request: Request, referral_track_id: str):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)
        if require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn", status_code=302)

        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]
        tid = referral_track_id.strip()
        detail = fetch_referrer_referral_detail(api_client, tid, logger)
        reward_summary = fetch_reward_summary(api_client, tid)

        return render(
            request,
            "my_referral_detail.html",
            {
                "referrer_ucn": referrer_ucn,
                "tenant": tenant,
                "referral_track_id": tid,
                "referrer_detail": detail,
                "reward_summary": reward_summary,
                "detail_unavailable": detail is None and reward_summary is None,
            },
        )

    @router.get("/me/tips")
    def my_referral_tips(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)
        if require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn", status_code=302)
        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]

        rewards_overview = fetch_referrer_reward_overview(api_client, referrer_ucn, logger)
        dashboard = fetch_referrer_dashboard(api_client, referrer_ucn, logger)

        progress_rows = fetch_referrer_progress_from_api(referrer_ucn)
        if progress_rows is None:
            raw_demo = get_referrer_statuses(referrer_ucn) if DEMO_MODE else []
            progress_rows = (
                normalize_referrer_progress({"items": raw_demo}) if raw_demo else []
            )
        else:
            progress_rows = list(progress_rows)

        referrals_total = len(progress_rows)
        completed_referrals = sum(1 for r in progress_rows if r.get("is_complete"))
        opportunities_count = 0
        badge_count = 0
        leaderboard_rank = None
        leaderboard_tier = ""
        points_to_next_rank = 0

        if dashboard:
            referrals_total = int(dashboard.get("summary_referrals_count") or referrals_total)
            completed_referrals = int(
                dashboard.get("referrals_completed_count") or completed_referrals
            )
            opportunities_count = int(dashboard.get("pending_bonuses_count") or 0)
            badge_count = int(dashboard.get("current_badges_count") or 0)
            leaderboard_rank = dashboard.get("leaderboard_rank")
            leaderboard_tier = str(dashboard.get("leaderboard_tier") or "").strip()
            points_to_next_rank = int(dashboard.get("points_to_next_rank") or 0)

        if not leaderboard_tier:
            leaderboard_tier = "Bronze"

        reward_disclosures: List[str] = []
        regulatory_tags: List[str] = []
        if rewards_overview:
            raw_disc = rewards_overview.get("disclosures") or []
            if isinstance(raw_disc, list):
                reward_disclosures = [str(d).strip() for d in raw_disc if str(d).strip()]
            comp = rewards_overview.get("compliance") or {}
            raw_tags = comp.get("regulatory_tags") if isinstance(comp, dict) else []
            if isinstance(raw_tags, list):
                regulatory_tags = [str(t).strip() for t in raw_tags if str(t).strip()]

        return render(
            request,
            "my_referral_tips.html",
            {
                "referrer_ucn": referrer_ucn,
                "tenant": tenant,
                "tips_referrals_count": referrals_total,
                "tips_completed_count": completed_referrals,
                "tips_opportunities_count": opportunities_count,
                "tips_badge_count": badge_count,
                "tips_leaderboard_rank": leaderboard_rank,
                "tips_leaderboard_tier": leaderboard_tier,
                "tips_points_to_next_rank": points_to_next_rank,
                "tips_disclosures": reward_disclosures,
                "tips_regulatory_tags": regulatory_tags,
            },
        )

    @router.get("/me/missions")
    def my_referral_missions(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)
        if require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn", status_code=302)

        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]
        missions_snapshot = fetch_referrer_missions_snapshot(api_client, referrer_ucn, logger) or {}
        missions = list(missions_snapshot.get("all_missions") or [])
        core_missions = list(missions_snapshot.get("core") or [])
        boost_missions = list(missions_snapshot.get("boost") or [])
        milestone_missions = list(missions_snapshot.get("milestone") or [])
        total_count = int(missions_snapshot.get("total_count") or len(missions))
        completed_count = sum(1 for m in missions if m.get("is_complete"))
        active_count = len(missions) - completed_count
        rewards_overview = fetch_referrer_reward_overview(api_client, referrer_ucn, logger)
        # Hero "You've unlocked": all mission buckets (core + boost + milestone). Milestone
        # payouts are real earned value and must match the headline total customers expect.
        total_earned = sum(float(m.get("reward_earned_amount") or 0.0) for m in missions)
        if rewards_overview:
            overview_earned = float(rewards_overview.get("earned") or 0.0)
            if overview_earned > 0:
                total_earned = max(total_earned, overview_earned)
        boost_bonus_earned = sum(float(m.get("reward_earned_amount") or 0.0) for m in boost_missions)
        hero_completed_referrals = int(
            (rewards_overview or {}).get("completed_referrals_count") or 0
        )
        if hero_completed_referrals <= 0:
            for m in milestone_missions:
                code = str(m.get("mission_code") or "").upper()
                if code == "COMPLETE_1_REFERRAL" and m.get("is_complete"):
                    hero_completed_referrals = max(hero_completed_referrals, int(m.get("progress") or 0))
                    break

        currency_sym = str((rewards_overview or {}).get("currency_symbol") or "R").strip() or "R"

        milestone_featured: Optional[Dict[str, Any]] = None
        milestone_completed_rows: List[Dict[str, Any]] = []
        milestone_future_rows: List[Dict[str, Any]] = []
        if milestone_missions:
            ms_sorted = sorted(
                milestone_missions,
                key=lambda m: (
                    int(m.get("display_order") or 0),
                    str(m.get("mission_code") or ""),
                ),
            )
            for m in ms_sorted:
                if not m.get("is_complete"):
                    milestone_featured = m
                    break
            for m in ms_sorted:
                if m.get("is_complete"):
                    milestone_completed_rows.append(m)
                elif m is not milestone_featured:
                    milestone_future_rows.append(m)

        milestone_earned_total = sum(
            float(m.get("reward_earned_amount") or 0.0)
            for m in milestone_missions
            if m.get("is_complete")
        )

        hero_next: Optional[Dict[str, Any]] = None
        if milestone_featured:
            prog = int(milestone_featured.get("progress") or 0)
            goal = int(milestone_featured.get("goal") or 0)
            away = max(0, goal - prog) if goal > 0 else 0
            pct = 0.0 if goal <= 0 else min(100.0, (prog * 100.0) / float(goal))
            hero_next = {
                "title": str(milestone_featured.get("title") or "Next milestone").strip(),
                "amount": float(milestone_featured.get("bonus_reward_amount") or 0.0),
                "progress": prog,
                "goal": goal,
                "progress_label": str(
                    milestone_featured.get("progress_label") or f"{prog} / {goal}"
                ),
                "referrals_away": away,
                "progress_percent": pct,
            }

        return render(
            request,
            "my_referral_missions.html",
            {
                "referrer_ucn": referrer_ucn,
                "tenant": tenant,
                "missions": missions,
                "core_missions": core_missions,
                "boost_missions": boost_missions,
                "milestone_missions": milestone_missions,
                "milestone_featured": milestone_featured,
                "milestone_completed_rows": milestone_completed_rows,
                "milestone_future_rows": milestone_future_rows,
                "milestone_earned_total": milestone_earned_total,
                "missions_total_count": total_count,
                "missions_total_earned": total_earned,
                "boost_bonus_earned": boost_bonus_earned,
                "hero_completed_referrals": hero_completed_referrals,
                "hero_currency_symbol": currency_sym,
                "hero_next": hero_next,
                "completed_count": completed_count,
                "active_count": active_count,
                "terms_pending": False,
            },
        )

    @router.get("/me/leaderboard")
    def my_referral_leaderboard(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)
        if require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn", status_code=302)

        referrer_ucn = ocep["ucn"]
        tenant = ocep["tenant"]
        leaderboard_my: Optional[Dict[str, Any]] = None
        leaderboard_rows: List[Dict[str, Any]] = []
        leaderboard_generated: Optional[str] = None

        if leaderboard_code_setting:
            leaderboard_my, leaderboard_rows, leaderboard_generated = fetch_leaderboard_for_me(
                api_client,
                leaderboard_code_setting,
                referrer_ucn,
                leaderboard_top_n,
            )

        return render(
            request,
            "my_referral_leaderboard.html",
            {
                "referrer_ucn": referrer_ucn,
                "tenant": tenant,
                "leaderboard_code": leaderboard_code_setting,
                "leaderboard_my": leaderboard_my,
                "leaderboard_rows": leaderboard_rows,
                "leaderboard_generated": leaderboard_generated,
            },
        )

    @router.get("/me/rewards")
    def my_referral_rewards(request: Request):
        ocep = get_ocep_context(request)
        if not ocep:
            return RedirectResponse(url="/?no_ocep=1", status_code=302)
        if require_terms_for_me(request, ocep):
            return RedirectResponse(url="/refer-and-earn", status_code=302)
        # Decommissioned rewards surface; route kept for backward compatibility.
        return RedirectResponse(url="/me/progress", status_code=302)

    return router
