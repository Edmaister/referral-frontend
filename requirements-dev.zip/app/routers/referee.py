from __future__ import annotations

import json
import logging
import time
from typing import Any, Callable, Dict, Optional
from urllib.parse import quote

import requests
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import RedirectResponse

from app.services.referee_dashboard_service import fetch_referee_dashboard
from app.services.referee_referral_view_service import fetch_referee_referral_detail
from app.services.referee_rewards_service import fetch_referee_rewards
from app.services.reward_explanation_service import fetch_reward_explanation
from app.services.security_service import verify_csrf
from referral_client import workflows

logger = logging.getLogger(__name__)


def build_referee_router(
    *,
    render: Callable[[Request, str, Dict[str, Any]], Any],
    api_client: Any,
    record_validated: Callable[[str, Optional[str]], None],
    record_accepted: Callable[[str, Optional[str]], None],
    api_error_message: Callable[[requests.RequestException], str],
    render_recommendations: Callable[[Any], Optional[Dict[str, Any]]],
) -> APIRouter:
    router = APIRouter()

    @router.get("/friend")
    def friend_landing(
        request: Request,
        referral_code: Optional[str] = None,
        tenant_code: str = "FNB",
        accepted: bool = False,
        validate: bool = False,
        accepted_terms: Optional[str] = None,
        alias: Optional[str] = None,
    ):
        validate_result = None
        referee_recommendations: Optional[Dict[str, Any]] = None
        referee_journey: Optional[Dict[str, Any]] = None

        if accepted:
            try:
                session = getattr(request, "session", None) or {}
                referee_track_id = session.get("referee_referral_track_id", "")
                referee_ucn = session.get("referee_ucn", "")
                stored_tenant = session.get("referee_tenant_code", tenant_code)
                identifier = referee_ucn or referee_track_id
                if identifier:
                    raw_recommendations = api_client.my_recommendations(
                        referrer_hash=identifier,
                        sticker="EASY",
                        tenant=stored_tenant,
                        subject_role="SELF",
                    )
                    referee_recommendations = render_recommendations(raw_recommendations)
                if referee_track_id:
                    referee_journey = fetch_referee_dashboard(
                        api_client,
                        referee_track_id,
                        logger,
                    )
            except requests.RequestException as e:
                logger.warning("Referee recommendations failed: %s", e)
                referee_recommendations = None
            except Exception as e:
                logger.warning("Referee recommendations error: %s", e)
                referee_recommendations = None

        if referral_code and validate:
            code_clean = (referral_code or "").strip()
            tenant_clean = (tenant_code or "FNB").strip()
            logger.info("Validate referral: referralCode=%s tenantCode=%s", code_clean, tenant_clean)
            accepted_terms_bool = str(accepted_terms or "").strip() in ("1", "true", "True", "yes", "on")
            payload: Dict[str, Any] = {
                "tenantCode": tenant_clean,
                "referralCode": code_clean,
                "acceptedTerms": accepted_terms_bool,
            }
            if alias and str(alias).strip():
                payload["alias"] = str(alias).strip()
            last_error = None
            try:
                for attempt in range(2):
                    try:
                        validate_result = api_client.validate_referral(payload)
                        logger.info("Validate API raw response: %s", json.dumps(validate_result, default=str))
                        break
                    except requests.RequestException as e:
                        last_error = e
                        status = getattr(getattr(e, "response", None), "status_code", None)
                        is_retryable = status is None or status >= 500 or "timeout" in str(e).lower() or "connection" in str(type(e).__name__).lower()
                        if attempt == 0 and is_retryable:
                            logger.info("Validate referral attempt %s failed (status=%s), retrying once...", attempt + 1, status)
                            time.sleep(1.0)
                            continue
                        raise
                if not validate_result:
                    validate_result = {"valid": False, "message": "No response from referral service."}
                    logger.warning("Validate referral: empty response body")
                else:
                    data = validate_result.get("data") or validate_result.get("result") or validate_result
                    if not isinstance(data, dict):
                        data = validate_result
                    track_id = (
                        data.get("referral_track_id")
                        or data.get("referralTrackId")
                        or data.get("referralTrackID")
                        or data.get("referralInstanceId")
                        or data.get("referral_instance_id")
                        or data.get("track_id")
                        or data.get("trackId")
                        or validate_result.get("referral_track_id")
                        or validate_result.get("referralTrackId")
                        or validate_result.get("referralTrackID")
                        or validate_result.get("referralInstanceId")
                        or validate_result.get("referral_instance_id")
                    )
                    if track_id and isinstance(track_id, dict):
                        track_id = track_id.get("id") or track_id.get("value") or None
                    track_id = str(track_id).strip() if track_id else None
                    raw_valid = data.get("valid") or data.get("Valid") or validate_result.get("valid") or validate_result.get("Valid")
                    is_valid = raw_valid is True or (isinstance(raw_valid, str) and raw_valid.strip().lower() == "true")
                    alias_out = data.get("alias") or validate_result.get("alias")
                    if track_id:
                        validate_result["referral_track_id"] = track_id
                    validate_result["valid"] = is_valid
                    if alias_out:
                        validate_result["alias"] = str(alias_out)
                    logger.info("Validate referral response: valid=%s referral_track_id=%s (raw valid=%s)", is_valid, track_id, raw_valid)
                    if is_valid and track_id:
                        record_validated(code_clean, track_id)
                        try:
                            request.session["referee_referral_track_id"] = track_id
                            request.session["referee_referral_code"] = code_clean
                            request.session["referee_tenant_code"] = tenant_clean
                            if validate_result.get("alias"):
                                request.session["referee_alias"] = validate_result.get("alias")
                        except Exception:
                            pass
                    else:
                        validate_result.setdefault("valid", False)
                        if not validate_result.get("message") and validate_result.get("error_code"):
                            validate_result["message"] = str(validate_result.get("error_code"))
                        validate_result.setdefault("message", "Referral code was not accepted. Check the code and tenant (e.g. FNB).")
            except requests.RequestException as e:
                err = last_error if last_error is not None else e
                status = getattr(getattr(err, "response", None), "status_code", None)
                body = ""
                if getattr(err, "response", None) is not None and err.response is not None:
                    try:
                        body = (err.response.text or "")[:500]
                    except Exception:
                        pass
                logger.warning("Validate referral failed: status=%s error=%s body=%s", status, err, body)
                if getattr(err, "response", None) is not None and err.response is not None and err.response.text:
                    try:
                        logger.warning("Validate API error body (parsed): %s", json.dumps(err.response.json(), default=str))
                    except Exception:
                        pass
                msg = api_error_message(err)
                if status is None or "Connection" in str(type(err).__name__) or "timeout" in msg.lower():
                    msg = "The referral service couldn't be reached. It can be temporarily unavailable—please try again in a moment."
                elif status and status >= 500:
                    msg = "The referral service is temporarily unavailable. Please try again in a moment. If it keeps failing, the backend may need a health check."
                validate_result = {"valid": False, "message": msg}
        elif referral_code:
            referral_code = (referral_code or "").strip() or None

        base = str(request.base_url).rstrip("/")
        share_url = f"{base}/friend?referral_code={quote(referral_code or '')}&tenant_code={quote(tenant_code)}" if referral_code else ""

        return render(
            request,
            "friend.html",
            {
                "tenant_code": tenant_code or "FNB",
                "referral_code": referral_code or "",
                "validate_result": validate_result,
                "accepted": accepted,
                "share_url": share_url,
                "referee_recommendations": referee_recommendations,
                "referee_journey": referee_journey,
            },
        )

    @router.post("/friend/accept")
    async def friend_accept(request: Request):
        try:
            form = await request.form()
            verify_csrf(request, form)
            referral_track_id = (form.get("referral_track_id") or "").strip()
            referral_code = (form.get("referral_code") or "").strip() or None

            if referral_track_id:
                try:
                    workflows.record_referral_progress_event(
                        api_client,
                        referral_track_id=referral_track_id,
                        event_type="ACCOUNT_OPENED",
                        product="ACCOUNT",
                    )
                except requests.RequestException as e:
                    logger.warning("Progress API failed (continuing): %s", e)
                record_accepted(referral_track_id, referral_code)
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("friend/accept error: %s", e)

        return RedirectResponse(url="/friend?accepted=true", status_code=303)

    @router.get("/friend/rewards")
    def friend_rewards(request: Request, referral_track_id: Optional[str] = None):
        try:
            session = getattr(request, "session", None) or {}
        except Exception:
            session = {}
        track_id = (referral_track_id or session.get("referee_referral_track_id") or "").strip()
        selected_reward_id = (request.query_params.get("reward_id") or "").strip()

        rewards_payload = (
            fetch_referee_rewards(api_client, track_id, logger)
            if track_id
            else None
        ) or {
            "items": [],
            "earned_amount": 0.0,
            "pending_amount": 0.0,
            "potential_max_amount": 0.0,
            "potential_narrative": "",
            "potential_breakdown": [],
        }
        reward_explanation = (
            fetch_reward_explanation(api_client, selected_reward_id, logger)
            if selected_reward_id
            else None
        )

        return render(
            request,
            "friend_rewards.html",
            {
                "referral_track_id": track_id,
                "rewards_items": rewards_payload.get("items", []),
                "rewards_earned_amount": float(rewards_payload.get("earned_amount", 0.0)),
                "rewards_pending_amount": float(
                    rewards_payload.get("pending_amount", 0.0)
                ),
                "rewards_potential_max_amount": float(
                    rewards_payload.get("potential_max_amount", 0.0)
                ),
                "rewards_potential_narrative": rewards_payload.get("potential_narrative") or "",
                "rewards_potential_breakdown": rewards_payload.get("potential_breakdown") or [],
                "selected_reward_id": selected_reward_id,
                "reward_explanation": reward_explanation,
            },
        )

    @router.get("/friend/journey")
    def friend_journey(request: Request, referral_track_id: Optional[str] = None):
        try:
            session = getattr(request, "session", None) or {}
        except Exception:
            session = {}
        track_id = (referral_track_id or session.get("referee_referral_track_id") or "").strip()
        referral_view = (
            fetch_referee_referral_detail(api_client, track_id, logger) if track_id else None
        )
        dashboard = (
            fetch_referee_dashboard(api_client, track_id, logger)
            if track_id and referral_view is None
            else None
        )
        detail_unavailable = bool(track_id) and referral_view is None and dashboard is None

        return render(
            request,
            "friend_journey.html",
            {
                "referral_track_id": track_id,
                "referee_dashboard": dashboard,
                "referee_detail": referral_view,
                "detail_unavailable": detail_unavailable,
            },
        )

    return router
