from __future__ import annotations

import logging
import os
import uuid
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv

    _env_path = APP_DIR.parent / ".env"
    if _env_path.is_file():
        load_dotenv(_env_path)
except ImportError:
    pass

import requests
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.templating import Jinja2Templates

from app.adapters.referral_api_adapter import ReferralApiAdapter
from app.config import (
    ALLOW_EXTERNAL_CDN,
    DEMO_MODE,
    ENABLE_ADMIN_CONSOLE,
    LEADERBOARD_CODE_SETTING,
    LEADERBOARD_TOP_N,
    PROGRESS_EVENT_TYPES,
    REFERRAL_API_TIMEOUT_SECONDS,
    SESSION_OCEP_KEYS,
)
from app.recommendation_renderer import render_recommendations
from app.routers.admin import build_admin_router
from app.routers.core import build_core_router
from app.routers.referee import build_referee_router
from app.routers.referrer import build_referrer_router
from app.services.error_service import api_error_message
from app.services.leaderboard_mapping_service import (
    leaderboard_generated_label as leaderboard_generated_label_service,
)
from app.services.leaderboard_mapping_service import (
    normalize_leaderboard_rows as normalize_leaderboard_rows_service,
)
from app.services.leaderboard_mapping_service import (
    normalize_my_leaderboard as normalize_my_leaderboard_service,
)
from app.services.leaderboard_ui_service import (
    fetch_leaderboard_for_me as fetch_leaderboard_for_me_service,
)
from app.services.observability_service import (
    clear_correlation_id,
    get_correlation_id,
    set_correlation_id,
)
from app.services.progress_ui_service import (
    fetch_referrer_progress_from_api as fetch_referrer_progress_from_api_service,
)
from app.services.progress_ui_service import (
    normalize_referrer_progress as normalize_referrer_progress_service,
)
from app.services.referrer_code_service import (
    resolve_referrer_code_for_ui as resolve_referrer_code_for_ui_service,
)
from app.services.reward_summary_ui_service import (
    fetch_reward_summary as fetch_reward_summary_service,
)
from app.services.security_service import get_csrf_token
from app.copy import ux_copy_catalog as ux_copy_catalog
from app.services.referrer_home_hero_service import default_me_hero_context
from app.services.template_service import build_renderer
from app.services.terms_service import require_terms_for_me
from app.services.tracking_service import (
    get_referrer_statuses as get_referrer_statuses_service,
)
from app.services.tracking_service import (
    lookup_referee_ucn_for_track,
)
from app.services.tracking_service import (
    record_accepted as record_accepted_service,
)
from app.services.tracking_service import (
    record_progress as record_progress_service,
)
from app.services.tracking_service import (
    record_ucn_captured as record_ucn_captured_service,
)
from app.services.tracking_service import (
    record_validated as record_validated_service,
)
from app.services.tracking_service import (
    register_referral_code as register_referral_code_service,
)
from referral_client import ReferralApiClient

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    """
    Application factory: middleware, static, templates, adapter, routers.
    Keeps app.main as a thin entrypoint only.
    """
    logging.basicConfig(level=logging.INFO)

    app = FastAPI(title="Referral Portal")

    @app.middleware("http")
    async def correlation_id_middleware(request: Request, call_next):
        correlation_id = request.headers.get("X-Correlation-ID") or str(uuid.uuid4())
        set_correlation_id(correlation_id)
        try:
            response = await call_next(request)
        finally:
            clear_correlation_id()
        response.headers["X-Correlation-ID"] = correlation_id
        return response

    secret_key = os.environ.get("SESSION_SECRET", "dev-secret-change-in-production")
    if not DEMO_MODE and (
        not secret_key
        or secret_key.strip() == "dev-secret-change-in-production"
        or len(secret_key.strip()) < 16
    ):
        raise RuntimeError(
            "SESSION_SECRET must be set to a strong value when DEMO_MODE is disabled."
        )
    app.add_middleware(
        SessionMiddleware,
        secret_key=secret_key,
        https_only=not DEMO_MODE,
        same_site="lax",
    )

    app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")
    templates = Jinja2Templates(directory=str(APP_DIR / "templates"))
    templates.env.globals["ux"] = ux_copy_catalog
    templates.env.globals["default_me_hero"] = default_me_hero_context
    render = build_renderer(
        templates=templates,
        get_csrf_token=get_csrf_token,
        allow_external_cdn=ALLOW_EXTERNAL_CDN,
    )

    _referral_client = ReferralApiClient(
        timeout_seconds=REFERRAL_API_TIMEOUT_SECONDS,
        headers_provider=lambda: (
            {"X-Correlation-ID": get_correlation_id()} if get_correlation_id() else {}
        ),
    )
    api_client = ReferralApiAdapter(_referral_client)
    logger.info(
        "Referral API base URL: %s (set REFERRAL_API_BASE_URL or add .env in project root)",
        _referral_client.base_url,
    )
    _base = (_referral_client.base_url or "").lower()
    if _base.startswith("http://127.0.0.1:8000") or _base.startswith("http://localhost:8000"):
        logger.warning(
            "Referral API base is %s. If this uvicorn process is the UX portal on the same host/port, "
            "outbound bootstrap/issue calls will hit this app instead of the referral service (500/404). "
            "Run the referral API separately and set REFERRAL_API_BASE_URL to that base URL.",
            _referral_client.base_url,
        )

    def format_api_error(exc: requests.RequestException) -> str:
        return api_error_message(exc)

    app.include_router(
        build_core_router(
            render=render,
            admin_console_enabled=ENABLE_ADMIN_CONSOLE,
        )
    )
    app.include_router(
        build_referee_router(
            render=render,
            api_client=api_client,
            record_validated=record_validated_service,
            record_accepted=record_accepted_service,
            api_error_message=format_api_error,
            render_recommendations=render_recommendations,
        )
    )
    app.include_router(
        build_admin_router(
            render=render,
            api_client=api_client,
            progress_event_types=PROGRESS_EVENT_TYPES,
            session_ocep_keys=SESSION_OCEP_KEYS,
            lookup_referee_ucn_for_track=lookup_referee_ucn_for_track,
            record_ucn_captured=record_ucn_captured_service,
            record_progress=record_progress_service,
            record_accepted=record_accepted_service,
            api_error_message=format_api_error,
            render_recommendations=render_recommendations,
        )
    )
    app.include_router(
        build_referrer_router(
            render=render,
            api_client=api_client,
            leaderboard_code_setting=LEADERBOARD_CODE_SETTING,
            leaderboard_top_n=LEADERBOARD_TOP_N,
            require_terms_for_me=require_terms_for_me,
            resolve_referrer_code_for_ui=lambda **kwargs: resolve_referrer_code_for_ui_service(
                client=api_client,
                logger=logger,
                api_error_message=format_api_error,
                **kwargs,
            ),
            register_referral_code=register_referral_code_service,
            fetch_referrer_progress_from_api=lambda referrer_ucn: fetch_referrer_progress_from_api_service(
                api_client,
                referrer_ucn,
                logger,
                normalizer=normalize_referrer_progress_service,
            ),
            get_referrer_statuses=get_referrer_statuses_service,
            fetch_leaderboard_for_me=lambda client, leaderboard_code, referrer_ucn, list_limit: fetch_leaderboard_for_me_service(
                client,
                leaderboard_code,
                referrer_ucn,
                list_limit,
                logger,
                normalize_my_leaderboard_service,
                leaderboard_generated_label_service,
                normalize_leaderboard_rows_service,
            ),
            api_error_message=format_api_error,
            render_recommendations=render_recommendations,
            fetch_reward_summary=lambda client, tid: fetch_reward_summary_service(
                client, tid, logger
            ),
        )
    )

    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}

    return app
