from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.config import DEMO_MODE


def register_referral_code(_referrer_ucn: str, _referral_code: str) -> None:
    """Frontend does not own referral business state."""
    return


def record_validated(_referral_code: str, _referral_track_id: Optional[str]) -> None:
    return


def record_ucn_captured(_referral_track_id: str, _referee_ucn: str) -> None:
    return


def record_progress(_referral_track_id: str, _event_type: str) -> None:
    return


def record_accepted(_referral_track_id: str, _referral_code: Optional[str] = None) -> None:
    return


def get_referrer_statuses(_referrer_ucn: str) -> List[Dict[str, Any]]:
    """
    In DEMO_MODE, return sample rows when the progress API is unavailable so local
    previews show the referrer progress card layout.
    """
    if not DEMO_MODE:
        return []
    return [
        {
            "referralTrackId": "demo-track-active",
            "refereeAlias": "Preview friend",
            "progressPercent": 75,
            "isComplete": False,
            "lastUpdatedAt": "2026-04-09T12:00:00Z",
            "pendingRewardAmount": 200.0,
        },
        {
            "referralTrackId": "demo-track-done",
            "refereeAlias": "Preview complete",
            "progressPercent": 100,
            "isComplete": True,
            "rewardEarned": True,
            "lastUpdatedAt": "2026-04-08T12:00:00Z",
        },
    ]


def lookup_referee_ucn_for_track(_referral_track_id: str) -> str:
    return ""
