from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import requests


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def fetch_referee_dashboard(
    client: Any,
    referral_track_id: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """Fetch and normalize referee journey view; returns None on unavailable endpoint."""
    if not (referral_track_id or "").strip():
        return None
    try:
        raw = client.get_referee_dashboard(referral_track_id)
    except requests.RequestException as exc:
        logger.info("Referee dashboard unavailable; fallback to legacy view: %s", exc)
        return None

    if not isinstance(raw, dict):
        return None

    journey = _pick(raw, "journey", default={}) or {}
    rewards = _pick(raw, "rewards", default={}) or {}
    compliance = _pick(raw, "compliance", default={}) or {}
    conditions = _pick(journey, "conditions", default=[]) or []
    if not isinstance(conditions, list):
        conditions = []

    return {
        "current_milestone": _pick(journey, "currentMilestone", "current_milestone"),
        "next_milestone": _pick(journey, "nextMilestone", "next_milestone"),
        "next_step_potential_reward": _to_float(
            _pick(
                journey,
                "nextStepPotentialReward",
                "next_step_potential_reward",
                default=0,
            )
        ),
        "conditions": [str(item) for item in conditions if item is not None],
        "earned_amount": _to_float(_pick(rewards, "earnedAmount", "earned_amount", default=0)),
        "potential_amount": _to_float(
            _pick(rewards, "potentialAmount", "potential_amount", default=0)
        ),
        "disclaimer": _pick(compliance, "disclaimer"),
    }
