from __future__ import annotations

import base64
import secrets
from typing import Any

from fastapi import HTTPException, Request

from app.config import ADMIN_PASSWORD, ADMIN_USERNAME, ENABLE_ADMIN_CONSOLE


def require_admin_console(request: Request) -> None:
    if not ENABLE_ADMIN_CONSOLE:
        raise HTTPException(status_code=404, detail="Not found")
    if ADMIN_USERNAME and ADMIN_PASSWORD:
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Basic "):
            raise HTTPException(
                status_code=401,
                detail="Admin authentication required",
                headers={"WWW-Authenticate": "Basic"},
            )
        try:
            decoded = base64.b64decode(auth.split(" ", 1)[1]).decode("utf-8")
            username, password = decoded.split(":", 1)
        except Exception:
            raise HTTPException(
                status_code=401,
                detail="Invalid admin authentication header",
                headers={"WWW-Authenticate": "Basic"},
            )
        user_ok = secrets.compare_digest(username, ADMIN_USERNAME)
        pass_ok = secrets.compare_digest(password, ADMIN_PASSWORD)
        if not (user_ok and pass_ok):
            raise HTTPException(
                status_code=401,
                detail="Invalid admin credentials",
                headers={"WWW-Authenticate": "Basic"},
            )


def get_csrf_token(request: Request) -> str:
    token = request.session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf_token"] = token
    return token


def verify_csrf(request: Request, form: Any) -> None:
    expected = request.session.get("csrf_token")
    provided = str(form.get("csrf_token") or "")
    if not expected or not provided or not secrets.compare_digest(str(expected), provided):
        raise HTTPException(status_code=403, detail="Invalid CSRF token")
