from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests

from app.services.reward_summary_extensions import normalize_reward_summary_extensions


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _totals_field(
    totals: Dict[str, Any],
    root: Dict[str, Any],
    *keys: str,
    root_aliases: tuple[str, ...] = (),
    default: Any = 0,
) -> Any:
    v = _pick(totals, *keys, default=None)
    if v is not None:
        return v
    for alias in root_aliases:
        v = _pick(root, alias, default=None)
        if v is not None:
            return v
    return default


def summary_response_to_legacy_referrer_rewards(raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Map ``GET /v1/rewards/summary/referrers/{ucn}`` to the legacy
    ``items`` + ``summary`` shape consumed by this module and templates.
    """
    totals = _pick(raw, "totals", default={}) or {}
    if not isinstance(totals, dict):
        totals = {}
    summary = {
        "earnedAmount": _totals_field(
            totals, raw, "earned", "earnedAmount", root_aliases=("earned", "earnedAmount")
        ),
        "pendingAmount": _totals_field(
            totals, raw, "pending", "pendingAmount", root_aliases=("pending", "pendingAmount")
        ),
        "potentialMaxAmount": _totals_field(
            totals,
            raw,
            "totalPotential",
            "total_potential",
            root_aliases=(
                "totalPotential",
                "total_potential",
                "potentialMaxAmount",
                "potential_max_amount",
            ),
        ),
        "potentialNarrative": _pick(
            raw, "potentialNarrative", "potential_narrative", default=""
        ),
        "amountSemanticsVersion": _pick(
            raw, "amountSemanticsVersion", "amount_semantics_version", default=""
        ),
        "potentialBreakdown": _pick(
            raw, "potentialBreakdown", "potential_breakdown", default=[]
        )
        or [],
    }
    items_raw = _pick(raw, "items", "lineItems", "line_items", default=[]) or []
    if not isinstance(items_raw, list):
        items_raw = []
    return {"items": items_raw, "summary": summary}


def fetch_referrer_rewards(
    client: Any,
    referrer_ucn: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """
    Fetch and normalize referrer rewards via ``GET /v1/rewards/summary/referrers/{ucn}`` only.
    Returns None if the client has no ``get_referrer_reward_summary`` or the call fails.
    """
    summary_fn = getattr(client, "get_referrer_reward_summary", None)
    if not callable(summary_fn):
        return None
    try:
        blob = summary_fn(referrer_ucn)
    except requests.RequestException as exc:
        logger.info("Referrer reward summary unavailable: %s", exc)
        return None

    if not isinstance(blob, dict):
        return None
    raw = summary_response_to_legacy_referrer_rewards(blob)

    items_raw = _pick(raw, "items", default=[]) or []
    if not isinstance(items_raw, list):
        items_raw = []

    items: List[Dict[str, Any]] = []
    for row in items_raw[:20]:
        if not isinstance(row, dict):
            continue
        items.append(
            {
                "reward_id": _pick(row, "rewardId", "reward_id", default=""),
                "amount": _to_float(_pick(row, "amount", default=0)),
                "status": str(_pick(row, "status", default="")).upper(),
                "reward_source": str(
                    _pick(row, "rewardSource", "reward_source", default="")
                ).upper(),
                "trigger_summary": _pick(
                    row,
                    "triggerSummary",
                    "trigger_summary",
                    default="Referral progress completed",
                ),
                "created_at": _pick(row, "createdAt", "created_at", default=""),
            }
        )

    summary = _pick(raw, "summary", default={}) or {}
    extensions = normalize_reward_summary_extensions(summary)
    return {
        "items": items,
        "earned_amount": _to_float(
            _pick(summary, "earnedAmount", "earned_amount", default=0)
        ),
        "pending_amount": _to_float(
            _pick(summary, "pendingAmount", "pending_amount", default=0)
        ),
        **extensions,
    }
