from __future__ import annotations

import logging
from typing import Optional, TypedDict

from fastapi import Request

from app.config import DEMO_MODE, OCEP_HEADERS

logger = logging.getLogger(__name__)


class OCEPContext(TypedDict, total=False):
    ucn: str
    tenant: str
    sticker: str
    segment: str


def get_ocep_context(request: Request) -> Optional[OCEPContext]:
    """
    Resolve OCEP context: headers first (production), then session, then query params (admin testing).
    """
    headers = request.headers
    ucn = headers.get(OCEP_HEADERS["ucn"])
    tenant = headers.get(OCEP_HEADERS["tenant"])
    sticker = headers.get(OCEP_HEADERS["sticker"])
    segment = headers.get(OCEP_HEADERS["segment"])
    if ucn and tenant:
        return OCEPContext(
            ucn=ucn.strip(),
            tenant=(tenant or "FNB").strip(),
            sticker=(sticker or "EASY").strip(),
            segment=(segment or "EASY").strip(),
        )

    try:
        session = getattr(request, "session", None)
        if session:
            su = session.get("ocep_ucn")
            st = session.get("ocep_tenant")
            ss = session.get("ocep_sticker")
            sg = session.get("ocep_segment")
            if su and st:
                return OCEPContext(
                    ucn=su,
                    tenant=st,
                    sticker=ss or "EASY",
                    segment=sg or "EASY",
                )
    except Exception as e:
        logger.warning("Session OCEP read failed: %s", e)

    if not DEMO_MODE:
        return None
    q = request.query_params
    qu = q.get("ocep_ucn") or q.get("ucn")
    qt = q.get("ocep_tenant") or q.get("tenant")
    if qu and qt:
        try:
            request.session["ocep_ucn"] = qu.strip()
            request.session["ocep_tenant"] = qt.strip()
            request.session["ocep_sticker"] = (q.get("ocep_sticker") or q.get("sticker") or "EASY").strip()
            request.session["ocep_segment"] = (q.get("ocep_segment") or q.get("segment") or "EASY").strip()
        except Exception:
            pass
        return OCEPContext(
            ucn=qu.strip(),
            tenant=qt.strip(),
            sticker=(q.get("ocep_sticker") or q.get("sticker") or "EASY").strip(),
            segment=(q.get("ocep_segment") or q.get("segment") or "EASY").strip(),
        )
    return None
