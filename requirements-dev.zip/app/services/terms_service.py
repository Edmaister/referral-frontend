from __future__ import annotations

from typing import Any, Optional


def terms_accepted(request: Any) -> bool:
    try:
        return bool(getattr(request, "session", {}).get("terms_accepted"))
    except Exception:
        return False


def require_terms_for_me(request: Any, ocep: Optional[dict]) -> bool:
    if not ocep:
        return False
    q = request.query_params
    if q.get("ocep_ucn") or q.get("ucn"):
        return False
    return not terms_accepted(request)
