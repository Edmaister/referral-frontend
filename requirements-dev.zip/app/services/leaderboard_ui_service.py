from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests


def fetch_leaderboard_for_me(
    client: Any,
    leaderboard_code: str,
    referrer_ucn: str,
    list_limit: int,
    logger: logging.Logger,
    normalize_my: Any,
    generated_label: Any,
    normalize_rows: Any,
) -> tuple[Optional[Dict[str, Any]], List[Dict[str, Any]], Optional[str]]:
    my_row: Optional[Dict[str, Any]] = None
    try:
        my_raw = client.get_my_leaderboard_position(leaderboard_code, referrer_ucn)
        my_row = normalize_my(my_raw)
    except requests.RequestException as e:
        logger.warning("Leaderboard /me failed: %s", e)

    try:
        list_raw = client.get_leaderboard(leaderboard_code, limit=list_limit)
        gen = generated_label(list_raw)
        my_name = (my_row or {}).get("display_name") if my_row else None
        rows = normalize_rows(list_raw, my_display_name=my_name)
        return my_row, rows, gen
    except requests.RequestException as e:
        logger.warning("Leaderboard list failed: %s", e)
        return my_row, [], None
