from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests

from app.copy.ux_copy_catalog import (
    REFERRER_PHASE_FINAL_STEPS,
    REFERRER_STATUS_COMPLETED,
    enrich_referrer_progress_row,
    contains_referee_sensitive_action_hint,
    format_referrer_milestone_for_display,
)


def finalize_progress_rows_for_ui(rows: List[Dict[str, Any]]) -> None:
    """
    Call after any post-normalize mutation (e.g. lastUpdatedLabel) so list cards always
    have stable template keys (camelCase + snake_case mirrors).
    """
    for row in rows:
        _ensure_milestone_display_for_template(row)
        row["current_milestone"] = str(row.get("currentMilestone") or "")
        row["next_milestone"] = str(row.get("nextMilestone") or "")
        row["current_milestone_display"] = str(row.get("currentMilestoneDisplay") or "")
        row["next_milestone_display"] = str(row.get("nextMilestoneDisplay") or "")


def _ensure_milestone_display_for_template(row: Dict[str, Any]) -> None:
    """
    Templates expect currentMilestoneDisplay / nextMilestoneDisplay. Backfill if missing
    (stale deploy, partial enrich, or Jinja treating absent keys as empty).
    """
    is_complete = bool(row.get("is_complete"))
    if is_complete:
        if not str(row.get("currentMilestoneDisplay") or "").strip():
            cur = str(row.get("currentMilestone") or "").strip()
            row["currentMilestoneDisplay"] = (
                format_referrer_milestone_for_display(cur) or REFERRER_STATUS_COMPLETED
            )
        row["nextMilestoneDisplay"] = str(row.get("nextMilestoneDisplay") or "").strip()
        return

    if not str(row.get("currentMilestoneDisplay") or "").strip():
        cur = str(row.get("currentMilestone") or "").strip()
        disp = format_referrer_milestone_for_display(cur) if cur else ""
        if not disp:
            disp = str(row.get("referrerStatusDetail") or "").strip()
        row["currentMilestoneDisplay"] = disp or "—"

    if not str(row.get("nextMilestoneDisplay") or "").strip():
        nxt = str(row.get("nextMilestone") or "").strip()
        if contains_referee_sensitive_action_hint(nxt):
            row["nextMilestoneDisplay"] = REFERRER_PHASE_FINAL_STEPS
        elif nxt:
            row["nextMilestoneDisplay"] = format_referrer_milestone_for_display(nxt)
        else:
            row["nextMilestoneDisplay"] = ""


def normalize_referrer_progress(raw: Any) -> List[Dict[str, Any]]:
    """
    Normalize the referrer progress payload into the shape our UI expects.
    Defensive for snake_case/camelCase variants.
    """
    if not raw:
        return []

    records = None
    if isinstance(raw, dict):
        for key in ("items", "Items", "data", "results", "records"):
            if isinstance(raw.get(key), list):
                records = raw.get(key)
                break
        if records is None and isinstance(raw.get("referral_progress"), list):
            records = raw.get("referral_progress")
    elif isinstance(raw, list):
        records = raw

    if records is None or not isinstance(records, list):
        return []

    def _coalesce(*values: Any) -> Any:
        for v in values:
            if v is None:
                continue
            if isinstance(v, str) and not v.strip():
                continue
            return v
        return None

    def _to_bool(v: Any) -> bool:
        if isinstance(v, bool):
            return v
        if v is None:
            return False
        if isinstance(v, (int, float)):
            return bool(v)
        s = str(v).strip().lower()
        return s in ("1", "true", "t", "yes", "y", "on", "completed", "complete")

    def _to_int(v: Any) -> Optional[int]:
        if v is None:
            return None
        try:
            return int(v)
        except Exception:
            return None

    def _to_percent(v: Any) -> Optional[int]:
        num = _to_int(v)
        if num is None:
            return None
        if num < 0:
            return 0
        if num > 100:
            return 100
        return num

    def _to_reward_float(v: Any) -> Optional[float]:
        if v is None or (isinstance(v, str) and not str(v).strip()):
            return None
        try:
            return float(v)
        except Exception:
            return None

    normalized: List[Dict[str, Any]] = []
    for r in records:
        if not isinstance(r, dict):
            continue

        prog_dict = r.get("progress") if isinstance(r.get("progress"), dict) else {}
        journey_dict = r.get("journey") if isinstance(r.get("journey"), dict) else {}

        referral_code = (
            r.get("referral_code")
            or r.get("referralCode")
            or r.get("code")
            or r.get("referralShortCode")
            or r.get("short_code")
            or r.get("shortCode")
        )
        referral_track_id = (
            r.get("referral_track_id")
            or r.get("referralTrackId")
            or r.get("referralInstanceId")
            or r.get("referral_instance_id")
            or r.get("track_id")
            or r.get("trackId")
        )
        status = r.get("status") or r.get("state") or r.get("journeyStatus")

        validated_at = (
            r.get("validated_at")
            or r.get("validatedAt")
            or r.get("validatedOn")
            or r.get("created_at")
            or r.get("createdAt")
        )
        accepted_at = r.get("accepted_at") or r.get("acceptedAt") or r.get("acceptedOn")

        referee_alias = (
            r.get("referee_alias")
            or r.get("refereeAlias")
            or r.get("alias")
            or r.get("refereeProfileAlias")
        )
        referee_ucn = (
            r.get("referee_ucn")
            or r.get("refereeUCN")
            or r.get("refereeUcn")
            or r.get("referee")
        )

        raw_events = (
            r.get("progress_events")
            or r.get("progressEvents")
            or r.get("events")
            or r.get("journeyEvents")
            or []
        )
        progress_events: List[Dict[str, Any]] = []
        if isinstance(raw_events, list):
            for ev in raw_events:
                if not isinstance(ev, dict):
                    continue
                event_type = ev.get("event_type") or ev.get("eventType") or ev.get("type")
                occurred_at = ev.get("occurred_at") or ev.get("occurredAt") or ev.get("occurredOn")
                if event_type:
                    progress_events.append({"event_type": event_type, "occurred_at": occurred_at})

        display_alias = _coalesce(referee_alias, referee_ucn)
        progress_percent = _to_percent(
            _coalesce(
                r.get("progressPercent"),
                r.get("progress_percent"),
                r.get("progress_percentage"),
                prog_dict.get("percent"),
                prog_dict.get("progressPercent"),
                prog_dict.get("progress_percent"),
            )
        )
        is_complete = _to_bool(
            _coalesce(r.get("is_complete"), r.get("isComplete"), r.get("is_complete_flag"), r.get("complete"))
        )
        status_str = str(status).strip().lower() if status else ""
        if not is_complete and any(k in status_str for k in ("complete", "completed", "reward")):
            is_complete = True
        if progress_percent is None:
            if is_complete:
                progress_percent = 100
            else:
                if status_str in ("accepted", "account_activated", "activated"):
                    progress_percent = 70
                elif status_str in ("ucn_captured", "validated", "validation", "validated_account"):
                    progress_percent = 40
                elif status_str in ("issued", "in_progress", "inprogress", "started"):
                    progress_percent = 20
                else:
                    progress_percent = 20

        current_milestone = _coalesce(
            r.get("currentMilestone"),
            r.get("display_status"),
            r.get("displayStatus"),
            r.get("current_milestone"),
            prog_dict.get("currentMilestone"),
            prog_dict.get("current_milestone"),
            prog_dict.get("displayStatus"),
            prog_dict.get("display_status"),
            journey_dict.get("currentMilestone"),
            journey_dict.get("current_milestone"),
        )
        if not current_milestone:
            st = _coalesce(r.get("status"), r.get("state"), r.get("journeyStatus"))
            if st is not None and str(st).strip():
                current_milestone = str(st).strip()
        if not current_milestone:
            current_milestone = "Completed" if is_complete else ("On track" if progress_percent >= 60 else "In progress")

        next_milestone = _coalesce(
            r.get("nextMilestone"),
            r.get("next_milestone"),
            r.get("nextMilestoneName"),
            prog_dict.get("nextMilestone"),
            prog_dict.get("next_milestone"),
            journey_dict.get("nextMilestone"),
            journey_dict.get("next_milestone"),
        )
        if not next_milestone:
            next_milestone = "Reward earned" if is_complete else "Next milestone pending"

        last_updated_at = _coalesce(
            r.get("lastUpdatedAt"),
            r.get("updated_at"),
            r.get("updatedAt"),
            r.get("updated_on"),
            r.get("accepted_at") if accepted_at else None,
            r.get("validated_at") if validated_at else None,
            r.get("created_at"),
            r.get("createdAt"),
        )
        reward_earned = _to_bool(
            _coalesce(r.get("reward_earned"), r.get("rewardEarned"), r.get("reward_applied"), r.get("rewardApplied"))
        )
        rewards_pending_amount = _to_reward_float(
            _coalesce(
                r.get("rewards_pending_amount"),
                r.get("rewardsPendingAmount"),
                r.get("pendingRewardAmount"),
                r.get("pending_reward_amount"),
                r.get("rewardPendingAmount"),
                r.get("pending_reward"),
            )
        )

        row: Dict[str, Any] = {
            "referral_code": str(referral_code).strip() if referral_code else None,
            "referral_track_id": str(referral_track_id).strip() if referral_track_id else None,
            "status": str(status).strip() if status else "unknown",
            "validated_at": validated_at,
            "accepted_at": accepted_at,
            "referee_alias": referee_alias,
            "referee_ucn": referee_ucn,
            "alias": display_alias,
            "progressPercent": progress_percent,
            "currentMilestone": str(current_milestone) if current_milestone is not None else "",
            "nextMilestone": str(next_milestone) if next_milestone is not None else "",
            "is_complete": is_complete,
            "rewardEarned": reward_earned,
            "lastUpdatedAt": last_updated_at,
            "progress_events": progress_events,
            "rewardsPendingAmount": rewards_pending_amount,
        }
        enrich_referrer_progress_row(row)
        _ensure_milestone_display_for_template(row)
        normalized.append(row)

    def _sort_key(x: Dict[str, Any]) -> str:
        return str(x.get("lastUpdatedAt") or x.get("accepted_at") or x.get("validated_at") or "")

    normalized.sort(key=_sort_key, reverse=True)
    return normalized


def fetch_referrer_progress_from_api(
    client: Any,
    referrer_ucn: str,
    logger: logging.Logger,
    normalizer: Optional[Any] = None,
) -> Optional[List[Dict[str, Any]]]:
    try:
        raw = client.get_referrer_progress(referrer_ucn)
        if normalizer:
            return normalizer(raw)
        return normalize_referrer_progress(raw)
    except requests.RequestException as e:
        logger.warning("Fetch referrer progress failed; using demo store. error=%s", e)
        return None
    except Exception as e:
        logger.warning("Fetch referrer progress normalization failed; using demo store. error=%s", e)
        return None


def fetch_referrer_progress_snapshot(
    client: Any,
    referrer_ucn: str,
    logger: logging.Logger,
    normalizer: Optional[Any] = None,
) -> Optional[Dict[str, Any]]:
    """
    Fetch /v1/referrers/{referrer_ucn} and expose both normalized records and
    summary counters (total/completed/in-progress/has-active) for the progress UI.
    """
    def _to_int(value: Any, default: int) -> int:
        try:
            return int(value)
        except Exception:
            return default

    def _to_bool(value: Any, default: bool) -> bool:
        if isinstance(value, bool):
            return value
        if value is None:
            return default
        s = str(value).strip().lower()
        if s in ("1", "true", "yes", "on"):
            return True
        if s in ("0", "false", "no", "off"):
            return False
        return default

    def _pick(raw_dict: Dict[str, Any], *keys: str) -> Any:
        for k in keys:
            if k in raw_dict and raw_dict.get(k) is not None:
                return raw_dict.get(k)
        return None

    try:
        raw = client.get_referrer_summary(referrer_ucn)
        if normalizer:
            records = normalizer(raw)
        else:
            records = normalize_referrer_progress(raw)
        records = records or []
        total_default = len(records)
        completed_default = sum(1 for r in records if r.get("is_complete"))
        in_progress_default = max(0, total_default - completed_default)

        if isinstance(raw, dict):
            total_referrals = _to_int(
                _pick(raw, "totalReferrals", "total_referrals"),
                total_default,
            )
            completed_referrals = _to_int(
                _pick(raw, "completedReferralsCount", "completed_referrals_count"),
                completed_default,
            )
            in_progress_referrals = _to_int(
                _pick(raw, "inProgressReferralsCount", "in_progress_referrals_count"),
                in_progress_default,
            )
            has_active_referrals = _to_bool(
                _pick(raw, "hasActiveReferrals", "has_active_referrals"),
                in_progress_referrals > 0,
            )
        else:
            total_referrals = total_default
            completed_referrals = completed_default
            in_progress_referrals = in_progress_default
            has_active_referrals = in_progress_referrals > 0

        return {
            "records": records,
            "total_referrals": max(0, total_referrals),
            "completed_referrals_count": max(0, completed_referrals),
            "in_progress_referrals_count": max(0, in_progress_referrals),
            "has_active_referrals": has_active_referrals,
        }
    except requests.RequestException as e:
        logger.warning("Fetch referrer summary failed; using demo store. error=%s", e)
        return None
    except Exception as e:
        logger.warning(
            "Fetch referrer summary normalization failed; using demo store. error=%s",
            e,
        )
        return None
