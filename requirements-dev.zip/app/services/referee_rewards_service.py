from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests

from app.services.reward_summary_extensions import normalize_reward_summary_extensions


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def fetch_referee_rewards(
    client: Any,
    referral_track_id: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """Fetch and normalize referee rewards payload."""
    referral_track_id = (referral_track_id or "").strip()
    if not referral_track_id:
        return None
    try:
        raw = client.get_referee_rewards(referral_track_id)
    except requests.RequestException as exc:
        logger.info("Referee rewards unavailable; fallback to empty view: %s", exc)
        return None

    if not isinstance(raw, dict):
        return None

    items_raw = _pick(raw, "items", default=[]) or []
    if not isinstance(items_raw, list):
        items_raw = []

    items: List[Dict[str, Any]] = []
    for row in items_raw[:20]:
        if not isinstance(row, dict):
            continue
        items.append(
            {
                "reward_id": _pick(row, "rewardId", "reward_id", default=""),
                "amount": _to_float(_pick(row, "amount", default=0)),
                "status": str(_pick(row, "status", default="")).upper(),
                "reward_source": str(
                    _pick(row, "rewardSource", "reward_source", default="")
                ).upper(),
                "trigger_summary": _pick(
                    row,
                    "triggerSummary",
                    "trigger_summary",
                    default="Referral progress completed",
                ),
                "created_at": _pick(row, "createdAt", "created_at", default=""),
            }
        )

    summary = _pick(raw, "summary", default={}) or {}
    extensions = normalize_reward_summary_extensions(summary)
    return {
        "items": items,
        "earned_amount": _to_float(
            _pick(summary, "earnedAmount", "earned_amount", default=0)
        ),
        "pending_amount": _to_float(
            _pick(summary, "pendingAmount", "pending_amount", default=0)
        ),
        **extensions,
    }
