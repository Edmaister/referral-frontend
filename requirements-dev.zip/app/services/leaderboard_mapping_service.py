from __future__ import annotations

from typing import Any, Dict, List, Optional


def lb_unwrap(raw: Any) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    merged = dict(raw)
    inner = raw.get("data") or raw.get("result")
    if isinstance(inner, dict):
        merged.update(inner)
    return merged


def lb_pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if k not in d:
            continue
        v = d[k]
        if v is None or v == "":
            continue
        return v
    return default


def normalize_my_leaderboard(raw: Any) -> Optional[Dict[str, Any]]:
    d = lb_unwrap(raw)
    if not d:
        return None
    rank = lb_pick(d, "rankPosition", "rank_position")
    return {
        "display_name": lb_pick(d, "displayName", "display_name") or "You",
        "rank": rank,
        "total_score": lb_pick(d, "totalScore", "total_score", default=0),
        "referral_score": lb_pick(d, "referralScore", "referral_score", default=0),
        "milestone_score": lb_pick(d, "milestoneScore", "milestone_score", default=0),
        "bonus_score": lb_pick(d, "bonusScore", "bonus_score", default=0),
        "referrals_count": lb_pick(d, "referralsCount", "referrals_count", default=0),
        "completed_referrals_count": lb_pick(d, "completedReferralsCount", "completed_referrals_count", default=0),
        "badge": lb_pick(d, "badge", default="") or "",
        "points_to_next_rank": lb_pick(d, "pointsToNextRank", "points_to_next_rank"),
        "next_rank_position": lb_pick(d, "nextRankPosition", "next_rank_position"),
        "next_rank_score": lb_pick(d, "nextRankScore", "next_rank_score"),
    }


def normalize_leaderboard_rows(list_raw: Any, *, my_display_name: Optional[str] = None) -> List[Dict[str, Any]]:
    d = lb_unwrap(list_raw)
    items = d.get("items")
    if not isinstance(items, list):
        return []
    my_dn = (my_display_name or "").strip()
    rows: List[Dict[str, Any]] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        dn = str(lb_pick(it, "displayName", "display_name") or "").strip()
        rank = lb_pick(it, "rankPosition", "rank_position")
        rows.append(
            {
                "rank": rank,
                "display_name": dn or "—",
                "total_score": lb_pick(it, "totalScore", "total_score", default=0),
                "badge": lb_pick(it, "badge", default="") or "",
                "referrals_count": lb_pick(it, "referralsCount", "referrals_count"),
                "highlight": bool(my_dn and dn == my_dn),
            }
        )
    return rows


def leaderboard_generated_label(list_raw: Any) -> Optional[str]:
    d = lb_unwrap(list_raw)
    iso = lb_pick(d, "generatedAt", "generated_at")
    if not iso or not isinstance(iso, str):
        return None
    return iso[:10] if len(iso) >= 10 else iso
