from __future__ import annotations

from contextvars import ContextVar
from typing import Optional

_correlation_id_ctx: ContextVar[Optional[str]] = ContextVar("correlation_id", default=None)


def set_correlation_id(correlation_id: str) -> None:
    _correlation_id_ctx.set(correlation_id)


def get_correlation_id() -> Optional[str]:
    return _correlation_id_ctx.get()


def clear_correlation_id() -> None:
    _correlation_id_ctx.set(None)
