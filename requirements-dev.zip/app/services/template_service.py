from __future__ import annotations

from typing import Any, Callable, Dict

from fastapi import Request


def build_renderer(
    *,
    templates: Any,
    get_csrf_token: Callable[[Request], str],
    allow_external_cdn: bool,
) -> Callable[[Request, str, Dict[str, Any]], Any]:
    """Build a template renderer with shared UI context."""

    def render(request: Request, template_name: str, context: Dict[str, Any]) -> Any:
        ctx = dict(context)
        status_code = int(ctx.pop("_http_status", 200))
        ctx["request"] = request
        ctx["csrf_token"] = get_csrf_token(request)
        ctx["allow_external_cdn"] = allow_external_cdn
        return templates.TemplateResponse(
            request=request,
            name=template_name,
            context=ctx,
            status_code=status_code,
        )

    return render
