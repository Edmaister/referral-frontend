from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _to_bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    s = str(v).strip().lower()
    return s in ("1", "true", "yes", "on")


def _format_generated_at(raw: Any) -> str:
    if raw is None:
        return ""
    if isinstance(raw, str):
        s = raw.strip().replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).strftime("%d %b %Y, %H:%M UTC")
        except Exception:
            return raw[:19] if len(raw) >= 19 else raw
    return str(raw)


def _normalize_totals(blob: Any) -> Dict[str, int]:
    if not isinstance(blob, dict):
        return {
            "earned": 0,
            "pending": 0,
            "next_eligible": 0,
            "total_potential": 0,
        }
    return {
        "earned": _to_int(_pick(blob, "earned", default=0)),
        "pending": _to_int(_pick(blob, "pending", default=0)),
        "next_eligible": _to_int(
            _pick(blob, "nextEligibleReward", "next_eligible_reward", default=0)
        ),
        "total_potential": _to_int(
            _pick(blob, "totalPotential", "total_potential", default=0)
        ),
    }


def _normalize_items(raw_items: Any) -> List[Dict[str, Any]]:
    if not isinstance(raw_items, list):
        return []
    out: List[Dict[str, Any]] = []
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        btype = str(_pick(it, "beneficiaryType", "beneficiary_type", default="") or "")
        out.append(
            {
                "beneficiary_type": btype,
                "beneficiary_label": (
                    "Your rewards (referrer)"
                    if btype.upper() == "REFERRER"
                    else "Friend’s programme rewards (referee)"
                    if btype.upper() == "REFEREE"
                    else btype or "Reward"
                ),
                "reward_type": str(_pick(it, "rewardType", "reward_type", default="") or ""),
                "reward_source": str(_pick(it, "rewardSource", "reward_source", default="") or ""),
                "status": str(_pick(it, "status", default="") or ""),
                "amount": _to_int(_pick(it, "amount", default=0)),
                "description": str(_pick(it, "description", default="") or ""),
                "mission_code": _pick(it, "missionCode", "mission_code"),
            }
        )
    return out


def normalize_reward_summary_payload(raw: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(raw, dict):
        return None
    comp = _pick(raw, "compliance", default={}) or {}
    if not isinstance(comp, dict):
        comp = {}
    disclosures = _pick(raw, "disclosures", default=[]) or []
    if not isinstance(disclosures, list):
        disclosures = []

    return {
        "referral_track_id": str(
            _pick(raw, "referralTrackId", "referral_track_id", default="") or ""
        ),
        "currency": str(_pick(raw, "currency", default="ZAR") or "ZAR"),
        "generated_at_raw": _pick(raw, "generatedAt", "generated_at"),
        "generated_at_label": _format_generated_at(_pick(raw, "generatedAt", "generated_at")),
        "referrer": _normalize_totals(_pick(raw, "referrer", default={})),
        "referee": _normalize_totals(_pick(raw, "referee", default={})),
        "count": _to_int(_pick(raw, "count", default=0)),
        "items": _normalize_items(_pick(raw, "items", default=[])),
        "disclosures": [str(d).strip() for d in disclosures if str(d).strip()],
        "compliance": {
            "is_advice": _to_bool(_pick(comp, "isAdvice", "is_advice", default=False)),
            "requires_disclaimer": _to_bool(
                _pick(comp, "requiresDisclaimer", "requires_disclaimer", default=True)
            ),
            "disclaimer_codes": [
                str(c).strip()
                for c in (_pick(comp, "disclaimerCodes", "disclaimer_codes", default=[]) or [])
                if c is not None and str(c).strip()
            ],
            "regulatory_tags": [
                str(t).strip()
                for t in (_pick(comp, "regulatoryTags", "regulatory_tags", default=[]) or [])
                if t is not None and str(t).strip()
            ],
        },
    }


def fetch_reward_summary(
    client: Any,
    referral_track_id: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    tid = (referral_track_id or "").strip()
    if not tid:
        return None
    try:
        raw = client.get_reward_summary(tid)
    except requests.RequestException as exc:
        logger.info("Reward summary unavailable for %s: %s", tid, exc)
        return None
    return normalize_reward_summary_payload(raw)
