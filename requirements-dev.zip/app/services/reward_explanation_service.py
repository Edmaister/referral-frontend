from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import requests


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def fetch_reward_explanation(
    client: Any,
    reward_id: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """Fetch and normalize reward explainability payload."""
    reward_id = (reward_id or "").strip()
    if not reward_id:
        return None
    try:
        raw = client.get_reward_explanation(reward_id)
    except requests.RequestException as exc:
        logger.info("Reward explanation unavailable for %s: %s", reward_id, exc)
        return None

    if not isinstance(raw, dict):
        return None

    met = _pick(raw, "conditionsMet", "conditions_met", default=[]) or []
    outstanding = _pick(
        raw, "conditionsOutstanding", "conditions_outstanding", default=[]
    ) or []
    if not isinstance(met, list):
        met = []
    if not isinstance(outstanding, list):
        outstanding = []

    unlocks = _pick(raw, "whatUnlocksMore", "what_unlocks_more", "pathToMax", "path_to_max", default=[]) or []
    if not isinstance(unlocks, list):
        unlocks = []

    def _to_float(value: Any, default: float = 0.0) -> float:
        try:
            return float(value)
        except Exception:
            return default

    return {
        "reward_id": reward_id,
        "reason": _pick(raw, "reason", default="Reward criteria evaluation summary"),
        "trigger_milestone": _pick(
            raw, "triggerMilestone", "trigger_milestone", default=""
        ),
        "policy_name": _pick(raw, "policyName", "policy_name", default=""),
        "policy_version": _pick(raw, "policyVersion", "policy_version", default=""),
        "conditions_met": [str(item) for item in met if item is not None],
        "conditions_outstanding": [str(item) for item in outstanding if item is not None],
        "amount_status": str(_pick(raw, "amountStatus", "amount_status", default="") or "").upper(),
        "potential_ceiling": _to_float(_pick(raw, "potentialCeiling", "potential_ceiling", default=0)),
        "what_unlocks_more": [str(x) for x in unlocks if x is not None],
        "eligibility_narrative": str(
            _pick(raw, "eligibilityNarrative", "eligibility_narrative", default="") or ""
        ).strip(),
    }
