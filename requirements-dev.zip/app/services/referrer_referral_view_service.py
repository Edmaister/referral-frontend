from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import requests

from app.copy.ux_copy_catalog import apply_referrer_referral_detail_copy


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


def _to_int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _to_bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    s = str(v).strip().lower()
    return s in ("1", "true", "yes", "on")


def normalize_referrer_referral_view_payload(
    raw: Any,
    *,
    fallback_track_id: str = "",
) -> Optional[Dict[str, Any]]:
    """Map raw API JSON to a template-safe dict. Returns None if not a mapping."""
    if not isinstance(raw, dict):
        return None
    tid = (
        str(_pick(raw, "referralTrackId", "referral_track_id", default="") or "").strip()
        or (fallback_track_id or "").strip()
    )
    progress = _pick(raw, "progress", default={}) or {}
    rewards = _pick(raw, "rewards", default={}) or {}
    milestones = _pick(progress, "completedMilestones", "completed_milestones", default=[]) or []
    if not isinstance(milestones, list):
        milestones = []

    result = {
        "referral_track_id": tid,
        "progress_percent": _to_int(_pick(progress, "percent", default=0)),
        "display_status": str(_pick(progress, "displayStatus", "display_status", default="")),
        "is_complete": _to_bool(_pick(progress, "isComplete", "is_complete", default=False)),
        "completed_milestones": [str(m) for m in milestones if m is not None],
        "remaining_state_label": str(
            _pick(progress, "remainingStateLabel", "remaining_state_label", default="")
        ),
        "rewards_earned": _to_float(_pick(rewards, "earnedAmount", "earned_amount", default=0)),
        "rewards_pending": _to_float(
            _pick(rewards, "pendingAmount", "pending_amount", default=0)
        ),
    }
    apply_referrer_referral_detail_copy(result)
    return result


def fetch_referrer_referral_detail(
    client: Any,
    referral_track_id: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """
    Persona-safe referrer view from GET /v1/referrals/{id}/referrer-view.
    Returns None if unavailable; do not infer sensitive milestones client-side.
    """
    tid = (referral_track_id or "").strip()
    if not tid:
        return None
    try:
        raw = client.get_referrer_referral_view(tid)
    except requests.RequestException as exc:
        logger.info("Referrer referral view unavailable for %s: %s", tid, exc)
        return None

    return normalize_referrer_referral_view_payload(raw, fallback_track_id=tid)
