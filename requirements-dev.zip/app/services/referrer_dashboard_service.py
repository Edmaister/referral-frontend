from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def _pick_next_milestone(missions: Dict[str, Any]) -> Dict[str, Any]:
    """
    Pick a portfolio milestone to drive /me tier progression copy.
    Prefer COMPLETE_3_REFERRALS (product rule), else first incomplete milestone.
    """
    milestones = _as_list(_pick(missions, "milestone", default=[]) or [])
    first_incomplete: Optional[Dict[str, Any]] = None
    for m in milestones:
        if not isinstance(m, dict):
            continue
        if str(_pick(m, "missionCode", "mission_code", default="")).upper() == "COMPLETE_3_REFERRALS":
            return m
        if first_incomplete is None and not bool(_pick(m, "isComplete", "is_complete", default=False)):
            first_incomplete = m
    return first_incomplete or {}


def fetch_referrer_dashboard(
    client: Any,
    referrer_ucn: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """
    Fetch and normalize persona-safe referrer dashboard response.
    Returns None when endpoint is unavailable so callers can fallback.
    """
    try:
        raw = client.get_referrer_dashboard(referrer_ucn)
    except requests.RequestException as exc:
        logger.info("Referrer dashboard unavailable; fallback to legacy view: %s", exc)
        return None

    if not isinstance(raw, dict):
        return None

    summary = _as_dict(_pick(raw, "summary", default={}) or {})
    rewards_summary = _as_dict(
        _pick(raw, "rewardsSummary", "rewards_summary", default={}) or {}
    )
    rewards_payload = _as_dict(_pick(raw, "rewards", default={}) or {})
    rewards_totals = _as_dict(_pick(rewards_payload, "totals", default={}) or {})
    referrals = _as_dict(_pick(raw, "referralsSummary", "referrals_summary", default={}) or {})
    leaderboard = _as_dict(_pick(raw, "leaderboard", default={}) or {})
    missions = _as_dict(_pick(raw, "missions", default={}) or {})
    referrals_list = _as_list(_pick(raw, "referrals", default=[]) or [])
    badges_raw = _pick(raw, "badges", default={}) or {}
    if isinstance(badges_raw, list):
        current_badges = badges_raw
    else:
        badges = _as_dict(badges_raw)
        current_badges = _pick(badges, "current", default=[]) or []
    badge_items: List[Dict[str, str]] = []
    if isinstance(current_badges, list):
        for b in current_badges:
            if isinstance(b, dict):
                title = _pick(
                    b,
                    "title",
                    "name",
                    "label",
                    "badgeName",
                    "badge_name",
                    "displayName",
                    "display_name",
                    default="",
                )
                badge_items.append(
                    {"title": str(title).strip() or "Achievement"}
                )
            elif b is not None:
                badge_items.append({"title": str(b).strip() or "Achievement"})

    in_progress_count = _to_int(
        _pick(referrals, "inProgressCount", "in_progress_count", default=0)
    )
    if in_progress_count <= 0 and referrals_list:
        in_progress_count = sum(
            1 for r in referrals_list if isinstance(r, dict) and not bool(r.get("isComplete"))
        )

    completed_count = _to_int(
        _pick(
            summary,
            "completedReferralsCount",
            "completed_referrals_count",
            default=_pick(referrals, "completedCount", "completed_count", default=0),
        )
    )

    active_from_grouped = 0
    for key in ("boost", "core", "milestone", "active"):
        for m in _as_list(_pick(missions, key, default=[]) or []):
            if isinstance(m, dict) and not bool(_pick(m, "isComplete", "is_complete", default=False)):
                active_from_grouped += 1

    milestone_next = _pick_next_milestone(missions)
    milestone_progress = _to_int(_pick(milestone_next, "progressCount", "progress_count", default=0))
    milestone_goal = _to_int(_pick(milestone_next, "goalCount", "goal_count", default=0))
    pending_bonuses_count = _to_int(
        _pick(
            summary,
            "pendingBonusesCount",
            "pending_bonuses_count",
            default=_pick(rewards_payload, "pendingBonusesCount", "pending_bonuses_count", default=0),
        )
    )
    referrals_count = _to_int(
        _pick(summary, "referralsCount", "referrals_count", default=len(referrals_list))
    )

    return {
        "rewards_earned_amount": _to_float(
            _pick(
                rewards_summary,
                "earnedAmount",
                "earned_amount",
                default=_pick(summary, "totalEarned", default=_pick(rewards_totals, "earned", default=0)),
            )
        ),
        "rewards_pending_amount": _to_float(
            _pick(
                rewards_summary,
                "pendingAmount",
                "pending_amount",
                default=_pick(summary, "totalPending", default=_pick(rewards_totals, "pending", default=0)),
            )
        ),
        "referrals_in_progress_count": in_progress_count,
        "referrals_completed_count": completed_count,
        "leaderboard_code": _pick(
            leaderboard, "leaderboardCode", "leaderboard_code", default=""
        ),
        "leaderboard_rank": _pick(leaderboard, "rank", "rankPosition"),
        "leaderboard_tier": _pick(
            summary,
            "leaderboardTier",
            "leaderboard_tier",
            default=_pick(leaderboard, "rankTier", "leaderboardTier", "tier", default=""),
        ),
        "leaderboard_total_score": _to_int(
            _pick(leaderboard, "totalScore", "total_score", default=0)
        ),
        "leaderboard_next_rank_position": _pick(
            leaderboard, "nextRankPosition", "next_rank_position"
        ),
        "points_to_next_rank": _to_int(
            _pick(summary, "pointsToNextRank", default=_pick(leaderboard, "pointsToNextRank", default=0))
        ),
        "leaderboard_next_rank_threshold": _pick(
            leaderboard, "nextRankThreshold", "next_rank_threshold"
        ),
        "active_missions_count": active_from_grouped,
        "pending_bonuses_count": pending_bonuses_count,
        "summary_referrals_count": referrals_count,
        "next_eligible_reward": _to_float(
            _pick(
                summary,
                "nextEligibleReward",
                "next_eligible_reward",
                default=_pick(rewards_totals, "nextEligibleReward", "next_eligible_reward", default=0),
            )
        ),
        "milestone_next_progress_count": milestone_progress,
        "milestone_next_goal_count": milestone_goal,
        "current_badges_count": len(badge_items),
        "badge_items": badge_items,
    }
