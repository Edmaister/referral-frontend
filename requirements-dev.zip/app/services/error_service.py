from __future__ import annotations

import requests


def api_error_message(exc: requests.RequestException) -> str:
    """Build a user-friendly message from a requests exception."""
    if exc.response is not None:
        try:
            body = exc.response.json()
            if isinstance(body, dict):
                msg = body.get("detail") or body.get("message") or body.get("error")
                if isinstance(msg, list):
                    parts = []
                    for m in msg:
                        if isinstance(m, dict) and "msg" in m:
                            piece = str(m["msg"])
                            loc = m.get("loc")
                            if isinstance(loc, (list, tuple)) and loc:
                                loc_str = ".".join(str(x) for x in loc)
                                parts.append(f"{loc_str}: {piece}")
                            else:
                                parts.append(piece)
                        else:
                            parts.append(str(m))
                    return "; ".join(parts) if parts else str(msg)
                if msg:
                    return str(msg)
        except Exception:
            pass
        return f"Backend returned {exc.response.status_code}: {exc.response.text[:200]}"
    return str(exc)
