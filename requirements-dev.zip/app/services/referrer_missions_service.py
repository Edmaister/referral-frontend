from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

import requests

from app.copy.ux_copy_catalog import mission_is_credit_related, sanitize_mission_title_for_display


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


# Alternate API keys seen on missions payloads when canonical amounts are empty.
_REWARD_AMOUNT_SCAN_KEYS: Tuple[str, ...] = (
    "bonusRewardAmount",
    "bonus_reward_amount",
    "maxBonusRewardAmount",
    "max_bonus_reward_amount",
    "bonusRewardMax",
    "bonus_reward_max",
    "rewardAmount",
    "reward_amount",
    "missionRewardAmount",
    "mission_reward_amount",
    "bonusAmount",
    "bonus_amount",
    "displayBonusAmount",
    "display_bonus_amount",
    "potentialBonusReward",
    "potential_bonus_reward",
    "totalBonusReward",
    "total_bonus_reward",
    "earnedBonusAmount",
    "earned_bonus_amount",
    "rewardEarnedAmount",
    "reward_earned_amount",
    "payoutAmount",
    "payout_amount",
    "paidBonusAmount",
    "paid_bonus_amount",
    "paidRewardAmount",
    "paid_reward_amount",
    "awardedAmount",
    "awarded_amount",
    "settledAmount",
    "settled_amount",
    "actualRewardAmount",
    "actual_reward_amount",
    "grantedRewardAmount",
    "granted_reward_amount",
    "creditedAmount",
    "credited_amount",
)


def _best_positive_reward_scan(row: Dict[str, Any]) -> float:
    best = 0.0
    for key in _REWARD_AMOUNT_SCAN_KEYS:
        v = _pick(row, key, default=None)
        if v is None:
            continue
        best = max(best, _to_float(v, 0.0))
    return best


def _normalize_mission_row(row: Dict[str, Any], *, category_default: str = "") -> Dict[str, Any]:
    progress_count = _to_int(
        _pick(row, "progressCount", "progress_count", "progress", default=0)
    )
    goal_count = _to_int(_pick(row, "goalCount", "goal_count", "goal", default=0))
    is_complete = bool(_pick(row, "isComplete", "is_complete", default=False))
    status = str(_pick(row, "status", default="IN_PROGRESS") or "IN_PROGRESS").strip()
    reward_amount = _to_float(
        _pick(row, "bonusRewardAmount", "bonus_reward_amount", default=0)
    )
    currency = str(_pick(row, "currency", default="ZAR") or "ZAR")

    potential = _to_float(
        _pick(
            row,
            "maxBonusRewardAmount",
            "max_bonus_reward_amount",
            "bonusRewardMax",
            "bonus_reward_max",
            "potentialBonusReward",
            "potential_bonus_reward",
            "totalBonusReward",
            "total_bonus_reward",
            "potentialCeiling",
            "potential_ceiling",
            "potentialRewardAmount",
            "potential_reward_amount",
            default=0.0,
        )
    )
    if potential <= 0:
        potential = reward_amount

    scan = _best_positive_reward_scan(row)
    if scan > 0:
        if reward_amount <= 0:
            reward_amount = scan
        if potential <= 0:
            potential = scan
        potential = max(potential, reward_amount)

    earned_explicit = _pick(
        row,
        "earnedBonusAmount",
        "earned_bonus_amount",
        "bonusEarnedAmount",
        "bonus_earned_amount",
        "rewardEarnedAmount",
        "reward_earned_amount",
        "bonusEarned",
        "bonus_earned",
        default=None,
    )
    if earned_explicit is not None:
        earned = _to_float(earned_explicit)
        if is_complete and earned <= 0 < scan:
            earned = potential if potential > 0 else scan
    elif goal_count > 0:
        earned = potential * (progress_count / float(goal_count))
        if is_complete:
            earned = potential
    else:
        earned = potential if is_complete else 0.0

    if earned > potential:
        earned = potential
    if earned < 0:
        earned = 0.0

    mission = {
        "mission_code": _pick(row, "missionCode", "mission_code", default=""),
        "category": str(
            _pick(row, "category", default=category_default or "BOOST") or "BOOST"
        ).strip()
        or "BOOST",
        "scope": str(_pick(row, "scope", default="") or "").strip(),
        "display_order": _to_int(_pick(row, "displayOrder", "display_order", default=0)),
        "title": sanitize_mission_title_for_display(
            str(_pick(row, "title", default="Mission") or "Mission").strip()
        ),
        "body": str(_pick(row, "body", default="") or "").strip(),
        "progress": progress_count,
        "goal": goal_count,
        "progress_label": str(
            _pick(row, "progressLabel", "progress_label", default=f"{progress_count} / {goal_count}")
            or f"{progress_count} / {goal_count}"
        ),
        "status": status,
        "is_complete": is_complete,
        "completed_at": _pick(row, "completedAt", "completed_at", default=None),
        "bonus_reward_amount": reward_amount,
        "reward_potential_max": potential,
        "reward_earned_amount": earned,
        "reward_label": str(
            _pick(row, "rewardLabel", "reward_label", default=f"+{currency} {int(reward_amount)}")
            or f"+{currency} {int(reward_amount)}"
        ),
        "currency": currency,
        "associated_referral_track_ids": _pick(
            row,
            "associatedReferralTrackIds",
            "associated_referral_track_ids",
            default=[],
        )
        or [],
        "disclosures": _pick(row, "disclosures", default=[]) or [],
        "compliance": _pick(row, "compliance", default={}) or {},
        "badge": _pick(row, "badge", default=None),
        "is_credit_related": bool(
            _pick(row, "isCreditRelated", "is_credit_related", default=False)
        ),
    }
    if not mission["is_credit_related"]:
        mission["is_credit_related"] = mission_is_credit_related(mission)
    return mission


def _normalize_mission_bucket(raw_bucket: Any, *, category_default: str) -> List[Dict[str, Any]]:
    if not isinstance(raw_bucket, list):
        return []
    out: List[Dict[str, Any]] = []
    for row in raw_bucket:
        if not isinstance(row, dict):
            continue
        out.append(_normalize_mission_row(row, category_default=category_default))
    out.sort(key=lambda m: (int(m.get("display_order") or 0), str(m.get("title") or "")))
    return out


def fetch_referrer_missions_snapshot(
    client: Any,
    referrer_ucn: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """
    Fetch and normalize referrer missions into grouped buckets plus a flat list.
    Supports both the grouped schema (core/boost/milestone arrays) and legacy items/missions.
    """
    try:
        raw = client.get_referrer_missions(referrer_ucn)
    except requests.RequestException as exc:
        logger.info("Referrer missions unavailable; fallback to empty view: %s", exc)
        return None

    if not isinstance(raw, dict):
        return None

    core = _normalize_mission_bucket(_pick(raw, "core", default=[]), category_default="CORE")
    boost = _normalize_mission_bucket(_pick(raw, "boost", default=[]), category_default="BOOST")
    milestone = _normalize_mission_bucket(
        _pick(raw, "milestone", default=[]), category_default="MILESTONE"
    )

    if not core and not boost and not milestone:
        items_raw = _pick(raw, "items", "missions", default=[]) or []
        boost = _normalize_mission_bucket(items_raw, category_default="BOOST")

    all_missions = list(core) + list(boost) + list(milestone)
    all_missions.sort(
        key=lambda m: (
            str(m.get("category") or ""),
            int(m.get("display_order") or 0),
            str(m.get("title") or ""),
        )
    )

    return {
        "referrer_ucn": str(_pick(raw, "referrerUCN", "referrerUcn", "referrer_ucn", default=referrer_ucn) or referrer_ucn),
        "generated_at": str(_pick(raw, "generatedAt", "generated_at", default="") or ""),
        "total_count": _to_int(_pick(raw, "totalCount", "total_count", default=len(all_missions)), len(all_missions)),
        "core": core,
        "boost": boost,
        "milestone": milestone,
        "all_missions": all_missions,
    }


def fetch_referrer_missions(
    client: Any,
    referrer_ucn: str,
    logger: logging.Logger,
) -> Optional[List[Dict[str, Any]]]:
    """Fetch and normalize referrer-safe missions flat list."""
    snapshot = fetch_referrer_missions_snapshot(client, referrer_ucn, logger)
    if not snapshot:
        return None
    return list(snapshot.get("all_missions") or [])
