from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import requests

from referral_client import workflows


def bootstrap_merged(raw: Any) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    merged: Dict[str, Any] = dict(raw)
    for key in ("data", "result"):
        n = raw.get(key)
        if isinstance(n, dict):
            merged.update(n)
    return merged


def boolish(value: Any) -> bool:
    if value is True:
        return True
    if value is False or value is None:
        return False
    s = str(value).strip().lower()
    return s in ("1", "true", "yes", "on")


def bootstrap_referral_code(raw: Any) -> Optional[str]:
    if not isinstance(raw, dict):
        return None
    candidates = [raw]
    for key in ("data", "result"):
        n = raw.get(key)
        if isinstance(n, dict):
            candidates.append(n)
    for d in candidates:
        code = d.get("referralCode") or d.get("referral_code") or d.get("shortCode") or d.get("short_code")
        if code is not None and str(code).strip():
            return str(code).strip()
    return None


def bootstrap_terms_flags(raw: Any) -> tuple[bool, bool]:
    merged = bootstrap_merged(raw)
    return boolish(merged.get("requiresTermsAcceptance")), boolish(merged.get("acceptedTerms"))


def bootstrap_requires_api_terms(merged: Dict[str, Any]) -> bool:
    """
    exists=true, requiresTermsAcceptance=true, acceptedTerms=false → show terms, then POST /referrals/accept-terms.
    """
    if merged.get("exists") is not True:
        return False
    if not boolish(merged.get("requiresTermsAcceptance")):
        return False
    if boolish(merged.get("acceptedTerms")):
        return False
    return True


def bootstrap_is_favorable(raw: Any) -> bool:
    code = bootstrap_referral_code(raw)
    if not code:
        return False
    req, acc = bootstrap_terms_flags(raw)
    return not (req and not acc)


def issue_shape_from_bootstrap(raw: Dict[str, Any]) -> Dict[str, Any]:
    merged = bootstrap_merged(raw)
    code = bootstrap_referral_code(raw) or ""
    alias = merged.get("alias") or merged.get("gaming_handle") or merged.get("gamingHandle") or ""
    if not isinstance(alias, str):
        alias = str(alias or "")
    alias = alias.strip()
    return {
        "referral_code": code,
        "short_code": code,
        "referralCode": code,
        "gaming_handle": alias,
        "message": merged.get("message"),
        "exists": merged.get("exists"),
        "qr_eligible": merged.get("qrEligible"),
        "accepted_terms": merged.get("acceptedTerms"),
    }


def fetch_bootstrap_safe(
    client: Any,
    referrer_ucn: str,
    tenant: str,
    logger: logging.Logger,
) -> Dict[str, Any]:
    try:
        return workflows.bootstrap_referrer_for_customer(
            client,
            referrer_ucn=referrer_ucn,
            tenant_code=tenant,
        )
    except requests.RequestException as e:
        logger.warning("Referrals bootstrap failed: %s", e)
        return {}


def resolve_referrer_code_for_ui(
    *,
    client: Any,
    logger: logging.Logger,
    api_error_message,
    referrer_ucn: str,
    tenant: str,
    sticker: str,
    segment: str,
    preferred_handle: Optional[str],
    bootstrap_raw: Optional[Dict[str, Any]] = None,
) -> tuple[Dict[str, Any], Optional[str], str]:
    if bootstrap_raw is None:
        bootstrap_raw = fetch_bootstrap_safe(client, referrer_ucn, tenant, logger)

    if bootstrap_is_favorable(bootstrap_raw):
        return issue_shape_from_bootstrap(bootstrap_raw), None, "bootstrap"

    try:
        issue_resp = workflows.issue_referral_code_for_customer(
            client,
            referrer_ucn=referrer_ucn,
            sticker=sticker,
            tenant=tenant,
            segment=segment,
            preferred_handle=preferred_handle,
        )
        return issue_resp, None, "issue"
    except requests.RequestException as e:
        logger.warning("Issue referral code failed: %s", e)
        return {}, api_error_message(e), "issue"
