"""
Persona-safe home (/me): portfolio counts, still available, reward summary helpers.

Per-referral milestone steppers belong on /me/progress and referral detail — not here.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.copy import ux_copy_catalog as ux

REFERRAL_CLOSE_PROGRESS_PCT = 60


def _f(overview: Optional[Dict[str, Any]], key: str, default: float = 0.0) -> float:
    if not overview:
        return default
    try:
        return float(overview.get(key) or 0.0)
    except (TypeError, ValueError):
        return default


def rewards_still_available_amount(rewards_overview: Optional[Dict[str, Any]]) -> float:
    earned = _f(rewards_overview, "earned")
    tp = _f(rewards_overview, "total_potential")
    pending = _f(rewards_overview, "pending")
    still = max(0.0, tp - earned)
    if still <= 0.0 and pending > 0.0:
        return pending
    return still


def summarize_referral_portfolio(progress_rows: List[Dict[str, Any]]) -> Dict[str, int]:
    """Counts in-flight referrals for portfolio copy on /me (not per-milestone UI)."""
    in_prog = [r for r in progress_rows if not r.get("is_complete")]
    active = len(in_prog)
    close = 0
    for r in in_prog:
        pct = int(r.get("progressPercent") or 0)
        pending = float(r.get("rewardsPendingAmount") or 0)
        if pct >= REFERRAL_CLOSE_PROGRESS_PCT or pending > 0:
            close += 1
    return {"active_in_progress": active, "close_to_reward": close}


def portfolio_hero_momentum_line(
    close_n: int,
    active_n: int,
    *,
    next_eligible: float,
    still: float,
    fallback: str,
) -> str:
    """Single hero momentum line: specific portfolio counts first, then programme fallbacks."""
    if close_n == 1:
        return ux.PORTFOLIO_CLOSE_ONE
    if close_n > 1:
        return ux.PORTFOLIO_CLOSE_MANY.format(n=close_n)
    if active_n == 1:
        return ux.PORTFOLIO_ACTIVE_PROGRESS_ONE
    if active_n > 1:
        return ux.PORTFOLIO_ACTIVE_PROGRESS_MANY.format(n=active_n)
    if next_eligible > 0:
        return ux.OVERVIEW_MOMENTUM_NEXT_POSSIBLE
    if still > 0:
        return ux.OVERVIEW_MOMENTUM_STILL_BUILDING
    return fallback


def almost_there_body(active_n: int) -> str:
    if active_n <= 0:
        return ""
    if active_n == 1:
        return ux.MOMENTUM_ALMOST_BODY_ONE
    return ux.MOMENTUM_ALMOST_BODY_MANY.format(n=active_n)


def almost_there_body_short(active_n: int) -> str:
    """Compact in-progress line for /me overview (less copy than almost_there_body)."""
    if active_n <= 0:
        return ""
    if active_n == 1:
        return ux.MOMENTUM_CARD_BODY_SHORT_ONE
    return ux.MOMENTUM_CARD_BODY_SHORT_MANY.format(n=active_n)


def build_me_hero_context(
    *,
    rewards_overview: Optional[Dict[str, Any]],
    tier_progress_percent: int,
    referrals_in_progress_count: int,
) -> Dict[str, Any]:
    """Amounts and optional unlock hints for /me (no stepper — portfolio-led UI)."""
    still = rewards_still_available_amount(rewards_overview)
    next_eligible = _f(rewards_overview, "next_eligible")
    pending = _f(rewards_overview, "pending")

    fallback = ux.OVERVIEW_HERO_FALLBACK_SHARE
    if next_eligible > 0:
        fallback = ux.OVERVIEW_MOMENTUM_NEXT_POSSIBLE
    elif tier_progress_percent >= 85 and referrals_in_progress_count == 0:
        fallback = ux.OVERVIEW_HERO_FALLBACK_HIGH_TIER
    elif referrals_in_progress_count > 0 and still > 0:
        fallback = ux.OVERVIEW_HERO_FALLBACK_IN_FLIGHT

    show_momentum_card = next_eligible > 0 or (pending > 0 and still > 0)
    if next_eligible > 0:
        momentum_card_lead = "next_unlock_amount"
        momentum_unlock_amount = next_eligible
    elif pending > 0 and still > 0:
        momentum_card_lead = "pending_qualifying"
        momentum_unlock_amount = min(pending, still)
    else:
        momentum_card_lead = ""
        momentum_unlock_amount = 0.0

    return {
        "rewards_still_available": still,
        "momentum_hero_line": fallback,
        "show_momentum_card": show_momentum_card,
        "momentum_card_variant": momentum_card_lead,
        "momentum_unlock_amount": momentum_unlock_amount,
    }


def default_me_hero_context() -> Dict[str, Any]:
    """Fallback when ``me_hero`` is missing (stale routes or tests)."""
    return build_me_hero_context(
        rewards_overview=None,
        tier_progress_percent=0,
        referrals_in_progress_count=0,
    )
