from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    s = str(value).strip().lower()
    return s in ("1", "true", "yes", "on")


def _currency_symbol(code: str) -> str:
    c = (code or "").strip().upper()
    symbols = {"ZAR": "R", "USD": "$", "EUR": "€", "GBP": "£"}
    if c in symbols:
        return symbols[c]
    return f"{c} " if c else "R"


def _format_generated_at(raw: Any) -> str:
    if raw is None:
        return ""
    if isinstance(raw, str):
        s = raw.strip().replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).strftime("%d %b %Y, %H:%M UTC")
        except Exception:
            return raw[:19] if len(raw) >= 19 else raw
    return str(raw)


def _normalize_disclosures(raw: Any) -> List[str]:
    if not isinstance(raw, list):
        return []
    out: List[str] = []
    for line in raw:
        if isinstance(line, str) and line.strip():
            out.append(line.strip())
    return out


def _normalize_compliance(blob: Any) -> Dict[str, Any]:
    if not isinstance(blob, dict):
        return {
            "is_advice": False,
            "requires_disclaimer": False,
            "disclaimer_codes": [],
            "regulatory_tags": [],
        }
    codes = _pick(blob, "disclaimerCodes", "disclaimer_codes", default=[]) or []
    tags = _pick(blob, "regulatoryTags", "regulatory_tags", default=[]) or []
    if not isinstance(codes, list):
        codes = []
    if not isinstance(tags, list):
        tags = []
    return {
        "is_advice": _to_bool(_pick(blob, "isAdvice", "is_advice", default=False)),
        "requires_disclaimer": _to_bool(
            _pick(blob, "requiresDisclaimer", "requires_disclaimer", default=False)
        ),
        "disclaimer_codes": [str(x) for x in codes if x is not None],
        "regulatory_tags": [str(x) for x in tags if x is not None],
    }


def _totals_field(
    totals: Dict[str, Any],
    raw: Dict[str, Any],
    *keys: str,
    root_aliases: tuple[str, ...] = (),
    default: Any = 0,
) -> Any:
    """Prefer nested ``totals``, then root-level keys (some gateways flatten the payload)."""
    v = _pick(totals, *keys, default=None)
    if v is not None:
        return v
    if root_aliases:
        v = _pick(raw, *root_aliases, default=None)
        if v is not None:
            return v
    return default


def normalize_referrer_reward_overview_payload(raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalise GET /v1/rewards/summary/referrers/{referrerUcn} for Jinja (avoid dict method names as keys only when accessed with .attr).
    """
    totals = _pick(raw, "totals", default={}) or {}
    if not isinstance(totals, dict):
        totals = {}
    currency = str(_pick(raw, "currency", default="ZAR") or "ZAR")
    gen_raw = _pick(raw, "generatedAt", "generated_at", default="")
    return {
        "referrer_ucn": str(_pick(raw, "referrerUcn", "referrer_ucn", default="") or ""),
        "currency": currency,
        "currency_symbol": _currency_symbol(currency),
        "earned": _to_float(
            _totals_field(totals, raw, "earned", root_aliases=("earned", "earnedAmount"))
        ),
        "pending": _to_float(
            _totals_field(totals, raw, "pending", root_aliases=("pending", "pendingAmount"))
        ),
        "next_eligible": _to_float(
            _totals_field(
                totals,
                raw,
                "nextEligibleReward",
                "nextEligible",
                "nextEligibleAmount",
                "next_eligible_reward",
                "next_eligible",
                root_aliases=(
                    "nextEligibleReward",
                    "nextEligible",
                    "nextEligibleAmount",
                    "next_eligible_reward",
                    "next_eligible",
                ),
            )
        ),
        "total_potential": _to_float(
            _totals_field(
                totals,
                raw,
                "totalPotential",
                "total_potential",
                root_aliases=("totalPotential", "total_potential"),
            )
        ),
        "referrals_count": _to_int(_pick(raw, "referralsCount", "referrals_count", default=0)),
        "completed_referrals_count": _to_int(
            _pick(raw, "completedReferralsCount", "completed_referrals_count", default=0)
        ),
        "pending_bonuses_count": _to_int(
            _pick(raw, "pendingBonusesCount", "pending_bonuses_count", default=0)
        ),
        "line_item_count": _to_int(_pick(raw, "count", default=0)),
        "generated_at": str(gen_raw) if gen_raw else "",
        "generated_label": _format_generated_at(gen_raw),
        "disclosures": _normalize_disclosures(_pick(raw, "disclosures", default=[])),
        "compliance": _normalize_compliance(_pick(raw, "compliance", default={})),
    }


def fetch_referrer_reward_overview(
    client: Any,
    referrer_ucn: str,
    logger: logging.Logger,
) -> Optional[Dict[str, Any]]:
    """Fetch referrer-level reward summary; return None if the API is unavailable."""
    base = getattr(client, "base_url", None) or getattr(
        getattr(client, "_client", None), "base_url", ""
    )
    try:
        raw = client.get_referrer_reward_summary(referrer_ucn)
    except requests.RequestException as exc:
        req_url = ""
        if getattr(exc, "request", None) is not None and exc.request is not None:
            req_url = getattr(exc.request, "url", "") or ""
        logger.warning(
            "Referrer reward summary failed (%s). "
            "Set REFERRAL_API_BASE_URL to your Referral Engine base (e.g. http://127.0.0.1:8000), "
            "not the front-end port. %s",
            req_url or f"base={base!r} referrer_ucn={referrer_ucn!r}",
            exc,
        )
        return None
    except Exception as exc:
        logger.warning("Referrer reward overview failed: %s", exc)
        return None

    if not isinstance(raw, dict):
        return None
    return normalize_referrer_reward_overview_payload(raw)
