"""Normalise optional reward summary fields for 'potential earn' once the API emits them."""

from __future__ import annotations

from typing import Any, Dict, List


def _pick(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def normalize_potential_breakdown(raw: Any) -> List[Dict[str, Any]]:
    if not isinstance(raw, list):
        return []
    out: List[Dict[str, Any]] = []
    for row in raw:
        if not isinstance(row, dict):
            continue
        out.append(
            {
                "code": str(_pick(row, "code", default="") or ""),
                "label": str(_pick(row, "label", "title", default="") or ""),
                "amount": _to_float(_pick(row, "amount", default=0)),
                "status": str(_pick(row, "status", default="") or "").upper(),
            }
        )
    return out


def normalize_reward_summary_extensions(summary: Any) -> Dict[str, Any]:
    """
    Map extended summary fields from GET /v1/rewards/... responses.

    Backend should populate these; until then, values are absent or zero and UIs
    fall back to neutral copy only.
    """
    if not isinstance(summary, dict):
        return {
            "potential_max_amount": 0.0,
            "potential_narrative": "",
            "amount_semantics_version": "",
            "potential_breakdown": [],
        }
    return {
        "potential_max_amount": _to_float(
            _pick(
                summary,
                "potentialMaxAmount",
                "potential_max_amount",
                "maxPotentialAmount",
                "scenario_upper_bound",
                default=0,
            )
        ),
        "potential_narrative": str(
            _pick(
                summary,
                "potentialNarrative",
                "potential_narrative",
                "eligibilityNarrative",
                "eligibility_narrative",
                default="",
            )
            or ""
        ).strip(),
        "amount_semantics_version": str(
            _pick(summary, "amountSemanticsVersion", "amount_semantics_version", default="") or ""
        ).strip(),
        "potential_breakdown": normalize_potential_breakdown(
            _pick(summary, "potentialBreakdown", "potential_breakdown", default=[]) or []
        ),
    }
