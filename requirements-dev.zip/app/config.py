from __future__ import annotations

import os

OCEP_HEADERS = {
    "ucn": "x-ocep-ucn",
    "tenant": "x-ocep-tenant",
    "sticker": "x-ocep-sticker",
    "segment": "x-ocep-segment",
}

SESSION_OCEP_KEYS = ("ocep_ucn", "ocep_tenant", "ocep_sticker", "ocep_segment")

PROGRESS_EVENT_TYPES = (
    "UCN_CAPTURED",
    "ACCOUNT_OPENED",
    "ACCOUNT_ACTIVATED",
    "FUNDED",
    "DEBIT_ORDER_SWITCHED",
    "SALARY_SWITCHED",
    "FIRST_TRANSACTION_COMPLETED",
)

try:
    _lb_top_n = int(os.environ.get("LEADERBOARD_TOP_N", "10"))
except ValueError:
    _lb_top_n = 10
LEADERBOARD_TOP_N = max(3, min(_lb_top_n, 100))
LEADERBOARD_CODE_SETTING = os.environ.get("LEADERBOARD_CODE", "GLOBAL_TRANSACTIONAL").strip()

DEMO_MODE = os.environ.get("DEMO_MODE", "1").strip().lower() in ("1", "true", "yes", "on")
# When DEMO_MODE and the progress API returns an empty list, show sample rows so UX can be previewed locally.
DEMO_PROGRESS_PREVIEW = os.environ.get("DEMO_PROGRESS_PREVIEW", "0").strip().lower() in (
    "1",
    "true",
    "yes",
    "on",
)
ENABLE_ADMIN_CONSOLE = os.environ.get("ENABLE_ADMIN_CONSOLE", "1" if DEMO_MODE else "0").strip().lower() in (
    "1",
    "true",
    "yes",
    "on",
)
ENVIRONMENT = os.environ.get("ENVIRONMENT", "development").strip().lower()
ALLOW_EXTERNAL_CDN = os.environ.get("ALLOW_EXTERNAL_CDN", "1" if DEMO_MODE else "0").strip().lower() in (
    "1",
    "true",
    "yes",
    "on",
)
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "").strip()
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "").strip()

try:
    _api_timeout = int(os.environ.get("REFERRAL_API_TIMEOUT_SECONDS", "10"))
except ValueError:
    _api_timeout = 10
REFERRAL_API_TIMEOUT_SECONDS = max(1, min(_api_timeout, 120))
