from referral_client import ReferralApiClient, workflows


def main() -> None:
    client = ReferralApiClient()

    # 1. Create or look up a campaign (optional helper)
    campaign = workflows.create_marketing_campaign(
        client,
        tenant_code="FNB",
        segment="EASY",
        name="Refer a Friend March 2026",
        campaign_code="REFERRAL_MAR_2026",
        attributes={"channel": "APP"},
    )
    print("Created campaign:", campaign)

    # 2. Issue a referral code for a referrer
    issue_resp = workflows.issue_referral_code_for_customer(
        client,
        referrer_ucn="REFERRER_UCN_123",
        sticker="EASY",
        tenant="FNB",
        segment="EASY",
    )
    print("Issued referral code:", issue_resp)

    referral_code = issue_resp.get("referral_code")
    if not referral_code:
        print("No referral_code returned, stopping.")
        return

    # 3. Validate the referral code for a new referee and capture their UCN
    combined = workflows.validate_and_capture_referral(
        client,
        tenant_code="FNB",
        referral_code=referral_code,
        device_fingerprint="device-xyz",
        ip_address="127.0.0.1",
        referee_ucn="REFEREE_UCN_456",
    )
    print("Validate + capture:", combined)

    validate_response = combined.get("validate_response", {})
    referral_track_id = validate_response.get("referral_track_id") or validate_response.get(
        "referralTrackId"
    )
    if not referral_track_id:
        print("No referral_track_id, cannot continue progress / rewards.")
        return

    # 4. Record a progress event (e.g. account opened)
    progress_resp = workflows.record_referral_progress_event(
        client,
        referral_track_id=referral_track_id,
        event_type="ACCOUNT_OPENED",
    )
    print("Recorded progress:", progress_resp)

    # 5. Apply a reward for the successful referral
    reward_resp = workflows.apply_referral_reward(
        client,
        referral_track_id=referral_track_id,
        reward_type="CASHBACK",
        tenant="FNB",
        sticker="EASY",
        campaign_code="REFERRAL_MAR_2026",
        segment="EASY",
    )
    print("Applied reward:", reward_resp)


if __name__ == "__main__":
    main()

