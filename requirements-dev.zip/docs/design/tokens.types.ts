export type DesignTokens = {
  color: {
    brand: {
      primary: string;
      primaryDark: string;
      primarySoft: string;
    };
    semantic: {
      success: string;
      warning: string;
      info: string;
      danger: string;
    };
    text: {
      primary: string;
      secondary: string;
      muted: string;
      inverse: string;
    };
    surface: {
      page: string;
      card: string;
      subtle: string;
      inverse: string;
    };
    border: {
      default: string;
      strong: string;
      focus: string;
    };
  };
  spacing: Record<string, number>;
  radius: Record<string, number>;
  shadow: Record<string, string>;
  typography: {
    fontFamily: {
      base: string;
    };
    fontSize: Record<string, number>;
    fontWeight: Record<string, number>;
    lineHeight: Record<string, number>;
    letterSpacing: Record<string, string>;
  };
  size: {
    buttonHeight: Record<string, number>;
    icon: Record<string, number>;
    progress: {
      height: number;
    };
  };
  motion: {
    duration: Record<string, string>;
    easing: Record<string, string>;
  };
};
