import type * as React from "react";
import type { ReactNode } from "react";

export type OverviewHeroCardProps = {
  earnedAmount: number;
  availableNowAmount: number;
  nextPotentialAmount?: number;
  primaryLabel?: string;
  secondaryLabel?: string;
  disclaimer?: string;
  onRewardBreakdownClick?: () => void;
  rewardBreakdownLabel?: string;
  currency?: string;
  isLoading?: boolean;
  testId?: string;
};

export type StatTileProps = {
  label: string;
  value: string | number;
  icon?: ReactNode;
  tone?: "default" | "success" | "warning" | "brand";
  onClick?: () => void;
  isLoading?: boolean;
  testId?: string;
};

export type StatsRowItem = {
  key: string;
  label: string;
  value: string | number;
  icon?: React.ReactNode;
  tone?: "default" | "success" | "warning" | "brand";
  onClick?: () => void;
};

export type StatsRowProps = {
  items: StatsRowItem[];
  columns?: 2 | 3 | 4;
  testId?: string;
};

export type ProgressCardProps = {
  title: string;
  body: string;
  progressPercent?: number;
  ctaLabel: string;
  onCtaClick?: () => void;
  icon?: React.ReactNode;
  disclaimer?: string;
  testId?: string;
};

export type TierProgressCardProps = {
  currentTier?: string;
  nextTier: string;
  supportingText: string;
  progressPercent: number;
  pointsToNextRank?: number | null;
  ctaLabel: string;
  onCtaClick?: () => void;
  icon?: React.ReactNode;
  testId?: string;
};

export type OpportunityCardProps = {
  title: string;
  amount: number;
  status: "available" | "in_progress" | "completed" | "blocked";
  description?: string;
  infoLabel?: string;
  onInfoClick?: () => void;
  currency?: string;
  associatedReferralCount?: number;
  testId?: string;
};

export type OpportunityItem = {
  id: string;
  title: string;
  amount: number;
  status: "available" | "in_progress" | "completed" | "blocked";
  description?: string;
  associatedReferralCount?: number;
};

export type OpportunitySectionProps = {
  title?: string;
  items: OpportunityItem[];
  onItemInfoClick?: (id: string) => void;
  currency?: string;
  emptyStateLabel?: string;
  testId?: string;
};

export type ReferralCardProps = {
  referralTrackId: string;
  product?: string | null;
  subProduct?: string | null;
  progressPercent: number;
  progressBand?: string | null;
  displayStatus?: string | null;
  nextMilestone?: string | null;
  isComplete: boolean;
  createdAt?: string | Date | null;
  updatedAt?: string | Date | null;
  onViewDetails?: (referralTrackId: string) => void;
  viewDetailsLabel?: string;
  testId?: string;
};

export type ReferralListSectionProps = {
  title?: string;
  items: ReferralCardProps[];
  onViewDetails?: (referralTrackId: string) => void;
  emptyStateLabel?: string;
  testId?: string;
};

export type BadgePillProps = {
  label: string;
  icon?: React.ReactNode;
  tone?: "brand" | "success" | "warning" | "neutral";
  testId?: string;
};

export type BadgeCardProps = {
  badgeCode: string;
  badgeName: string;
  badgeDescription: string;
  iconName?: string | null;
  awardedAt?: string | Date;
  awardReason?: string | null;
  onClick?: () => void;
  testId?: string;
};

export type TabItem = {
  key: string;
  label: string;
  disabled?: boolean;
};

export type TabNavProps = {
  items: TabItem[];
  activeKey: string;
  onChange: (key: string) => void;
  testId?: string;
};

export type BottomActionBarProps = {
  primaryLabel: string;
  secondaryLabel: string;
  onPrimaryClick?: () => void;
  onSecondaryClick?: () => void;
  primaryDisabled?: boolean;
  secondaryDisabled?: boolean;
  testId?: string;
};

export type ReferralOverviewPageProps = {
  summary: {
    referrerUcn: string;
    currency: string;
    generatedAt: string;
    totalEarned: number;
    totalPending: number;
    totalPotential: number;
    nextEligibleReward: number;
    referralsCount: number;
    completedReferralsCount: number;
    pendingBonusesCount: number;
    badgeCount: number;
    leaderboardRank?: number | null;
    leaderboardBadge?: string | null;
    totalScore?: number | null;
    pointsToNextRank?: number | null;
  };
  missions: {
    core: Array<{
      missionCode: string;
      title: string;
      body: string;
      progressCount: number;
      goalCount: number;
      status: string;
      isComplete: boolean;
      bonusRewardAmount: number;
      associatedReferralTrackIds: string[];
    }>;
    boost: Array<{
      missionCode: string;
      title: string;
      body: string;
      progressCount: number;
      goalCount: number;
      status: string;
      isComplete: boolean;
      bonusRewardAmount: number;
      associatedReferralTrackIds: string[];
    }>;
    milestone: Array<{
      missionCode: string;
      title: string;
      body: string;
      progressCount: number;
      goalCount: number;
      status: string;
      isComplete: boolean;
      bonusRewardAmount: number;
      associatedReferralTrackIds: string[];
    }>;
  };
  badges: Array<{
    badgeCode: string;
    badgeName: string;
    badgeDescription: string;
    iconName?: string | null;
    awardedAt: string;
    awardReason?: string | null;
  }>;
  leaderboard: {
    leaderboardCode?: string | null;
    displayName?: string | null;
    totalScore?: number | null;
    rankPosition?: number | null;
    badge?: string | null;
    nextRankPosition?: number | null;
    nextRankScore?: number | null;
    pointsToNextRank?: number | null;
  };
  referrals: Array<{
    referralTrackId: string;
    product?: string | null;
    subProduct?: string | null;
    progressPercent: number;
    progressBand?: string | null;
    displayStatus?: string | null;
    nextMilestone?: string | null;
    isComplete: boolean;
    createdAt?: string | null;
    updatedAt?: string | null;
  }>;
  onRewardBreakdownClick?: () => void;
  onTrackProgressClick?: () => void;
  onViewTierBenefitsClick?: () => void;
  onReferFriendClick?: () => void;
  onViewMyReferralsClick?: () => void;
  onReferralClick?: (referralTrackId: string) => void;
  onTabChange?: (key: string) => void;
};

export function mapOverviewProps(api: ReferralOverviewPageProps) {
  const firstActiveReferral = api.referrals.find((r) => !r.isComplete);
  const firstBoost = api.missions.boost.find((m) => !m.isComplete);
  const tierLabel = api.leaderboard.badge ?? api.summary.leaderboardBadge ?? "Starter";

  return {
    hero: {
      earnedAmount: api.summary.totalEarned,
      availableNowAmount: 0,
      nextPotentialAmount: api.summary.nextEligibleReward,
      primaryLabel: "Earned",
      secondaryLabel:
        api.summary.nextEligibleReward > 0
          ? `Up to R${api.summary.nextEligibleReward} may be earned next`
          : undefined,
      disclaimer: "Rewards are applied once qualifying actions are completed."
    },
    stats: [
      { key: "referrals", label: "Referrals", value: api.summary.referralsCount },
      { key: "completed", label: "Completed", value: api.summary.completedReferralsCount },
      { key: "opportunities", label: "Opportunities", value: api.summary.pendingBonusesCount },
      { key: "tier", label: "Tier", value: tierLabel }
    ],
    progress: {
      title: "In progress",
      body: firstActiveReferral
        ? "1 referral is progressing toward the next reward milestone."
        : "No active referrals right now.",
      progressPercent: firstActiveReferral?.progressPercent ?? 0,
      ctaLabel: "Track progress"
    },
    tier: {
      nextTier: api.leaderboard.nextRankPosition ? `Rank #${api.leaderboard.nextRankPosition}` : "Next tier",
      supportingText: api.summary.pointsToNextRank
        ? `${api.summary.pointsToNextRank} points to the next rank`
        : "Your programme progress updates as referrals progress.",
      progressPercent: 0
    },
    opportunities: api.missions.boost.map((m) => ({
      id: m.missionCode,
      title: m.title,
      amount: m.bonusRewardAmount,
      status: m.isComplete ? "completed" : m.progressCount > 0 ? "in_progress" : "available",
      description: m.body,
      associatedReferralCount: m.associatedReferralTrackIds.length
    })),
    referrals: api.referrals
  };
}

export type MissionStatus = "available" | "in_progress" | "completed" | "blocked";

export function toMissionStatus(input: {
  isComplete: boolean;
  progressCount: number;
}): MissionStatus {
  if (input.isComplete) return "completed";
  if (input.progressCount > 0) return "in_progress";
  return "available";
}
