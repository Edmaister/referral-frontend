# `/me` overview — production UI spec (handoff)

This document maps the **referrer overview** screen to **tokens**, **components**, and **copy keys** implemented in the FastAPI/Jinja app.

## Design tokens

| Token (concept) | Hex | CSS variable |
|-----------------|-----|----------------|
| Primary (brand) | `#00897B` | `--fnb-teal` |
| Primary dark | `#00695C` | `--fnb-teal-dark` |
| Success | `#2E7D32` | `--fnb-success` |
| Warning | `#F9A825` | `--fnb-warning` |
| Text primary | `#1A1A1A` | `--fnb-text-dark` |
| Text secondary | `#6B7280` | `--fnb-text-muted` |
| Page background | `#F7F9FA` | `--fnb-bg-canvas` |
| Card | `#FFFFFF` | `--fnb-bg-card` |
| Border | `#E5E7EB` | `--fnb-border-light` |

Machine-readable export: **`docs/design-tokens-fnb-overview.json`**.

## Typography (overview only)

| Role | Target | CSS |
|------|--------|-----|
| Hero amount | 32–36px bold | `--type-overview-hero` (clamp) |
| Section / card title | ~18px / 16px bold | `--type-overview-section`, `--type-overview-card-title` |
| Body | 14px | `--type-overview-body` |
| Meta | 12px muted | `--type-overview-meta` |

**Rule:** only one dominant number on the screen — the hero earned amount (teal).

## Spacing

8px grid via `--space-*`. Overview cards use **16px** padding (`--space-4`) and **16px** corner radius (`--radius-overview`). Section gaps target **24px** (`--space-4` / `--space-6` between major blocks).

## Components → files

| Component | Template / markup | Styles |
|-----------|-------------------|--------|
| Hero card | `my_referral.html` → `.overview-hero-card` | `overview-production.css` |
| Stat tiles | `.overview-stat-tiles` | same |
| In progress | `.overview-momentum-card` + dots + **6px bar** | same |
| Bonus | `.overview-bonus-card` | same |
| Tier | `.overview-tier-card` + meter | same |
| Footer CTAs | `.overview-footer-pair` | same; **primary** + **teal outline** |

## Buttons

- **Primary:** filled `--fnb-teal`, white text (global `.btn.primary`).
- **Secondary (scoped):** `.overview-footer-pair .btn.outline` — transparent fill, **teal border** (not grey).

## Copy (compliance)

- Pending slice: `OVERVIEW_HERO_LINE_PENDING` → `{amt} available now`
- Next slice: `OVERVIEW_HERO_LINE_UP_TO` → `Up to {amt} may be earned`
- Qualifying disclaimer: `MOMENTUM_CARD_PROGRESS_SUB`, `REWARDS_MICRO_COMPLIANCE_PROGRESS`

## Micro-interactions (CSS)

- Hero amount: `overview-figure-reveal` (opacity + translateY), disabled when `prefers-reduced-motion: reduce`.
- Tier + momentum bars: `transition` on width; reduced motion removes transition.

## API context fields (`/me` render)

| Field | Purpose |
|-------|---------|
| `rewards_earned_display` | Compact currency string for hero |
| `overview_hero_subline_pending` | First hero subline |
| `overview_hero_subline_next` | Optional second line (may be earned) |
| `overview_momentum_dots_filled` | 0–6 for dot row |
| `overview_momentum_bar_pct` | 0–100 for 6px bar |
| `tier_display_short` | Tier tile label (strips trailing “ tier”) |

## Figma / React handoff

- **Figma:** use JSON tokens + this table for colour styles; component sizes from `overview-production.css`.
- **React:** mirror tokens as a theme object; props for `earnedDisplay`, `sublinePending`, `sublineNext`, `stats`, `dotsFilled`, `barPct`, `tierHeadline`, `tierPercent`.
