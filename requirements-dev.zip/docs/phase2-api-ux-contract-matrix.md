# Phase 2 API to UX Contract Matrix

This document captures the persona-safe API contract the frontend should consume for Phase 2 UX work.

## Referrer Endpoints

### `GET /v1/referrers/{referrer_ucn}/dashboard`
- Use for `Referrer Home Dashboard`.
- Render:
  - `rewardsSummary.earnedAmount`
  - `rewardsSummary.pendingAmount`
  - `referralsSummary.inProgressCount`
  - `referralsSummary.completedCount`
  - `leaderboard.rank`
  - `missions.active[]`
  - `badges.current[]`

### `GET /v1/referrals/{referral_track_id}/referrer-view`
- Use for `Referrer Referral Detail`.
- Render:
  - `progress.percent`
  - `progress.displayStatus`
  - `progress.isComplete`
  - `progress.completedMilestones[]`
  - `progress.remainingStateLabel`
  - `rewards.earnedAmount`
  - `rewards.pendingAmount`
- Do not infer pending sensitive milestones on frontend.

### `GET /v1/rewards/summary/referrers/{referrer_ucn}`
- Use for `Referrer Rewards` persona totals (and optional line items when the API returns them).
- Do **not** call `GET /v1/rewards/referrer/{referrer_ucn}` — that route is retired.
- Render:
  - `totals.earned` / `totals.pending` / `totals.totalPotential` (and root-level aliases where the gateway flattens)
  - `referralsCount`, `completedReferralsCount`, disclosures, compliance
  - Optional `items[]` / `lineItems[]` when present: `amount`, `status`, `rewardSource`, `triggerSummary`, `createdAt`
- Copy rule: prefer neutral trigger text (for example, "Referral progress completed").

### `GET /v1/missions/referrer/{referrer_ucn}`
- Use for `Referrer Missions`.
- Render only referrer-safe missions:
  - `title`
  - `progress`
  - `goal`
  - `bonusRewardAmount`
  - `isComplete`
  - `badge`

### `GET /v1/leaderboards/{leaderboard_code}/me`
### `GET /v1/leaderboards/{leaderboard_code}`
- Use for `Referrer Leaderboard`.
- Render:
  - my rank and score
  - anonymized peer rows (`displayName`)
- Never render raw UCN or personal names.

## Referee Endpoints

### `GET /v1/dashboard/referee/{referral_track_id}`
- Use for `Referee Home / My Journey`.
- Render:
  - `journey.currentMilestone`
  - `journey.nextMilestone`
  - `journey.nextStepPotentialReward` (with "may earn" language)
  - `journey.conditions[]`
  - `rewards.earnedAmount`
  - `rewards.potentialAmount`
  - `compliance.disclaimer`

### `GET /v1/referrals/{referral_track_id}/referee-view`
- Use for detail-safe referee journey state.

### `GET /v1/rewards/referee/{referral_track_id}`
- Use for referee reward list/summary.

### `GET /v1/rewards/{reward_id}/explanation`
- Use for reward explainability drawer.
- Render:
  - `reason`
  - `triggerMilestone`
  - `policyName`
  - `policyVersion`
  - `conditionsMet[]`
  - `conditionsOutstanding[]`

## Consent and Privacy

Prefer dedicated consent persistence payload:

```json
{
  "consent": {
    "referrerConfirmedPermission": true,
    "acceptedTerms": true,
    "acceptedAt": "2026-04-09T11:00:00Z"
  }
}
```

## Persona Visibility Policy

Enforce sensitivity in API responses, not template logic.

- `ReferrerReferralView`: no pending sensitive milestones, no next-action prompts for referee behavior.
- `RefereeReferralView`: full actionable state and conditions allowed.
