from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional

import requests

_DEFAULT_API_BASE = (
    "http://my-python-app-env.eba-kdpn8aib.eu-west-1.elasticbeanstalk.com"
)


def _default_base_url() -> str:
    """
    Prefer ``REFERRAL_API_BASE_URL``. When unset and ``DEMO_MODE`` is on (default),
    assume the Referral Engine API runs on localhost port 8001 so it does not collide
    with the UX portal (commonly started on port 8000).
    """
    explicit = os.environ.get("REFERRAL_API_BASE_URL", "").strip()
    if explicit:
        return explicit.rstrip("/")
    if os.environ.get("DEMO_MODE", "1").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    ):
        return "http://127.0.0.1:8001"
    return str(_DEFAULT_API_BASE).rstrip("/")


@dataclass
class ReferralApiClient:
    """
    Thin Python client for the Referral, Campaign & Composite Code API.

    It wraps the Swagger-defined endpoints at:
    http://my-python-app-env.eba-kdpn8aib.eu-west-1.elasticbeanstalk.com/docs

    Set REFERRAL_API_BASE_URL to override the default host (e.g. in production).
    """

    base_url: str = field(default_factory=_default_base_url)
    timeout_seconds: int = 10
    headers_provider: Optional[Callable[[], Dict[str, str]]] = None

    def _url(self, path: str) -> str:
        return f"{self.base_url.rstrip('/')}/{path.lstrip('/')}"

    def _headers(self) -> Dict[str, str]:
        if not self.headers_provider:
            return {}
        try:
            return self.headers_provider() or {}
        except Exception:
            return {}

    def _post(self, path: str, json: Dict[str, Any]) -> requests.Response:
        resp = requests.post(
            self._url(path),
            json=json,
            headers=self._headers(),
            timeout=self.timeout_seconds,
        )
        resp.raise_for_status()
        return resp

    def _patch(self, path: str, json: Dict[str, Any]) -> requests.Response:
        resp = requests.patch(
            self._url(path),
            json=json,
            headers=self._headers(),
            timeout=self.timeout_seconds,
        )
        resp.raise_for_status()
        return resp

    def _put(self, path: str, json: Dict[str, Any]) -> requests.Response:
        resp = requests.put(
            self._url(path),
            json=json,
            headers=self._headers(),
            timeout=self.timeout_seconds,
        )
        resp.raise_for_status()
        return resp

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> requests.Response:
        resp = requests.get(
            self._url(path),
            params=params or {},
            headers=self._headers(),
            timeout=self.timeout_seconds,
        )
        resp.raise_for_status()
        return resp

    # Health / metrics -------------------------------------------------

    def health(self) -> Dict[str, Any]:
        return self._get("/health").json()

    def healthz(self) -> Dict[str, Any]:
        """GET /healthz – lightweight liveness probe."""
        return self._get("/healthz").json()

    def readyz(self) -> Dict[str, Any]:
        """GET /readyz – readiness probe."""
        return self._get("/readyz").json()

    def metrics(self) -> Dict[str, Any]:
        return self._get("/metrics").json()

    # Campaigns --------------------------------------------------------

    def create_campaign(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /campaigns

        Expects shape matching CampaignCreateRequest, for example:
        {
            "tenant_code": "FNB",
            "segment": "EASY",
            "name": "Welcome Bonus",
            "campaign_code": "WELCOME_2026",
            "starts_at": "2026-03-14T00:00:00Z",
            "ends_at": "2026-06-30T23:59:59Z",
            "max_uses": 1000,
            "attributes": {...}
        }
        """
        return self._post("/campaigns", json=payload).json()

    def validate_campaign(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /campaigns/validate
        """
        return self._post("/campaigns/validate", json=payload).json()

    def update_campaign_track(
        self, campaign_track_id: str, payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        PATCH /campaigns/tracks/{campaign_track_id}
        """
        path = f"/campaigns/tracks/{campaign_track_id}"
        return self._patch(path, json=payload).json()

    def get_campaign_policy(
        self, campaign_code: str, tenant_code: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        GET /campaigns/{campaign_code}/policy
        """
        params: Dict[str, Any] = {}
        if tenant_code:
            params["tenant_code"] = tenant_code
        path = f"/campaigns/{campaign_code}/policy"
        return self._get(path, params=params).json()

    def upsert_campaign_policy(
        self, campaign_code: str, payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        PUT /campaigns/{campaign_code}/policy
        """
        path = f"/campaigns/{campaign_code}/policy"
        return self._put(path, json=payload).json()

    # Referrals --------------------------------------------------------

    def issue_referral_code(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /referrals/codes

        Expects ReferralCodeIssue (field names may be camelCase or snake_case per API):
        referrer_ucn, sticker, tenant, segment, acceptedTerms (required), preferred_handle optional.
        """
        return self._post("/referrals/codes", json=payload).json()

    def validate_referral(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /referrals/validate
        Required: tenantCode, referralCode, acceptedTerms.
        Optional: alias, deviceFingerprint, ipAddress, qrCode (telemetry).
        """
        return self._post("/referrals/validate", json=payload).json()

    def bootstrap_referrer(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /referrals/bootstrap – referrer state (code, terms, QR eligibility).
        Body: referrerUcn, tenantCode (per ReferralBootstrapRequest).
        """
        return self._post("/referrals/bootstrap", json=payload).json()

    def accept_referrer_terms(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /referrals/accept-terms – record programme terms for an existing referrer profile.
        Body: referrerUcn, tenantCode, acceptedTerms (typical contract).
        """
        return self._post("/referrals/accept-terms", json=payload).json()

    def capture_referee_ucn(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /referrals/referees/ucn
        """
        return self._post("/referrals/referees/ucn", json=payload).json()

    # Composite codes --------------------------------------------------

    def validate_composite_code(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /composite-codes/validate
        """
        return self._post("/composite-codes/validate", json=payload).json()

    # Rewards ----------------------------------------------------------

    def apply_reward(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /rewards/apply
        """
        return self._post("/rewards/apply", json=payload).json()

    def get_reward_summary(self, referral_track_id: str) -> Dict[str, Any]:
        """
        GET /v1/rewards/summary/{referralTrackId}

        Referrer-safe reward totals, line items, disclosures, and compliance metadata.
        """
        path = f"/v1/rewards/summary/{referral_track_id.lstrip('/')}"
        return self._get(path).json()

    def get_referrer_reward_summary(self, referrer_ucn: str) -> Dict[str, Any]:
        """
        GET /v1/rewards/summary/referrers/{referrerUcn}

        Persona-level totals, referral counts, disclosures, and compliance for the home
        rewards card and My Rewards summary.
        """
        ucn = referrer_ucn.lstrip("/")
        path = f"/v1/rewards/summary/referrers/{ucn}"
        return self._get(path).json()

    # Progress ---------------------------------------------------------

    def post_progress(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /v1/progress
        """
        return self._post("/v1/progress", json=payload).json()

    def get_referrer_progress(self, referrer_ucn: str) -> Dict[str, Any]:
        """
        GET /v1/referrers/{referrerUcn}

        Returns ReferrerReferralProgressResponse: referrerUcn, totalReferrals, items[].
        """
        path = f"/v1/referrers/{referrer_ucn}"
        return self._get(path).json()

    def get_leaderboard(
        self,
        leaderboard_code: str,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        """GET /v1/leaderboards/{leaderboard_code}"""
        params: Dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        path = f"/v1/leaderboards/{leaderboard_code}"
        return self._get(path, params=params).json()

    def get_my_leaderboard_position(
        self,
        leaderboard_code: str,
        referrer_ucn: str,
    ) -> Dict[str, Any]:
        """GET /v1/leaderboards/{leaderboard_code}/me?referrer_ucn=..."""
        path = f"/v1/leaderboards/{leaderboard_code}/me"
        return self._get(path, params={"referrer_ucn": referrer_ucn}).json()

    # Recommendations --------------------------------------------------

    def my_recommendations(
        self,
        referrer_hash: str,
        sticker: str,
        tenant: Optional[str] = None,
        top_k: int = 3,
        subject_role: Optional[str] = None,
        use_cache: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """
        GET /me/recommendations

        subject_role: REFERRER (default server-side) or SELF (e.g. referee context).
        use_cache: when False, bypasses cached recommendations if the API supports it.
        """
        params: Dict[str, Any] = {
            "referrer_hash": referrer_hash,
            "sticker": sticker,
            "top_k": top_k,
        }
        if tenant:
            params["tenant"] = tenant
        if subject_role:
            params["subject_role"] = subject_role
        if use_cache is not None:
            params["use_cache"] = use_cache
        return self._get("/me/recommendations", params=params).json()

    def campaign_insights(
        self,
        campaign_code: str,
        sticker: Optional[str] = None,
        tenant: Optional[str] = None,
        prefer_cache: bool = True,
    ) -> Dict[str, Any]:
        """
        GET /admin/recommendations/campaigns/{campaign_code}
        """
        params: Dict[str, Any] = {"prefer_cache": prefer_cache}
        if sticker:
            params["sticker"] = sticker
        if tenant:
            params["tenant"] = tenant

        path = f"/admin/recommendations/campaigns/{campaign_code}"
        return self._get(path, params=params).json()

