from __future__ import annotations

import uuid
from typing import Any, Dict, Optional

from .client import ReferralApiClient


def _scrub_string_id(value: Any) -> Optional[str]:
    """
    Strip whitespace and invisible characters that often sneak in via copy-paste
    and cause "does not match" errors against backend-stored values.
    """
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    for ch in ("\ufeff", "\u200b", "\u200c", "\u200d", "\u2060"):
        s = s.replace(ch, "")
    s = s.replace("\u00a0", "").replace("\u2009", "").replace("\u202f", "")
    return s if s else None


def _normalize_referral_track_id(tid: str) -> str:
    """Canonical UUID string when the track id is a UUID (avoids casing/format mismatches)."""
    s = (tid or "").strip()
    if not s:
        return s
    try:
        return str(uuid.UUID(s))
    except (ValueError, AttributeError):
        return s


def create_marketing_campaign(
    client: ReferralApiClient,
    *,
    tenant_code: str,
    segment: str,
    name: str,
    campaign_code: str | None = None,
    attributes: Dict[str, Any] | None = None,
    starts_at: str | None = None,
    ends_at: str | None = None,
    max_uses: int | None = None,
) -> Dict[str, Any]:
    """
    High-level helper to create a campaign.
    """
    payload: Dict[str, Any] = {
        "tenant_code": tenant_code,
        "segment": segment,
        "name": name,
    }

    if campaign_code:
        payload["campaign_code"] = campaign_code
    if starts_at:
        payload["starts_at"] = starts_at
    if ends_at:
        payload["ends_at"] = ends_at
    if max_uses is not None:
        payload["max_uses"] = max_uses
    if attributes:
        payload["attributes"] = attributes

    return client.create_campaign(payload)


def upsert_campaign_policy(
    client: ReferralApiClient,
    *,
    campaign_code: str,
    tenant_code: str | None,
    version: int = 1,
    is_active: bool = True,
    rolling_window_days: int | None = None,
    rules_json: Any | None = None,
    product_windows_json: Dict[str, Any] | None = None,
    reward_amounts_json: Dict[str, Any] | None = None,
    product_rules_json: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """
    Upsert a versioned campaign policy for attribution & rewards.
    """
    payload: Dict[str, Any] = {
        "version": version,
        "is_active": is_active,
    }
    if tenant_code:
        payload["tenant_code"] = tenant_code
    if rolling_window_days is not None:
        payload["rolling_window_days"] = rolling_window_days
    if rules_json is not None:
        payload["rules_json"] = rules_json
    if product_windows_json is not None:
        payload["product_windows_json"] = product_windows_json
    if reward_amounts_json is not None:
        payload["reward_amounts_json"] = reward_amounts_json
    if product_rules_json is not None:
        payload["product_rules_json"] = product_rules_json

    return client.upsert_campaign_policy(campaign_code=campaign_code, payload=payload)


def bootstrap_referrer_for_customer(
    client: ReferralApiClient,
    *,
    referrer_ucn: str,
    tenant_code: str,
) -> Dict[str, Any]:
    """
    POST /referrals/bootstrap — referrer state (existing code, terms, QR eligibility).
    """
    return client.bootstrap_referrer(
        {
            "referrerUcn": referrer_ucn,
            "tenantCode": tenant_code,
        }
    )


def accept_referrer_programme_terms(
    client: ReferralApiClient,
    *,
    referrer_ucn: str,
    tenant_code: str,
) -> Dict[str, Any]:
    """POST /referrals/accept-terms — after UX terms acceptance for exists=true pending API terms."""
    return client.accept_referrer_terms(
        {
            "referrerUcn": referrer_ucn,
            "tenantCode": tenant_code,
            "acceptedTerms": True,
        }
    )


def issue_referral_code_for_customer(
    client: ReferralApiClient,
    *,
    referrer_ucn: str,
    sticker: str,
    tenant: str,
    segment: str,
    preferred_handle: str | None = None,
) -> Dict[str, Any]:
    """
    Orchestrates issuing a new referral code for a given customer.
    """
    payload: Dict[str, Any] = {
        "referrer_ucn": referrer_ucn,
        "sticker": sticker,
        "tenant": tenant,
        "segment": segment,
        "acceptedTerms": True,
    }
    if preferred_handle:
        payload["preferred_handle"] = preferred_handle

    return client.issue_referral_code(payload)


def validate_and_capture_referral(
    client: ReferralApiClient,
    *,
    tenant_code: str,
    referral_code: str,
    accepted_terms: bool = True,
    alias: str | None = None,
    device_fingerprint: str | None = None,
    ip_address: str | None = None,
    qr_code: str | None = None,
    referee_ucn: str | None = None,
) -> Dict[str, Any]:
    """
    1. Validate a referral code (acceptedTerms required by API).
    2. Optionally capture the referee's UCN against the resulting referralTrackId.
    """
    validate_payload: Dict[str, Any] = {
        "tenantCode": tenant_code,
        "referralCode": referral_code,
        "acceptedTerms": accepted_terms,
    }
    if alias and str(alias).strip():
        validate_payload["alias"] = str(alias).strip()
    if device_fingerprint:
        validate_payload["deviceFingerprint"] = device_fingerprint
    if ip_address:
        validate_payload["ipAddress"] = ip_address
    if qr_code:
        validate_payload["qrCode"] = qr_code

    validate_resp = client.validate_referral(validate_payload)

    result: Dict[str, Any] = {"validate_response": validate_resp}

    track_id = validate_resp.get("referral_track_id") or validate_resp.get(
        "referralTrackId"
    )
    if referee_ucn and validate_resp.get("valid") and track_id:
        capture_payload = {
            "referral_track_id": track_id,
            "referee_ucn": referee_ucn,
        }
        capture_resp = client.capture_referee_ucn(capture_payload)
        result["capture_response"] = capture_resp

    return result


def record_referral_progress_event(
    client: ReferralApiClient,
    *,
    referral_track_id: str,
    event_type: str,
    product: str | None = "ACCOUNT",
    sub_product: str | None = None,
    occurred_at: str | None = None,
    referee_ucn: str | None = None,
    account_number: str | None = None,
    meta: Dict[str, Any] | None = None,
    source_system: str | None = None,
    source_event_id: str | None = None,
) -> Dict[str, Any]:
    """
    POST /v1/progress — eventType and referralTrackId are required; product is optional in OpenAPI.

    Admin/UI: Referee UCN → JSON refereeUCN; Account number → JSON accountNumber.
    """
    track = _normalize_referral_track_id(referral_track_id)
    ref_ucn = _scrub_string_id(referee_ucn)
    acct = _scrub_string_id(account_number)

    payload: Dict[str, Any] = {
        "referralTrackId": track,
        "eventType": event_type,
    }
    if product and str(product).strip():
        payload["product"] = str(product).strip()
    if sub_product and str(sub_product).strip():
        payload["subProduct"] = str(sub_product).strip()
    if occurred_at:
        payload["occurredAt"] = occurred_at
    if ref_ucn:
        payload["refereeUCN"] = ref_ucn
    if acct:
        payload["accountNumber"] = acct
    if meta:
        payload["meta"] = meta
    if source_system and str(source_system).strip():
        payload["sourceSystem"] = str(source_system).strip()
    if source_event_id and str(source_event_id).strip():
        payload["sourceEventId"] = str(source_event_id).strip()

    return client.post_progress(payload)


def apply_referral_reward(
    client: ReferralApiClient,
    *,
    referral_track_id: str,
    reward_type: str,
    product: str | None = None,
    tenant: str | None = None,
    sticker: str | None = None,
    campaign_code: str | None = None,
    segment: str | None = None,
    campaign_id: str | None = None,
) -> Dict[str, Any]:
    """
    Apply a reward based on an attributed referral.
    """
    payload: Dict[str, Any] = {
        "referral_track_id": referral_track_id,
        "reward_type": reward_type,
    }
    if product:
        payload["product"] = product
    if tenant:
        payload["tenant"] = tenant
    if sticker:
        payload["sticker"] = sticker
    if campaign_code:
        payload["campaign_code"] = campaign_code
    if segment:
        payload["segment"] = segment
    if campaign_id:
        payload["campaign_id"] = campaign_id

    return client.apply_reward(payload)


def validate_composite_code_for_attribution(
    client: ReferralApiClient,
    *,
    composite_code: str,
    tenant_code: str | None = None,
    channel: str | None = None,
    attributes: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """
    Validate a composite code that may contain both campaign and referral information.
    """
    payload: Dict[str, Any] = {
        "composite_code": composite_code,
    }
    if tenant_code:
        payload["tenant_code"] = tenant_code
    if channel:
        payload["channel"] = channel
    if attributes:
        payload["attributes"] = attributes

    return client.validate_composite_code(payload)

