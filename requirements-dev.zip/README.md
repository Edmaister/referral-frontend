## Referral Management & Campaign Attribution (Python Client)

This folder contains a small, opinionated Python client and workflows built on top of the **Referral, Campaign & Composite Code API** exposed at:

- `http://my-python-app-env.eba-kdpn8aib.eu-west-1.elasticbeanstalk.com/docs`

It gives you a ready-made **referral management and campaign attribution capability** that you can plug into backends, jobs, or scripts.

### Install

From this directory:

```bash
pip install -r requirements.txt
```

### Key pieces

- `referral_client/client.py` – low-level `ReferralApiClient` that maps directly to the Swagger endpoints (campaigns, referrals, composite codes, rewards, progress, recommendations).
- `referral_client/workflows.py` – higher-level workflows for:
  - **Creating campaigns** and **upserting campaign policies**
  - **Issuing referral codes** for a given customer
  - **Validating referrals** and capturing **referee UCN**
  - **Recording progress events** (e.g. `ACCOUNT_OPENED`, `FUNDED`)
  - **Applying rewards** once a referral is attributed
  - **Validating composite codes** to handle combined campaign + referral codes
- `examples/basic_flow.py` – end‑to‑end example of:
  1. Creating a campaign
  2. Issuing a referral code
  3. Validating that code and capturing the referee UCN
  4. Recording a progress event
  5. Applying a reward

### Run the basic example

```bash
python -m examples.basic_flow
```

You can adapt the example to your real tenant codes, stickers, and UCNs.

